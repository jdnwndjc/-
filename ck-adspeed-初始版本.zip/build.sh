#!/usr/bin/env bash
# 用法:
#   BT=/path/to/android/build-tools/34.0.0 ./build.sh 输入.apk 输出.apk 密钥库 别名
# 例:
#   BT=$ANDROID_HOME/build-tools/34.0.0 ./build.sh baseline.apk out.apk ./release.keystore release
#
# 做的事: 只重编 src-java/PlayerScan.java，替换 APK 里的 classes7.dex，
#         其余 dex / 资源原样保留，重新对齐 + 签名。
set -euo pipefail

APK_IN="${1:?缺少输入 APK}"
APK_OUT="${2:?缺少输出 APK}"
KS="${3:?缺少 keystore}"
ALIAS="${4:?缺少 key alias}"
KS_PASS="${KS_PASS:?请设置 KS_PASS 环境变量（密钥库口令，不要写进脚本）}"

ROOT="$(cd "$(dirname "$0")" && pwd)"
BT="${BT:?请设置 BT 指向 build-tools 目录}"

for t in d8 zipalign apksigner; do
  [ -x "$BT/$t" ] || { echo "缺少 $BT/$t"; exit 1; }
done
command -v javac >/dev/null || { echo "缺少 javac"; exit 1; }

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

echo "[1/6] 编译 PlayerScan.java"
mkdir -p "$WORK/classes"
javac -nowarn -source 8 -target 8 \
  -cp "$ROOT/lib/stub.jar" \
  -d "$WORK/classes" "$ROOT/src-java/PlayerScan.java"

echo "[2/6] d8 生成 dex"
mkdir -p "$WORK/dex"
"$BT/d8" --min-api 21 --lib "$ROOT/lib/stub.jar" \
  --output "$WORK/dex" $(find "$WORK/classes" -name '*.class')

echo "[3/6] 解包 APK"
mkdir -p "$WORK/apk"
unzip -q -o "$APK_IN" -d "$WORK/apk"
cp "$WORK/dex/classes.dex" "$WORK/apk/classes7.dex"

echo "[4/6] 重新打包"
RAW="$WORK/raw.apk"
( cd "$WORK/apk" && zip -q -r -X "$RAW" . -x '.*' )
# resources.arsc / AndroidManifest.xml 必须 STORED，否则 targetSdk 30+ 装不上
( cd "$WORK/apk" && zip -q -0 "$RAW" resources.arsc AndroidManifest.xml )

echo "[5/6] 对齐"
"$BT/zipalign" -f -p 4 "$RAW" "$WORK/aligned.apk"
"$BT/zipalign" -c 4 "$WORK/aligned.apk"

echo "[6/6] 签名"
"$BT/apksigner" sign \
  --ks "$KS" --ks-key-alias "$ALIAS" \
  --ks-pass "pass:$KS_PASS" --key-pass "pass:$KS_PASS" \
  --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
  --out "$APK_OUT" "$WORK/aligned.apk"

"$BT/apksigner" verify "$APK_OUT" && echo "OK -> $APK_OUT"
