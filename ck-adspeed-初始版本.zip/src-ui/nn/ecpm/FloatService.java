package nn.ecpm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Outline;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

/**
 * 悬浮窗服务。
 *
 * 目的只有一个：在目标应用 / 游戏里直接切开关，不用来回切到助手界面。
 *
 * 设计上刻意做薄：
 *  - 不碰 hook、不读 hook 配置，只读写 SharedPreferences("config")；
 *  - 所有 WindowManager 操作都包 try/catch，加不上就自己停掉并提示，
 *    绝不让悬浮窗的问题影响到模块本身；
 *  - 前台服务只为了在 Android 8+ 上活下来，通知优先级最低，不响不震。
 *
 * v27 两处改动：
 *  1. 状态灯不再依赖广播。Android 8.0 起跨应用隐式广播送不到静态接收器，
 *     界面关掉后 ecpm_ts 永远不更新，灯一直是灰的。改成读
 *     shared_prefs/logbuf.xml 的修改时间 —— EcpmHook 每次改写都会经
 *     ConfigProvider 落一条日志，文件时间就是「最后一次改写」。
 *  2. 尺寸和位置跟着屏幕走：小屏缩球、平板放大、横屏/分屏重新夹回屏内。
 */
public class FloatService extends Service {

    private static final String CH_ID = "nn_ecpm_float";
    private static final int NOTI_ID = 0xEC9;
    /** Service.startForeground 的 FOREGROUND_SERVICE_TYPE_SPECIAL_USE */
    private static final int FGS_SPECIAL_USE = 0x40000000;

    private static final int C_CARD = 0xF7FFFFFF;
    private static final int C_TEXT = 0xFF1A1A1C;
    private static final int C_SUB = 0xFF6B6B70;
    private static final int C_OFF = 0xFFE8E8ED;
    /** 与主界面「外观 → 主题色」同一套色值，顺序必须一致 */
    private static final int[] ACCENTS = {0xFFFF5C7A, 0xFF4C8DFF, 0xFF9B6BFF, 0xFF2FBF9A};
    private static final int C_LINE = 0x14000000;

    private static volatile boolean running = false;

    /** 跟随主界面的主题色；读不到就用默认玫红 */
    private int accent() {
        try {
            int i = getSharedPreferences("config", 0).getInt("accent", 0);
            if (i < 0 || i >= ACCENTS.length) i = 0;
            return ACCENTS[i];
        } catch (Throwable t) {
            return ACCENTS[0];
        }
    }

    public static boolean isRunning() {
        return running;
    }

    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private LinearLayout root;
    private LinearLayout panel;
    private View ballDot;
    private TextView bSpeedY, bSpeedN, bSmartY, bSmartN;
    private TextView tvStatus;
    private View statusDot;
    /** 上次画过的状态灯颜色，没变就不重建 Drawable（2 秒一次，别给 GC 找事） */
    private int paintedDot;
    private SharedPreferences sp;
    private int slop;

    /** 状态灯每 2 秒刷一次；只在悬浮窗活着的时候跑，销毁时一定要撤掉 */
    private Handler ui;
    private final Runnable statusTick = new Runnable() {
        public void run() {
            paintStatus();
            if (ui != null) ui.postDelayed(this, 2000L);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        sp = getSharedPreferences("config", 0);
        slop = (int) (8 * getResources().getDisplayMetrics().density);
        // 前台服务没转成功的话，系统 5 秒后会把进程直接干掉，
        // 那时候悬浮窗闪一下就没了，不如现在就明确失败
        if (!startAsForeground()) {
            stopSelf();
            return;
        }
        if (!showOverlay()) {
            stopSelf();
            return;
        }
        ui = new Handler(Looper.getMainLooper());
        ui.postDelayed(statusTick, 400L);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // 系统回收后尽量自己回来，配合 START_STICKY
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        // 状态灯是每 2 秒一次的死循环，不撤掉会把整个 Service 一起泄漏
        if (ui != null) {
            ui.removeCallbacksAndMessages(null);
            ui = null;
        }
        hideOverlay();
        running = false;
        try {
            stopForeground(true);
        } catch (Throwable ignored) {
        }
        super.onDestroy();
    }

    // ---------------- 前台通知 ----------------

    private boolean startAsForeground() {
        try {
            NotificationManager nm =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(CH_ID, "悬浮窗",
                        NotificationManager.IMPORTANCE_MIN);
                ch.setShowBadge(false);
                ch.enableLights(false);
                ch.enableVibration(false);
                ch.setSound(null, null);
                if (nm != null) nm.createNotificationChannel(ch);
                b = new Notification.Builder(this, CH_ID);
            } else {
                b = new Notification.Builder(this);
            }

            Intent open = new Intent(this, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            int pif = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) pif |= PendingIntent.FLAG_IMMUTABLE;
            PendingIntent pi = PendingIntent.getActivity(this, 0, open, pif);

            b.setSmallIcon(android.R.drawable.stat_notify_sync)
                    .setContentTitle("CK广告助手 · 悬浮窗已开")
                    .setContentText("点这里回到助手，或在悬浮球上直接切开关")
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .setShowWhen(false);

            Notification n = b.build();
            // API 34 起必须带类型，否则抛 MissingForegroundServiceTypeException
            if (Build.VERSION.SDK_INT >= 34) {
                try {
                    getClass().getMethod("startForeground", int.class,
                                    Notification.class, int.class)
                            .invoke(this, Integer.valueOf(NOTI_ID), n,
                                    Integer.valueOf(FGS_SPECIAL_USE));
                } catch (Throwable t) {
                    startForeground(NOTI_ID, n);
                }
            } else {
                startForeground(NOTI_ID, n);
            }
            return true;
        } catch (Throwable t) {
            toast("前台服务启动失败：" + t.getClass().getSimpleName());
            return false;
        }
    }

    // ---------------- 悬浮窗 ----------------

    private boolean showOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            toast("没有悬浮窗权限");
            return false;
        }
        try {
            wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            if (wm == null) return false;

            root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);

            root.addView(buildBall(), new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            panel = buildPanel();
            panel.setVisibility(View.GONE);
            LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            plp.topMargin = dp(6);
            root.addView(panel, plp);

            int type = Build.VERSION.SDK_INT >= 26
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY   // 2038
                    : WindowManager.LayoutParams.TYPE_PHONE;                // 2002
            lp = new WindowManager.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.x = sp.getInt("float_x", dp(8));
            // 第一次摆放放到状态栏下面一点，别压在信号/电量上
            lp.y = sp.getInt("float_y", statusBarH() + dp(96));

            wm.addView(root, lp);
            running = true;
            return true;
        } catch (Throwable t) {
            running = false;
            toast("悬浮窗启动失败：" + t.getClass().getSimpleName());
            return false;
        }
    }

    private void hideOverlay() {
        try {
            if (wm != null && root != null) wm.removeViewImmediate(root);
        } catch (Throwable ignored) {
        }
        root = null;
        panel = null;
    }

    /**
     * 悬浮球。v26 起支持自定义图片（filesDir/ball.png）：
     * 有图就圆形裁切显示，没图就还是原来那颗带字的圆点。
     * 右下角一颗小状态灯，绿=eCPM 最近有改写，灰=没有，一眼能看出模块是不是在干活。
     */
    private View buildBall() {
        int size = dp(ballDp());
        FrameLayout wrap = new FrameLayout(this);
        wrap.setPadding(dp(4), dp(4), dp(4), dp(4));

        Bitmap bm = loadBallBitmap();
        if (bm != null) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageBitmap(bm);
            iv.setOutlineProvider(new ViewOutlineProvider() {
                public void getOutline(View v, Outline o) {
                    o.setOval(0, 0, v.getWidth(), v.getHeight());
                }
            });
            iv.setClipToOutline(true);
            wrap.addView(iv, new FrameLayout.LayoutParams(size, size));
            // 图片边和深色背景容易糊在一起，补一圈细描边
            View ring = new View(this);
            ring.setBackgroundDrawable(ringDrawable());
            wrap.addView(ring, new FrameLayout.LayoutParams(size, size));
        } else {
            TextView t = new TextView(this);
            t.setText("加速");
            t.setTextSize(11);
            t.setTextColor(0xFFFFFFFF);
            t.setGravity(Gravity.CENTER);
            t.setBackgroundDrawable(circle((accent() & 0x00FFFFFF) | 0xD9000000));
            t.setShadowLayer(4f, 0f, 2f, 0x66000000);
            wrap.addView(t, new FrameLayout.LayoutParams(size, size));
        }

        ballDot = new View(this);
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(dp(11), dp(11));
        dlp.gravity = Gravity.END | Gravity.BOTTOM;
        dlp.rightMargin = dp(3);
        dlp.bottomMargin = dp(3);
        wrap.addView(ballDot, dlp);

        bindDrag(wrap);
        paintStatus();
        return wrap;
    }

    /** 悬浮球图片。压过的不超过 256px，解码成本可以忽略 */
    private Bitmap loadBallBitmap() {
        try {
            File f = new File(getFilesDir(), "ball.png");
            if (!f.exists() || f.length() == 0) return null;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 1;
            return BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        } catch (Throwable t) {
            return null;
        }
    }

    private GradientDrawable ringDrawable() {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0x00000000);
        g.setStroke(dp(1), 0x40FFFFFF);
        return g;
    }

    // ---------------- 运行状态 ----------------

    /**
     * 状态灯。
     * eCPM 看「最后一次改写」的时间（见 Diag.ecpmLast），3 分钟内算运行中；
     * 加速不猜运行状态 —— 它是设了就生效的开关，直接读开关，比"未检测"有用。
     */
    private void paintStatus() {
        try {
            long ecpm = Diag.ecpmLast(this, sp);
            boolean ecpmOn = Diag.fresh(ecpm, Diag.WIN_ECPM);
            int c = ecpmOn ? 0xFF32D583 : 0xFF8E8E93;
            if (paintedDot != c) {
                paintedDot = c;
                if (ballDot != null) ballDot.setBackgroundDrawable(dot(c, 2));
                if (statusDot != null) statusDot.setBackgroundDrawable(dot(c, 1));
            }
            if (tvStatus != null) {
                String ecpmText;
                if (ecpm <= 0) {
                    ecpmText = "未检测到改写";
                } else if (ecpmOn) {
                    ecpmText = "运行中 · " + Diag.agoText(ecpm);
                } else {
                    ecpmText = "上次 " + Diag.agoText(ecpm);
                }
                String s = "eCPM  " + ecpmText + "\n加速  "
                        + (sp.getBoolean("speed_enabled", true) ? "已开启" : "已关闭");
                if (!s.equals(tvStatus.getText().toString())) tvStatus.setText(s);
            }
        } catch (Throwable ignored) {
        }
    }

    private GradientDrawable dot(int color, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        g.setStroke(dp(strokeDp), 0xFFFFFFFF);
        return g;
    }

    private LinearLayout buildPanel() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackgroundDrawable(round(C_CARD, 16));
        p.setPadding(dp(14), dp(12), dp(14), dp(12));
        p.setElevation(dp(8));
        p.setMinimumWidth(panelWidth());

        TextView title = new TextView(this);
        title.setText("CK广告助手");
        title.setTextSize(13);
        title.setTextColor(C_TEXT);
        p.addView(title);

        TextView sub = new TextView(this);
        sub.setText("改完立即生效，无需重启目标应用");
        sub.setTextSize(10);
        sub.setTextColor(C_SUB);
        sub.setPadding(0, dp(2), 0, dp(4));
        p.addView(sub);

        // 运行状态：绿点 = eCPM 最近 3 分钟有改写，灰点 = 没有
        LinearLayout st = new LinearLayout(this);
        st.setOrientation(LinearLayout.HORIZONTAL);
        st.setGravity(Gravity.CENTER_VERTICAL);
        statusDot = new View(this);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp(8), dp(8));
        dotLp.rightMargin = dp(5);
        st.addView(statusDot, dotLp);
        tvStatus = new TextView(this);
        tvStatus.setTextSize(10);
        tvStatus.setTextColor(C_SUB);
        tvStatus.setLineSpacing(dp(3), 1f);
        // 窄屏上状态文字不能把面板顶宽，限一下宽度让它自己折行
        tvStatus.setMaxWidth(Math.max(dp(120), panelWidth() - dp(30)));
        st.addView(tvStatus);
        LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stLp.bottomMargin = dp(6);
        p.addView(st, stLp);
        paintedDot = 0;
        paintStatus();

        p.addView(label("广告加速"));
        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        bSpeedY = chip("是");
        bSpeedN = chip("否");
        r1.addView(bSpeedY, chipLp(0));
        r1.addView(bSpeedN, chipLp(dp(6)));
        p.addView(r1);

        p.addView(label("智能调速"));
        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        bSmartY = chip("是");
        bSmartN = chip("否");
        r2.addView(bSmartY, chipLp(0));
        r2.addView(bSmartN, chipLp(dp(6)));
        p.addView(r2);

        View line = new View(this);
        line.setBackgroundColor(C_LINE);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        llp.topMargin = dp(10);
        llp.bottomMargin = dp(8);
        p.addView(line, llp);

        LinearLayout ops = new LinearLayout(this);
        ops.setOrientation(LinearLayout.HORIZONTAL);
        TextView open = textBtn("打开助手");
        open.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    Intent i = new Intent(FloatService.this, MainActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                    collapse();
                } catch (Throwable ignored) {
                }
            }
        });
        TextView close = textBtn("关闭悬浮窗");
        close.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sp.edit().putBoolean("float_on", false).apply();
                stopSelf();
            }
        });
        ops.addView(open, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        ops.addView(close);
        p.addView(ops);

        bindChips();
        return p;
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(11);
        t.setTextColor(C_SUB);
        t.setPadding(0, dp(9), 0, dp(5));
        return t;
    }

    private TextView chip(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(20), dp(6), dp(20), dp(6));
        return t;
    }

    private LinearLayout.LayoutParams chipLp(int left) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.leftMargin = left;
        return p;
    }

    private TextView textBtn(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(11);
        t.setTextColor(C_TEXT);
        t.setPadding(dp(6), dp(8), dp(6), dp(4));
        return t;
    }

    private void bindChips() {
        bSpeedY.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setCfg(true, null);
            }
        });
        bSpeedN.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setCfg(false, null);
            }
        });
        bSmartY.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setCfg(null, true);
            }
        });
        bSmartN.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setCfg(null, false);
            }
        });
        paintChips();
    }

    /** 只改传进来的那一项，另一项保持不变 */
    private void setCfg(Boolean speed, Boolean smart) {
        try {
            SharedPreferences.Editor e = sp.edit();
            if (speed != null) e.putBoolean("speed_enabled", speed.booleanValue());
            if (smart != null) e.putBoolean("smart_enabled", smart.booleanValue());
            e.commit();
            paintChips();
        } catch (Throwable ignored) {
        }
    }

    private void paintChips() {
        boolean s = sp.getBoolean("speed_enabled", true);
        boolean m = sp.getBoolean("smart_enabled", true);
        paint(bSpeedY, s);
        paint(bSpeedN, !s);
        paint(bSmartY, m);
        paint(bSmartN, !m);
    }

    private void paint(TextView t, boolean on) {
        t.setBackgroundDrawable(round(on ? accent() : C_OFF, 9));
        t.setTextColor(on ? 0xFFFFFFFF : C_SUB);
    }

    private void togglePanel() {
        if (panel == null) return;
        if (panel.getVisibility() == View.VISIBLE) {
            collapse();
        } else {
            paintChips();
            paintStatus();
            panel.setVisibility(View.VISIBLE);
            // 球贴在屏幕右下角时，面板会顶出可视区，展开前先把窗口挪回屏内
            try {
                int[] sc = screen();
                int sw = sc[0];
                int sh = sc[1];
                // 实测比估算准：状态行是两行、不同 ROM 行高也不同
                panel.measure(View.MeasureSpec.makeMeasureSpec(0,
                                View.MeasureSpec.UNSPECIFIED),
                        View.MeasureSpec.makeMeasureSpec(0,
                                View.MeasureSpec.UNSPECIFIED));
                int needW = Math.max(panelWidth(), panel.getMeasuredWidth()) + dp(8);
                int needH = panel.getMeasuredHeight() + ballSize() + dp(16);
                boolean moved = false;
                if (lp.x + needW > sw) {
                    lp.x = Math.max(0, sw - needW);
                    moved = true;
                }
                if (lp.y + needH > sh) {
                    lp.y = Math.max(0, sh - needH);
                    moved = true;
                }
                if (moved) wm.updateViewLayout(root, lp);
            } catch (Throwable ignored) {
            }
        }
    }

    private void collapse() {
        try {
            if (panel != null) panel.setVisibility(View.GONE);
        } catch (Throwable ignored) {
        }
    }

    // ---------------- 拖动 ----------------

    private void bindDrag(final View handle) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;
            long lastFrame;

            public boolean onTouch(View v, MotionEvent e) {
                if (lp == null) return false;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = lp.x;
                        startY = lp.y;
                        moved = false;
                        lastFrame = 0L;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (e.getRawX() - downX);
                        int dy = (int) (e.getRawY() - downY);
                        if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) moved = true;
                        if (moved) {
                            lp.x = startX + dx;
                            lp.y = startY + dy;
                            clamp();
                            // 触摸事件比屏幕刷新密得多，每帧一次 updateViewLayout 就够，
                            // 否则窗口合成线程被刷爆，滑动会发涩
                            long now = SystemClock.uptimeMillis();
                            if (now - lastFrame >= 16L) {
                                lastFrame = now;
                                update();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (moved) {
                            update();
                            sp.edit().putInt("float_x", lp.x).putInt("float_y", lp.y).apply();
                        } else {
                            togglePanel();
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void clamp() {
        try {
            int[] sc = screen();
            int sw = sc[0];
            int sh = sc[1];
            int keep = dp(24);
            if (lp.x < -keep) lp.x = -keep;
            if (lp.y < -keep) lp.y = -keep;
            if (lp.x > sw - keep) lp.x = sw - keep;
            if (lp.y > sh - keep) lp.y = sh - keep;
        } catch (Throwable ignored) {
        }
    }

    private void update() {
        try {
            wm.updateViewLayout(root, lp);
        } catch (Throwable ignored) {
        }
    }

    // ---------------- 屏幕适配 ----------------

    /**
     * 当前可用屏幕尺寸（px）。
     * 优先用 API 30 的 WindowMetrics：分屏、折叠屏展开、旋转之后它都是新值；
     * 取不到再退 getRealMetrics，最后退资源里的 DisplayMetrics。
     */
    private int[] screen() {
        int w = 0, h = 0;
        try {
            if (Build.VERSION.SDK_INT >= 30 && wm != null) {
                android.graphics.Rect b = wm.getCurrentWindowMetrics().getBounds();
                w = b.width();
                h = b.height();
            }
        } catch (Throwable ignored) {
        }
        if (w <= 0 || h <= 0) {
            try {
                android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
                if (wm != null) wm.getDefaultDisplay().getRealMetrics(dm);
                w = dm.widthPixels;
                h = dm.heightPixels;
            } catch (Throwable ignored) {
            }
        }
        if (w <= 0 || h <= 0) {
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            w = dm.widthPixels;
            h = dm.heightPixels;
        }
        return new int[]{w, h};
    }

    /** 球径跟着屏幕宽度走：小屏 46dp，常规 52dp，平板 58dp */
    private int ballDp() {
        int sw = 360;
        try {
            sw = getResources().getConfiguration().screenWidthDp;
        } catch (Throwable ignored) {
        }
        if (sw < 340) return 46;
        if (sw >= 600) return 58;
        return 52;
    }

    private int ballSize() {
        return dp(ballDp()) + dp(8);
    }

    /** 面板宽：最多 232dp，但窄屏上要让出两侧边距，不能顶出屏幕 */
    private int panelWidth() {
        int sw = screen()[0];
        int w = Math.min(dp(232), sw - dp(24));
        return Math.max(dp(168), w);
    }

    /** 首次摆放避开状态栏；读不到就用 24dp 兜底 */
    private int statusBarH() {
        try {
            int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
            if (id > 0) return getResources().getDimensionPixelSize(id);
        } catch (Throwable ignored) {
        }
        return dp(24);
    }

    @Override
    public void onConfigurationChanged(Configuration cfg) {
        super.onConfigurationChanged(cfg);
        // 旋转 / 分屏 / 折叠屏展开：窗口尺寸变了，原来的坐标可能已经在屏幕外
        try {
            collapse();
            clamp();
            update();
        } catch (Throwable ignored) {
        }
    }

    // ---------------- 小工具 ----------------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private GradientDrawable circle(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        g.setStroke(dp(1), 0x33FFFFFF);
        return g;
    }

    private void toast(String s) {
        try {
            Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) {
        }
    }
}
