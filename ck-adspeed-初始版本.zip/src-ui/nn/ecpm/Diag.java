package nn.ecpm;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.File;

/**
 * 运行状态探针 + 日志裁剪。界面层和悬浮窗共用，不参与 hook 判定。
 *
 * 为什么需要这一层：
 *
 * 1）「eCPM 在不在跑」不能靠猜进程。EcpmHook.emit 会往 nn.ecpm.LOG 发广播，
 *    但 Android 8.0 起跨应用的**隐式广播**送不到静态注册的接收器，界面关掉就收不到，
 *    于是状态灯一直是灰的（v26 的问题）。
 *    这里换成一个一定成立的信号：EcpmHook 每次改写都会 ContentResolver.insert
 *    到 content://nn.ecpm.config/log，ConfigProvider 把日志写进
 *    shared_prefs/logbuf.xml —— 这个文件的修改时间就是「最后一次改写」。
 *    读文件属性不涉及跨进程通信，也不需要改 hook 一行代码。
 *
 * 2）日志要能自动清。用户要求「超过某个数字就删除」。上限存在 config.log_cap，
 *    默认 2000 行；裁剪按行而不是按字符，避免把一行截成半个汉字。
 */
final class Diag {

    static final String PREF = "config";
    static final String PREF_LOG = "logbuf";

    /** 默认保留行数 */
    static final int CAP_DEFAULT = 2000;
    /** 字符硬上限：单行特别长时兜底，防止一个 xml 值撑到几百 KB */
    static final int CAP_CHARS = 40000;
    /** 文件属性读不到时的兜底时间窗口（毫秒） */
    static final long WIN_ECPM = 180000L;

    /**
     * 日志是「读旧值 → 拼接 → 写回」，LogReceiver、界面的裁剪逻辑都会碰 config.buf。
     * 两边不在同一个线程，必须共用一把锁，否则裁剪正好插在中间时，
     * 刚写进来的那条会被裁剪用的旧快照覆盖掉。
     */
    static final Object LOCK = new Object();

    private Diag() {
    }

    // ---------------- 日志上限 ----------------

    static int cap(SharedPreferences sp) {
        int v = CAP_DEFAULT;
        try {
            v = sp.getInt("log_cap", CAP_DEFAULT);
        } catch (Throwable ignored) {
        }
        if (v < 100) v = 100;
        if (v > 20000) v = 20000;
        return v;
    }

    /**
     * 保留最后 maxLines 行，同时不超过 maxChars 字符。
     * 从尾部往前数换行，不用 split（split 两万字会产生上千个临时 String）。
     */
    static String trim(String s, int maxLines, int maxChars) {
        if (s == null || s.length() == 0) return "";
        String r = s;
        if (r.length() > maxChars) {
            int i = r.indexOf('\n', r.length() - maxChars);
            r = (i >= 0) ? r.substring(i + 1) : r.substring(r.length() - maxChars);
        }
        if (maxLines > 0) {
            // 末尾那个换行不算新的一行，否则「保留 2000 行」实际只留 1999 行
            int last = r.length();
            if (last > 0 && r.charAt(last - 1) == '\n') last--;
            int n = 0;
            for (int i = last - 1; i >= 0; i--) {
                if (r.charAt(i) == '\n') {
                    n++;
                    if (n >= maxLines) return r.substring(i + 1);
                }
            }
        }
        return r;
    }

    /** 文本里有几行（末尾换行不算一行） */
    static int lines(String s) {
        if (s == null) return 0;
        int n = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '\n') n++;
        }
        return n + (s.length() > 0 && s.charAt(s.length() - 1) != '\n' ? 1 : 0);
    }

    // ---------------- 运行状态 ----------------

    /**
     * shared_prefs 下某个文件最后一次被写入的时间。
     * 文件的父目录就是 /data/data/<pkg>，不用拼包名，改包名也不会失效。
     */
    static long mtime(Context c, String prefsName) {
        if (c == null) return 0L;
        try {
            File dir = new File(c.getFilesDir().getParentFile(), "shared_prefs");
            File f = new File(dir, prefsName + ".xml");
            if (!f.isFile()) return 0L;
            return f.lastModified();
        } catch (Throwable t) {
            return 0L;
        }
    }

    /**
     * eCPM 最后一次改写的时间。
     * 取「广播收到的时间戳」和「logbuf.xml 的修改时间」里更晚的那个：
     *  - 界面开着时广播能收到，时间戳更精确；
     *  - 界面关着 / 悬浮窗里，广播收不到，看文件属性。
     */
    static long ecpmLast(Context c, SharedPreferences sp) {
        long a = 0L;
        try {
            a = sp.getLong("ecpm_ts", 0L);
        } catch (Throwable ignored) {
        }
        long b = mtime(c, PREF_LOG);
        return Math.max(a, b);
    }

    /** 加速内核最后一次活动：只有广播这条链路，收不到就是 0 */
    static long tickLast(SharedPreferences sp) {
        try {
            return sp.getLong("tick_ts", 0L);
        } catch (Throwable t) {
            return 0L;
        }
    }

    /**
     * 时间戳转「多久以前」。允许一点时钟回拨（系统对时、跨时区），
     * 负数一律当刚刚，不要显示 -3 分钟。
     */
    static long ago(long ts) {
        if (ts <= 0) return Long.MAX_VALUE;
        long d = System.currentTimeMillis() - ts;
        return d < 0 ? 0 : d;
    }

    static boolean fresh(long ts, long win) {
        long d = ago(ts);
        return d != Long.MAX_VALUE && d < win;
    }

    static String agoText(long ts) {
        long d = ago(ts);
        if (d == Long.MAX_VALUE) return "从未";
        if (d < 5000L) return "刚刚";
        if (d < 60000L) return (d / 1000L) + " 秒前";
        if (d < 3600000L) return (d / 60000L) + " 分钟前";
        if (d < 86400000L) return (d / 3600000L) + " 小时前";
        return (d / 86400000L) + " 天前";
    }
}
