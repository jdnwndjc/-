package nn.ecpm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

/**
 * 静态日志接收器。
 *
 * 以前日志只靠 MainActivity 里的动态广播接收器落地，界面没开的时候
 * 目标应用发过来的日志全部丢掉 —— 也就是「运行日志一直是空的」。
 * 这里改成清单里注册，界面关掉也照收，界面的那个接收器只负责刷新显示。
 *
 * 来源区分（v22 修正）：
 *  EcpmHook.emit 也是往 nn.ecpm.LOG 发广播，msg 是不带 "[EcpmRange] " 前缀的原文
 *  （那个前缀只加在 XposedBridge.log 那一行上），所以以前用 startsWith("[EcpmRange]")
 *  去重永远不成立，eCPM 日志会被同时写进 config.buf ——
 *  界面上同一段记录出现两遍。
 *  现在内核广播带 src=tick 标记，只认带了标记的；老版本内核没有标记时退回内容前缀判断。
 *
 * v26 卡顿修复：以前每来一条日志就 getString(2 万字) + 拼接 + commit 一次，
 * 目标应用频繁发日志时，助手进程主线程被磁盘 IO 拖住（切页、滚动都在这个线程）。
 * 现在先进内存缓冲，250ms 落一次盘，写盘次数从「每条一次」降到「每秒最多 4 次」，
 * 同时把 tick_ts（加速内核最后一次活动时间）一起写进去，供界面判断运行状态。
 */
public class LogReceiver extends BroadcastReceiver {

    /** 字符硬上限（行数上限在 Diag.cap() 里读配置，默认 2000 行） */
    private static final int MAX = Diag.CAP_CHARS;
    /** 合并窗口：这段时间内的日志攒在一起写一次 */
    private static final long FLUSH_MS = 250;
    private static final String PREF = Diag.PREF;

    /** 待落盘的增量，只在 synchronized 内读写 */
    private static final StringBuilder PENDING = new StringBuilder();
    private static Handler handler;
    private static Runnable flushTask;
    private static boolean scheduled;
    /** 本次窗口内有没有加速日志（决定要不要更新 tick_ts） */
    private static boolean pendingTick;
    /** 本次窗口内有没有 eCPM 改写（决定要不要更新 ecpm_ts） */
    private static boolean pendingEcpm;
    private static Context appCtx;

    @Override
    public void onReceive(Context c, Intent i) {
        if (c == null || i == null) return;
        try {
            String m = i.getStringExtra("msg");
            if (m == null || m.length() == 0) return;

            String src = null;
            try {
                src = i.getStringExtra("src");
            } catch (Throwable ignored) {
            }
            boolean tick = "tick".equals(src);
            if (!tick) {
                // 兼容没带标记的旧内核：加速日志只会是这两种开头
                if (m.startsWith("FastTick") || m.startsWith("cfg:")) {
                    tick = true;
                } else {
                    // eCPM 的 emit 不带 src，到这里就是"刚刚改写过一条"。
                    // 只更新时间戳，正文已经在 logbuf 里了，不能重复入 buf。
                    synchronized (PENDING) {
                        pendingEcpm = true;
                        appCtx = c.getApplicationContext();
                    }
                    schedule();
                    return;
                }
            }

            synchronized (PENDING) {
                PENDING.append(m).append('\n');
                // 缓冲本身也要封顶：目标应用短时间刷几千条时，
                // 不能等落盘才发现超了，内存里先削一次
                if (PENDING.length() > MAX) {
                    String cut = Diag.trim(PENDING.toString(), 0, MAX);
                    PENDING.setLength(0);
                    PENDING.append(cut);
                }
                if (tick) pendingTick = true;
                appCtx = c.getApplicationContext();
            }
            schedule();
        } catch (Throwable ignored) {
        }
    }

    /**
     * 第一次进来才挂任务，之后的日志只是往缓冲里追加。
     * 不能每次 removeCallbacks + postDelayed：日志连发时会一直推迟，永远不落盘。
     */
    private static void schedule() {
        synchronized (PENDING) {
            if (scheduled) return;
            scheduled = true;
        }
        if (handler == null) handler = new Handler(Looper.getMainLooper());
        if (flushTask == null) {
            flushTask = new Runnable() {
                public void run() {
                    drain();
                }
            };
        }
        handler.postDelayed(flushTask, FLUSH_MS);
    }

    private static void drain() {
        String add;
        boolean tick;
        boolean ecpm;
        Context ctx;
        synchronized (PENDING) {
            add = PENDING.toString();
            PENDING.setLength(0);
            tick = pendingTick;
            pendingTick = false;
            ecpm = pendingEcpm;
            pendingEcpm = false;
            scheduled = false;
            ctx = appCtx;
        }
        if (ctx == null || (add.length() == 0 && !tick && !ecpm)) return;
        // 落盘再往后台放一层：commit 要写整个 xml，放在广播接收器里就是写主线程
        final Context c = ctx;
        final String a = add;
        final boolean t = tick;
        final boolean e2 = ecpm;
        io().execute(new Runnable() {
            public void run() {
                write(c, a, t, e2);
            }
        });
    }

    private static void write(Context ctx, String add, boolean tick, boolean ecpm) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences(PREF, 0);
            // 和界面里的裁剪互斥，避免「读旧值-写回」把刚进来的日志盖掉
            synchronized (Diag.LOCK) {
                SharedPreferences.Editor e = sp.edit();
                if (add.length() > 0) {
                    String old = sp.getString("buf", "");
                    // v27：行数上限可配（报告页可改），超了就丢最旧的整行
                    e.putString("buf", Diag.trim((old == null ? "" : old) + add,
                            Diag.cap(sp), MAX));
                    // 加速统计行单独存一份：日志会被裁剪/被 eCPM 那 2 万字上限挤掉，
                    // 但「到底有没有加速」这条结论必须一直留着
                    String stat = lastStat(add);
                    if (stat != null) {
                        e.putString("speed_stat", stat);
                        e.putLong("speed_ts", System.currentTimeMillis());
                    }
                }
                long now = System.currentTimeMillis();
                if (tick) e.putLong("tick_ts", now);
                if (ecpm) e.putLong("ecpm_ts", now);
                // 后台线程 commit：既落盘了，也不阻塞 UI
                e.commit();
            }
        } catch (Throwable ignored) {
        }
    }

    /** 本批日志里最后一条「tick: ...」统计，没有就返回 null */
    private static String lastStat(String add) {
        if (add == null) return null;
        try {
            int i = add.lastIndexOf("tick: ");
            if (i < 0) return null;
            // 只认行首（避免 "cfg: ..." 之类里刚好含这几个字）
            if (i > 0 && add.charAt(i - 1) != '\n') return null;
            int j = add.indexOf('\n', i);
            String line = j < 0 ? add.substring(i) : add.substring(i, j);
            return line.length() > 160 ? line.substring(0, 160) : line;
        } catch (Throwable t) {
            return null;
        }
    }

    private static java.util.concurrent.ExecutorService IO;

    private static java.util.concurrent.ExecutorService io() {
        synchronized (PENDING) {
            if (IO == null) IO = java.util.concurrent.Executors.newSingleThreadExecutor();
            return IO;
        }
    }
}
