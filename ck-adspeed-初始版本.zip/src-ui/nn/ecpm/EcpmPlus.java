package nn.ecpm;

import android.app.Application;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.SystemClock;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Locale;
import java.util.Random;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * eCPM 补充层（v34）。
 *
 * <p>EcpmHook 那份（classes6.dex，原包自带）只认三种情况：**无参**方法、
 * 方法名里含 cpm、返回 String / int / long / double / float。它管不到的空白有三块：
 *
 * <ol>
 *   <li>带参数的取值方法，例如 {@code getEcpm(int adType)}、{@code getEcpm(String adn)}，
 *       它的 findMethod 只找无参重载，这类直接漏掉；</li>
 *   <li>不叫 cpm 的价格方法，例如 {@code getPrice()}、{@code getBidPrice()}、
 *       {@code getRevenue()}、{@code getPayout()}，这些在海外 SDK 和聚合层很常见；</li>
 *   <li>返回 {@link BigDecimal} 的 eCPM，它的 apply 只按 String / 数值分支处理，
 *       BigDecimal 走不到任何分支，hook 挂上了但值不变。</li>
 * </ol>
 *
 * <p>这个类只补这三块，且**刻意避开** EcpmHook 已经完整覆盖的组合
 * （无参 + 名字含 cpm + 非 BigDecimal），所以同一个方法不会被改两次。
 * EcpmHook 与加速内核一个字节都没动，这一层单独编在界面 dex 里，
 * 走 xposed_init 第三行入口。
 *
 * <p>取值区间与主 hook 共用同一个配置（content://nn.ecpm.config/config 的 min / max / skip），
 * 用户在外观页改区间，这边 15 秒内跟着变。
 *
 * <p>v35 补了四件事：
 * <ul>
 *   <li><b>把新配置推回主 hook</b>：EcpmHook 只在启动时读一次配置，之后再不重读，
 *       所以以前在外观页改完区间、目标 App 不重启是根本不生效的（界面还提示"最多 10 秒读到"）。
 *       这里 hook 它的 emit 拿到实例，每 10 秒比对一次 provider，变了就反射写回它的三个字段，
 *       等于替它做热更新，不用改它一个字节；</li>
 *   <li>日志节流：原来每改一次就跨进程 insert 一条，列表滚动时等于每条都做一次 IPC；</li>
 *   <li>类加载重入时不再直接丢弃，先进队列由当前线程补扫；</li>
 *   <li>纯「无参 + 含 cpm + 普通数值」的方法，如果类名不在主 hook 的前缀/关键字范围里，
 *       以前两边都让开、谁都不改，现在由这一层接管。</li>
 * </ul>
 */
public class EcpmPlus implements IXposedHookLoadPackage {

    private static final String URI_CFG = "content://nn.ecpm.config/config";
    private static final String URI_LOG = "content://nn.ecpm.config/log";

    /** 15 秒最多重读一次配置：hook 回调跑在广告线程上，不能每次都去 query */
    private static final long CFG_TTL = 15000L;

    /** 10 秒往主 hook 推一次配置，跟界面上写的「最多 10 秒读到」对上 */
    private static final long SYNC_MS = 10000L;

    /**
     * 补充的 SDK 包前缀（全小写）。EcpmHook 那份列了 50 多个主流前缀，
     * 这里补它没列的：字节 mSDK / Pangle 独立包、快手、以及一批海外与聚合平台。
     */
    private static final String[] PKG_PREFIX = {
            "com.bytedance.msdk.", "com.bytedance.pangle.", "com.pangle.",
            "com.tencent.gdt.", "com.kuaishou.", "com.kwai.",
            "com.unity3d.services.ads.", "com.hihonor.ads.",
            "com.moloco.", "com.criteo.", "com.taboola.", "com.outbrain.",
            "com.teads.", "com.smartadserver.", "com.digitalturbine.",
            "com.liftoff.", "com.yandex.mobile.ads.", "com.amazon.aps.",
            "com.smaato.", "com.fyber.", "com.tapjoy.", "com.startapp.",
            "com.verizon.", "com.ogury.", "com.pubnative.", "com.appnext.",
            "com.bigo.", "com.opera.", "com.supersonic.", "com.adcolony.",
            "com.my.target.", "com.aiming.mdt.", "com.corpuse.", "com.supertool."
    };

    /** 类名关键字：包名看不出是广告、但类名一看就知道的地方（聚合层最爱这么命名） */
    private static final String[] NAME_HINT = {
            "adunit", "adinfo", "adloader", "adrequest", "adresponse", "advalue",
            "adsdk", "advert", "mediation", "monet", "reward", "interstitial",
            "nativead", "bannerad", "splashad", "feedad"
    };

    /**
     * EcpmHook 自己那份前缀表（原包 classes2.dex 里那 52 条），只用来判断
     * 「这个类主 hook 会不会自己扫到」。这里不参与挂 hook，重复一份是为了
     * 决定要不要让开，避免同一个方法被两层各改一遍。
     */
    private static final String[] MAIN_PREFIX = {
            "com.baidu.mobads.", "com.qq.e.", "com.kwad.", "com.sigmob.", "com.bytedance.",
            "com.pangle.", "com.pgl.", "com.ss.android.", "com.bykv.", "com.anythink.",
            "com.adsuyi.", "com.mintegral.", "com.mbridge.", "com.tanx.", "com.alimama.",
            "com.alibaba.sdk.android.", "com.gdt.", "com.adview.", "com.upltv.", "com.apusapps.",
            "com.huawei.hms.ads.", "com.huawei.hms.adsengine.", "com.xiaomi.ad.",
            "com.xiaomi.miplay.", "com.miui.zeus.", "com.oppo.", "com.oplus.", "com.heytap.",
            "com.coloros.", "com.vivo.", "com.vivo.ad.", "com.google.android.gms.ads.",
            "com.unity3d.ads.", "com.ironsource.", "com.applovin.", "com.vungle.",
            "com.inmobi.", "com.mopub.", "com.startapp.", "com.amazon.device.ads.",
            "com.tapjoy.", "com.fyber.", "com.fairbid.", "com.smaato.", "com.chartboost.",
            "com.supersonic.", "com.adcolony.", "com.my.target.", "com.tradplus.",
            "com.aiming.mdt.", "com.corpuse.", "com.supertool."
    };

    private static final Set<String> MONEY_TYPES = new HashSet<String>();

    static {
        MONEY_TYPES.add("int");
        MONEY_TYPES.add("java.lang.Integer");
        MONEY_TYPES.add("long");
        MONEY_TYPES.add("java.lang.Long");
        MONEY_TYPES.add("double");
        MONEY_TYPES.add("java.lang.Double");
        MONEY_TYPES.add("float");
        MONEY_TYPES.add("java.lang.Float");
        MONEY_TYPES.add("java.lang.String");
        MONEY_TYPES.add("java.math.BigDecimal");
    }

    private Context appCtx;
    private long min = 100000L;
    private long max = 130000L;
    private boolean skipNonPositive = true;
    private long cfgAt = 0L;

    private final Random rnd = new Random();
    /** 已经处理过的类，避免 loadClass 两个重载重复进来、也防反射触发递归 */
    private final Set<String> seen = new HashSet<String>();
    /** 反射 getDeclaredMethods 时可能反过来触发类加载，重入时先进这里，由当前线程补扫 */
    private final java.util.concurrent.ConcurrentLinkedQueue<Class<?>> pending =
            new java.util.concurrent.ConcurrentLinkedQueue<Class<?>>();
    private volatile boolean busy = false;

    /** 日志节流：key = 类.方法，value = 已改写次数（主 hook 也是这个口径） */
    private final java.util.concurrent.ConcurrentHashMap<String, Integer> cnt =
            new java.util.concurrent.ConcurrentHashMap<String, Integer>();

    /** EcpmHook 的实例，从它的 emit 回调里拿；拿到之后才能给它推新配置 */
    private volatile Object mainHook;
    private final java.util.concurrent.atomic.AtomicBoolean syncOn =
            new java.util.concurrent.atomic.AtomicBoolean(false);
    private java.lang.reflect.Field fMin, fMax, fSkip;

    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) throws Throwable {
        if (!watch(lp.packageName)) return;

        // 拿进程级 Context：配置从 provider 读，日志也写回 provider。
        // 不用 XposedHelpers.findAndHookMethod（编译期的 stub 里没有这个重载），
        // 直接 hookAllMethods 再自己认参数，两种重载都能兜住
        try {
            XposedBridge.hookAllMethods(Application.class, "attach", new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        if (p.args.length < 1 || !(p.args[0] instanceof Context)) return;
                        appCtx = (Context) p.args[0];
                        loadConfig();
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable ignored) {
        }

        // 主 hook 的配置热更新：hook 它的 emit 只为了拿实例，日常不再挂别的方法
        watchMainHook(lp.classLoader);

        // 广告类基本都在 Application 起来之后按需加载，谁进来就挂谁
        try {
            XposedBridge.hookAllMethods(ClassLoader.class, "loadClass", new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        Object r = p.getResult();
                        if (!(r instanceof Class)) return;
                        Class<?> c = (Class<?>) r;
                        if (!looksLikeAd(c.getName())) return;
                        // 先入队，被重入挡掉也不会丢：谁拿到 busy 谁负责把这批扫完
                        pending.add(c);
                        drain();
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("EcpmPlus: hook loadClass 失败 " + t);
        }
    }

    /** 不碰系统界面、自己、Root / 框架自身，也不碰微信（与加速侧保持一致） */
    private static boolean watch(String pkg) {
        if (pkg == null || pkg.length() == 0) return false;
        if ("android".equals(pkg) || "com.android.systemui".equals(pkg)) return false;
        if ("nn.ecpm".equals(pkg)) return false;
        if (pkg.startsWith("com.topjohnwu.") || pkg.startsWith("de.robv.")) return false;
        if (pkg.contains("lsposed") || pkg.contains("xposed")) return false;
        if ("com.tencent.mm".equals(pkg)) return false;
        return true;
    }

    // ---------------- 主 hook 配置热更新 ----------------

    /**
     * 主 hook 只在启动时读一次配置，之后永远用老区间 —— 用户在外观页改完，
     * 目标 App 不重启是不生效的。这里 hook 它的 emit，只为拿到实例引用。
     * emit 是 private，hookAllMethods 能挂；挂不上就静默降级，不影响别的功能。
     */
    private void watchMainHook(final ClassLoader cl) {
        try {
            Class<?> ec = Class.forName("nn.ecpm.EcpmHook", false, cl);
            XposedBridge.hookAllMethods(ec, "emit", new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam p) {
                    if (mainHook == null) {
                        Object self = p.thisObject;
                        if (self == null) return;
                        mainHook = self;
                    }
                    // emit 会在多个广告线程上并发进来，线程只许起一个
                    if (syncOn.compareAndSet(false, true)) startCfgSync();
                }
            });
        } catch (Throwable ignored) {
            // 拿不到实例就算了，主 hook 还是按老行为走，不影响改写本身
        }
    }

    private void startCfgSync() {
        Thread t = new Thread(new Runnable() {
            public void run() {
                for (; ; ) {
                    try {
                        Thread.sleep(SYNC_MS);
                    } catch (InterruptedException e) {
                        return;
                    }
                    try {
                        syncOnce();
                    } catch (Throwable ignored) {
                    }
                }
            }
        });
        t.setName("EcpmPlus-sync");
        t.setDaemon(true);
        t.start();
    }

    /** 读 provider，跟主 hook 当前字段比，不一样就写回去 */
    private void syncOnce() {
        Object h = mainHook;
        if (h == null) return;
        long[] cfg = readCfg();
        if (cfg == null) return;
        try {
            if (fMin == null) fMin = anyField(h, "ecpmMin");
            if (fMax == null) fMax = anyField(h, "ecpmMax");
            if (fSkip == null) fSkip = anyField(h, "skipNonPositive");
            boolean sk = cfg[2] != 0;
            if (fMin.getLong(h) != cfg[0]) fMin.setLong(h, cfg[0]);
            if (fMax.getLong(h) != cfg[1]) fMax.setLong(h, cfg[1]);
            if (fSkip.getBoolean(h) != sk) fSkip.setBoolean(h, sk);
        } catch (Throwable ignored) {
        }
    }

    private static java.lang.reflect.Field anyField(Object o, String name) throws Exception {
        java.lang.reflect.Field f = o.getClass().getDeclaredField(name);
        f.setAccessible(true);
        return f;
    }

    /** @return {min, max, skip?1:0}，读不到返回 null */
    private long[] readCfg() {
        Context ctx = appCtx;
        if (ctx == null) return null;
        Cursor c = null;
        long[] r = null;
        try {
            c = ctx.getContentResolver().query(Uri.parse(URI_CFG), null, null, null, null);
            if (c == null) return null;
            long mn = -1L, mx = -1L;
            int sk = -1;
            while (c.moveToNext()) {
                String k = c.getString(0);
                String v = c.getString(1);
                if (k == null || v == null) continue;
                if ("min".equals(k)) {
                    mn = Long.parseLong(v.trim());
                } else if ("max".equals(k)) {
                    mx = Long.parseLong(v.trim());
                } else if ("skip".equals(k)) {
                    sk = ("1".equals(v.trim()) || "true".equalsIgnoreCase(v.trim())) ? 1 : 0;
                }
            }
            if (mn >= 0 && mx >= 0) r = new long[]{mn, mx, sk < 0 ? 1 : sk};
        } catch (Throwable ignored) {
        } finally {
            if (c != null) {
                try {
                    c.close();
                } catch (Throwable ignored) {
                }
            }
        }
        return r;
    }

    // ---------------- 类 / 方法筛选 ----------------

    private static boolean looksLikeAd(String cn) {
        if (cn == null) return false;
        String n = cn.toLowerCase(Locale.US);
        // 系统与第三方框架的类先排掉，占类加载的绝大多数
        if (n.startsWith("java.") || n.startsWith("javax.") || n.startsWith("android.")
                || n.startsWith("androidx.") || n.startsWith("kotlin.")
                || n.startsWith("com.android.") || n.startsWith("dalvik.")
                || n.startsWith("sun.") || n.startsWith("org.apache.")) return false;
        for (int i = 0; i < PKG_PREFIX.length; i++) {
            if (n.startsWith(PKG_PREFIX[i])) return true;
        }
        for (int i = 0; i < NAME_HINT.length; i++) {
            if (n.indexOf(NAME_HINT[i]) >= 0) return true;
        }
        return false;
    }

    /**
     * 主 hook 会不会自己扫这个类（前缀表 + 它那套类名关键字）。
     * 只影响「要不要让开」，不影响我们自己挂不挂别的类型。
     */
    static boolean mainCovers(String cn) {
        if (cn == null || cn.length() == 0) return false;
        String n = cn.toLowerCase(Locale.US);
        for (int i = 0; i < MAIN_PREFIX.length; i++) {
            if (n.startsWith(MAIN_PREFIX[i])) return true;
        }
        return n.indexOf("ads") >= 0 || n.indexOf(".ad.") >= 0 || n.indexOf("monet") >= 0
                || n.indexOf("reward") >= 0 || n.indexOf("mediation") >= 0
                || n.indexOf("msdk") >= 0 || n.indexOf("bid") >= 0 || n.indexOf("adx") >= 0
                || n.indexOf("splash") >= 0 || n.indexOf("cpm") >= 0;
    }

    /**
     * 要不要挂这个方法。抽成纯函数是为了能在 JVM 上单独跑断言，不依赖真机。
     *
     * @param name   方法名
     * @param argc   参数个数
     * @param rt     返回类型全名，如 "int"、"java.lang.String"、"java.math.BigDecimal"
     * @param isStat 是否静态方法
     */
    static boolean wantHook(String name, int argc, String rt, boolean isStat) {
        // 四参版本按「主 hook 管得到」处理，保持 v34 的语义，老断言仍可用
        return wantHook(name, argc, rt, isStat, true);
    }

    /**
     * @param mainHandles 这个类是否落在主 hook 的扫描范围里。落进去才让开，
     *                    没落进去就是它的盲区，无参 cpm 也得我们来改，否则谁都不动。
     */
    static boolean wantHook(String name, int argc, String rt, boolean isStat, boolean mainHandles) {
        if (name == null || rt == null) return false;
        if (!MONEY_TYPES.contains(rt)) return false;
        String n = name.toLowerCase(Locale.US);
        // 只认取值方法：getXxx / priceXxx / ecpmXxx。set / is / to 一律不碰
        if (!n.startsWith("get") && !n.startsWith("price") && !n.startsWith("ecpm")) return false;
        boolean cpm = n.indexOf("cpm") >= 0;
        boolean money = n.indexOf("price") >= 0 || n.indexOf("bid") >= 0
                || n.indexOf("revenue") >= 0 || n.indexOf("income") >= 0
                || n.indexOf("payout") >= 0;
        if (!cpm && !money) return false;
        // 主 hook 完整覆盖的组合：只在它真的会扫这个类时才让开
        if (cpm && argc == 0 && !"java.math.BigDecimal".equals(rt) && mainHandles) return false;
        // 静态方法只在语义明确（名字带 cpm）时才碰，工具类的 getPrice() 可能是全局算价
        if (isStat && !cpm) return false;
        return true;
    }

    /**
     * 把队列里的类扫完。重入时直接返回，由当前持有 busy 的线程负责；
     * 放掉 busy 之后再查一次队列 —— 否则「刚 poll 到 null、另一个线程才入队」的那一个
     * 会永远留在队列里没人处理。
     */
    private void drain() {
        for (; ; ) {
            if (busy) return;
            busy = true;
            try {
                Class<?> x;
                while ((x = pending.poll()) != null) {
                    try {
                        hookClass(x);
                    } catch (Throwable ignored) {
                    }
                }
            } finally {
                busy = false;
            }
            if (pending.isEmpty()) return;
        }
    }

    private void hookClass(Class<?> c) {
        String cn;
        try {
            cn = c.getName();
        } catch (Throwable t) {
            return;
        }
        if (!seen.add(cn)) return;
        if (c.isInterface() || c.isArray() || c.isPrimitive()) return;
        if (Modifier.isAbstract(c.getModifiers())) return;
        // 主 hook 会不会自己扫这个类：会就让开，不会就由这一层全包
        final boolean mainHandles = mainCovers(cn);

        Method[] ms;
        try {
            ms = c.getDeclaredMethods();
        } catch (Throwable t) {
            return;
        }
        for (int i = 0; i < ms.length; i++) {
            Method m = ms[i];
            try {
                if (Modifier.isAbstract(m.getModifiers()) || m.isSynthetic() || m.isBridge()) continue;
                boolean isStat = Modifier.isStatic(m.getModifiers());
                if (!wantHook(m.getName(), m.getParameterTypes().length,
                        m.getReturnType().getName(), isStat, mainHandles)) continue;
                hookOne(m, m.getReturnType());
            } catch (Throwable ignored) {
            }
        }
    }

    private void hookOne(Method m, final Class<?> rt) {
        try {
            XposedBridge.hookMethod(m, new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        apply(p, rt);
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private void apply(XC_MethodHook.MethodHookParam p, Class<?> rt) {
        Object res = p.getResult();
        if (res == null) return;

        long v = next();
        if (rt == String.class) {
            String s = res.toString().trim();
            if (!num(s)) return;
            if (skipNonPositive && Double.parseDouble(s) <= 0) return;
            p.setResult(String.valueOf(v));
        } else if (rt == int.class || rt == Integer.class) {
            if (skipNonPositive && ((Number) res).intValue() <= 0) return;
            p.setResult(Integer.valueOf((int) v));
        } else if (rt == long.class || rt == Long.class) {
            if (skipNonPositive && ((Number) res).longValue() <= 0) return;
            p.setResult(Long.valueOf(v));
        } else if (rt == double.class || rt == Double.class) {
            if (skipNonPositive && ((Number) res).doubleValue() <= 0) return;
            p.setResult(Double.valueOf((double) v));
        } else if (rt == float.class || rt == Float.class) {
            if (skipNonPositive && ((Number) res).floatValue() <= 0) return;
            p.setResult(Float.valueOf((float) v));
        } else if (rt == BigDecimal.class) {
            if (skipNonPositive && ((BigDecimal) res).signum() <= 0) return;
            p.setResult(BigDecimal.valueOf(v));
        } else {
            return;
        }
        emit(p, res, v);
    }

    private static boolean num(String s) {
        if (s == null || s.length() == 0 || s.length() > 24) return false;
        int i = 0;
        if (s.charAt(0) == '-' || s.charAt(0) == '+') i = 1;
        boolean dot = false, digit = false;
        for (; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '.') {
                if (dot) return false;
                dot = true;
            } else if (c >= '0' && c <= '9') {
                digit = true;
            } else {
                return false;
            }
        }
        return digit;
    }

    private long next() {
        if (SystemClock.elapsedRealtime() - cfgAt > CFG_TTL) loadConfig();
        if (max <= min) return min;
        return min + (long) (rnd.nextDouble() * (max - min + 1));
    }

    private void loadConfig() {
        Context ctx = appCtx;
        if (ctx == null) return;
        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(Uri.parse(URI_CFG), null, null, null, null);
            while (c != null && c.moveToNext()) {
                String k = c.getString(0);
                String v = c.getString(1);
                if (k == null || v == null) continue;
                if ("min".equals(k)) {
                    min = Long.parseLong(v.trim());
                } else if ("max".equals(k)) {
                    max = Long.parseLong(v.trim());
                } else if ("skip".equals(k)) {
                    skipNonPositive = "1".equals(v.trim()) || "true".equalsIgnoreCase(v.trim());
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (c != null) {
                try {
                    c.close();
                } catch (Throwable ignored) {
                }
            }
        }
        if (min < 0) min = 0;
        if (max < min) max = min;
        cfgAt = SystemClock.elapsedRealtime();
    }

    /** 写回 App 的日志通道，报告页里能看到「补充 xxx 原值 -> 新值」 */
    private void emit(XC_MethodHook.MethodHookParam p, Object old, long v) {
        Context ctx = appCtx;
        if (ctx == null) return;
        try {
            String who = "?";
            if (p.method instanceof Method) {
                Method m = (Method) p.method;
                String cn = m.getDeclaringClass().getName();
                int dot = cn.lastIndexOf('.');
                if (dot > 0) cn = cn.substring(dot + 1);
                who = cn + "." + m.getName();
            }
            // 节流：同主 hook 的口径，头两次必记，之后每 100 次记一条。
            // 不节流的话，列表滚动时每个 item 一次 getter，等于每条都做一次跨进程 IPC
            Integer c0 = cnt.get(who);
            int n = c0 == null ? 1 : c0.intValue() + 1;
            cnt.put(who, Integer.valueOf(n));
            if (n > 2 && n % 100 != 0) return;

            ContentValues cv = new ContentValues();
            cv.put("msg", n > 2
                    ? "补充 " + who + " 累计" + n + "次 (最近 " + old + " -> " + v + ")"
                    : "补充 " + who + " " + old + " -> " + v);
            ctx.getContentResolver().insert(Uri.parse(URI_LOG), cv);
        } catch (Throwable ignored) {
        }
    }
}
