package nn.ecpm;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.Outline;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * 主界面 v26：底部五个分页（加速 / eCPM / 悬浮窗 / 报告 / 外观）。
 *
 * 界面规则（改版时不要破坏，用户已多次强调）：
 * 1. **一页只有一块面板**：面板内部用 1px 分隔线划小节，不再拆成多张卡片，
 *    否则卡片缝里露出背景图，滚动起来一块一块的很碎。
 * 2. **每个功能都有自己的底部栏入口**，不要藏在二级页面里。
 * 3. **底部导航要透明，但文字必须看得清**：v28 起底栏不铺底色，整条透出背景图，
 *    未选中项用 C_NAV（0xE6 白）+ 黑阴影，选中项用强调色纯色 + 粗体 + 阴影。
 *    不要再给它加回不透明底色 —— 用户明确要求「底下也要变成透明的」。
 * 4. 配色全部跟随"外观"页：强调色 / 面板浓度 / 背景图，改完当场重画，不重建页面。
 *
 * v35：
 *  - eCPM 配置热更新：主 hook 只在启动时读一次配置，改了区间不重启目标 App 根本不生效，
 *    界面却写着"最多 10 秒读到"。现在由 EcpmPlus 每 10 秒把新区间推回去，说到做到；
 *  - 日志上限的说明写实：eCPM 那一路受核心 2 万字符限制，档位设再大也只留那么多。
 *
 * v34：
 *  - 新增 eCPM 补充层 EcpmPlus（xposed_init 第三行），补主 hook 管不到的三块：
 *    带参 getter、不叫 cpm 的价格方法（price/bid/revenue/income/payout）、BigDecimal 返回值；
 *  - 报告页把扩展层贡献的改写单独标成「其中扩展 N 次」。
 *
 * v33：
 *  - 应用名统一成「CK广告助手」：界面标题、悬浮窗面板、通知标题、桌面图标下的名字、模块描述；
 *  - 顶栏的 @QVQ660 换成交流群号 1132982709，点这串数字直接跳 QQ 加群；
 *  - 报告页新增「反馈与加群」一块，一个按钮进群；没装 QQ 就把群号复制到剪贴板。
 *
 * v32：
 *  - 点「本机」格子改成"有图就用这张"，一张都没有才弹相册（以前一律弹，想切回自己的图被挡住）；
 *  - 8 张满了再点选图，直接提示，不再先弹一次相册；
 *  - 存本机图解码用 RGB_565，1600px 的临时内存从 10MB 降到 5MB。
 *
 * v31：
 *  - 修 v30 的致命 bug：`want` 加上槽位号后，loadBgAsync 里还拿 `want == 4` 判断，
 *    选本机图时一直在解内置图 —— 上传成功、缩略图也有，背景就是不变；
 *  - 同时把解码用的 File 提到主线程先取好，避免后台解码期间切槽位解错图；
 *  - 选背景的 sp 写入从 apply 改 commit，选完立刻被系统回收也不会丢设置。
 *
 * v30：
 *  - 本机图片可多选上传，最多 8 张（bg_user_0..7.jpg，旧版单张 bg_user.jpg 自动并入 0 号）；
 *  - 外观页多一条「我的图片」横向缩略图，点一下切换、点右上角 × 删除；
 *  - 选图走 OPEN_DOCUMENT + EXTRA_ALLOW_MULTIPLE，国产图库对 GET_CONTENT 多选支持不稳定。
 *
 * v29：
 *  - 整屏 edge-to-edge：状态栏、导航栏一律透明，背景图铺到屏幕最上沿和最下沿，
 *    以前只有内容区透明、上下各压一条深色，用户反馈"上面和下面都不是透明"；
 *  - 标题栏不再有任何底色，底栏连那根 1px 分隔线也去掉，文字全靠阴影立住；
 *  - 键盘高度走 WindowInsets.Type.ime()，edge-to-edge 下不会把输入框顶到键盘后面。
 *
 * v28：
 *  - 底部导航整条透明，只留 1px 分隔线，文字加阴影保证深浅背景都读得清；
 *  - 日志裁剪整体挪到后台线程（之前在主线程读两路共 4 万字）；
 *  - 状态灯 3 秒轮询加异常隔离，抛一次不会让灯停更。
 *
 * v27：
 *  - 日志有上限（500 / 2000 / 10000 行），超了自动删最旧的整行；
 *  - 换主题不再 recreate()：只重画受影响的控件，不闪、不丢滚动位置；
 *  - 五个页面改懒加载，启动只建当前页；
 *  - 背景图后台解码 + 只画一层（去掉了全屏半透明遮罩 View）；
 *  - "eCPM 是否在运行"改用 logbuf.xml 的修改时间，界面关着也准。
 *
 * 配置写 SharedPreferences("config")，与 ConfigProvider / EcpmHook 共用；
 * eCPM 的运行记录在 SharedPreferences("logbuf")，由 ConfigProvider.insert 写入。
 */
public class MainActivity extends Activity {

    // ---------------- 配色 ----------------
    private static final int C_TITLE = 0xFAFFFFFF;
    private static final int C_TEXT = 0xE6FFFFFF;
    /** 次要文字。原来是 0xA0，深色背景上偏灰发闷，提到 0xB8 后仍弱于正文但看得清 */
    private static final int C_SUB = 0xB8FFFFFF;
    /**
     * 底部导航未选中项。必须比 C_SUB 更亮：
     * v25 之前用 0xA0 白压在近黑底栏上，实际只有深灰的观感，用户反馈"底部单个是黑色的"。
     * v28 起底栏透明，这个亮度配合阴影在深色图和白底图上都够读。
     */
    private static final int C_NAV = 0xF0FFFFFF;
    /** 面板底色。太透会被背景图抢掉文字，20% 白 + 54% 黑遮罩是可读性下限 */
    private static int C_PANEL = 0x33FFFFFF;
    private static final int C_FIELD = 0x2BFFFFFF;
    private static final int C_STROKE = 0x33FFFFFF;
    private static final int C_DIV = 0x1FFFFFFF;
    private static final int C_OFF = 0x1FFFFFFF;
    /**
     * 强调色与面板浓度不能是 final：外观页切换后要立刻生效。
     * v27 起不重建 Activity，改完由 repaintAll() 逐个体重画。
     */
    private static int C_ON = 0x66FF5C7A;
    private static int C_ACCENT = 0xFFFF5C7A;
    private static final int C_LOG = 0xD99CFFB0;

    // ---------------- 分页 ----------------
    private static final int TAB_SPEED = 0;
    private static final int TAB_ECPM = 1;
    private static final int TAB_FLOAT = 2;
    private static final int TAB_REPORT = 3;
    private static final int TAB_LOOK = 4;
    private static final String[] TAB_NAMES = {"加速", "eCPM", "悬浮窗", "报告", "外观"};

    /** 本机图片最多存几张：8 张够用，再多只是白占空间 */
    private static final int USER_MAX = 8;

    /** 交流群号：顶栏那串数字点一下就跳 QQ 加群，报告页也显它 */
    private static final String GROUP_UIN = "1132982709";

    private static final int REQ_OVERLAY = 0x201;
    private static final int REQ_IMAGE = 0x202;
    private static final int REQ_BALL = 0x203;

    /** 强调色可选项：玫红 / 蓝 / 紫 / 青绿 */
    private static final int[] ACCENTS = {0xFFFF5C7A, 0xFF4C8DFF, 0xFF9B6BFF, 0xFF2FBF9A};
    /** 面板浓度：轻薄 / 标准 / 厚重 */
    private static final int[] PANELS = {0x26FFFFFF, 0x33FFFFFF, 0x47FFFFFF};
    /** 日志最多显示最后这么多行，再长就只在日志框里滚 */
    private static final int LOG_LINES = 60;

    /** 配置 + 加速日志 */
    private SharedPreferences sp;
    /** eCPM 日志，由 ConfigProvider.insert 写入 */
    private SharedPreferences spLog;

    private boolean speedOn = true;
    private boolean smartOn = true;
    private boolean skipOn = true;
    private boolean floatOn = false;

    private Button bSpeedY, bSpeedN, bSmartY, bSmartN, bSkipY, bSkipN, bFloatY, bFloatN;
    private EditText etMin, etMax;
    private TextView tvLog, tvReport, tvSpeedMode, tvFloatState, tvEcpmState;
    /** 加速页的运行状态：灯 / 结论 / 统计正文 */
    private View speedDot;
    private TextView tvSpeedState, tvSpeedStat;
    private String shownSpeedStat = "";
    /** eCPM 状态灯（绿=最近有改写，灰=没有） */
    private View ecpmDot;
    /** 标题栏右侧的常驻状态灯，切到任何一页都看得见 */
    private View headDot;
    private TextView headState;
    /** 上次画过的灯色，没变就不重建 Drawable */
    private int paintedDot;

    /** 日志解析放后台：两万字的 split + 统计在主线程做，切页会顿一下 */
    private final java.util.concurrent.ExecutorService io =
            java.util.concurrent.Executors.newSingleThreadExecutor();
    private Handler ui;
    private Runnable logRefresh;
    private int reportSeq = 0;
    private int logSeq = 0;
    /** 上一次真正设进 TextView 的文本，内容没变就不 setText，省掉一次重排 */
    private String shownReport = "";
    private String shownLog = "";
    /** 解码过的背景位图，切背景/重建时复用，避免每次都读盘解码 */
    private Bitmap bgBmp;
    private int bgBmpStyle = -1;
    /** 正在后台解码哪种背景（0 内置 / 4 本机），避免连续切换时重复提交 */
    private int bgLoading = -1;
    private Drawable assetThumb;
    /** 本机图片缩略图，按槽位缓存；删除/新增时置空 */
    private final Drawable[] userThumbs = new Drawable[USER_MAX];
    /** 本机图片当前用第几个槽位（bg_user_N.jpg） */
    private int bgPick = 0;
    /** 外观页「我的图片」横向条：选图/删图后只重建这一条，不重建整页 */
    private LinearLayout myStrip;
    private View myStripBox;

    /** 懒加载：用到哪页建哪页，pages[i] 为 null 表示还没建 */
    private final View[] pages = new View[5];
    private FrameLayout holder;
    private final TextView[] tabLabels = new TextView[5];
    private final View[] tabBars = new View[5];

    /** 主题相关的容器，换色时逐个重画（代替整页 recreate） */
    private final java.util.ArrayList<LinearLayout> panels = new java.util.ArrayList<LinearLayout>();
    private final java.util.ArrayList<Button> primaries = new java.util.ArrayList<Button>();

    /** 日志上限选项（行） */
    private static final int[] LOG_CAPS = {500, 2000, 10000};
    private final TextView[] capChips = new TextView[3];

    /** 外观：背景样式、主题色、面板浓度 */
    private int bgStyle = 0;
    private int accentIdx = 0;
    private int glassIdx = 1;
    private FrameLayout bgHolder;
    private View[] bgChips = new View[5];
    private TextView[] accentChips = new TextView[4];
    private TextView[] glassChips = new TextView[3];
    private int tab = TAB_SPEED;

    private BroadcastReceiver logRx;

    /** 只更新状态文字，每 3 秒一次；页面不可见时停掉 */
    private final Runnable statusTick = new Runnable() {
        public void run() {
            // 这里一旦抛异常，循环就断了，状态灯再也不更新 —— 整个包住
            try {
                refreshStatus();
            } catch (Throwable ignored) {
            }
            if (ui != null) ui.postDelayed(this, 3000L);
        }
    };

    // ---------------- 生命周期 ----------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        // 背景图是后台解码的，解码完成前先给窗口一块深色底，
        // 否则部分 ROM 的主题背景是白的，冷启动会白闪一下
        try {
            getWindow().setBackgroundDrawable(
                    new android.graphics.drawable.ColorDrawable(0xFF0E0F14));
        } catch (Throwable ignored) {
        }

        // 状态栏 / 导航栏也要透明：只让内容区透出背景，上下还各压一条深色，
        // 看着就是屏幕最上和最下贴了两条胶带。整屏 edge-to-edge 才算真透明。
        applyEdge();

        sp = getSharedPreferences("config", 0);
        spLog = getSharedPreferences("logbuf", 0);
        ui = new Handler(getMainLooper());
        speedOn = sp.getBoolean("speed_enabled", true);
        smartOn = sp.getBoolean("smart_enabled", true);
        skipOn = sp.getBoolean("skip_non_positive", true);
        floatOn = sp.getBoolean("float_on", false);
        bgStyle = sp.getInt("bg_style", 0);
        bgPick = sp.getInt("bg_pick", 0);
        // 老版本只有一张 bg_user.jpg，先并到 0 号槽位，升级不丢图
        migrateUserBgs();
        // 文件可能被清理过：选中的槽位没了退到第一张，一张都没有就回内置图，
        // 否则开场背景层是空的，只剩窗口那块深色
        if (bgPick < 0 || bgPick >= USER_MAX || !slotUsed(bgPick)) {
            int first = firstUsedSlot();
            bgPick = first < 0 ? 0 : first;
        }
        if (bgStyle == 4 && firstUsedSlot() < 0) bgStyle = 0;
        accentIdx = sp.getInt("accent", 0);
        glassIdx = sp.getInt("glass", 1);
        applyLook();

        if (savedInstanceState != null) {
            tab = savedInstanceState.getInt("tab", TAB_SPEED);
        }
        if (tab < 0 || tab >= TAB_NAMES.length) tab = TAB_SPEED;

        FrameLayout root = new FrameLayout(this);

        // 背景单独放一层容器：换背景只需重建这一层，不用整页 recreate
        bgHolder = new FrameLayout(this);
        root.addView(bgHolder, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        rebuildBg();

        // 压暗交给背景图自己的 colorFilter，不再叠一层全屏 View。
        // 少一层全屏绘制，滚动时少一次合成，低端机上这点差别是看得见的。

        // 竖向三段：标题栏 / 页面容器 / 底部导航
        final LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);

        final LinearLayout header = buildHeader();
        shell.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        holder = new FrameLayout(this);
        shell.addView(holder, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        // 五个页面以前在 onCreate 一次性建完（两百多个 View），
        // 低端机首屏要等三四百毫秒。现在只建当前页，其余点到了再建。

        final LinearLayout nav = buildNav();
        shell.addView(nav, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(shell, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Android 15+ 强制 edge-to-edge：状态栏压在标题上、导航栏压住底部 tab。
        // 系统已经让位时 inset 为 0，加 0 不影响旧系统。
        final int headTop = dp(12);
        final int navBottom = dp(6);
        shell.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                int top = 0;
                int bottom = 0;
                int ime = 0;
                try {
                    if (Build.VERSION.SDK_INT >= 30) {
                        android.graphics.Insets b = insets.getInsets(WindowInsets.Type.systemBars());
                        top = b.top;
                        bottom = b.bottom;
                        // edge-to-edge 下 adjustResize 不再缩窗口，键盘高度得自己接，
                        // 否则点开输入框会把它顶在键盘后面
                        ime = insets.getInsets(WindowInsets.Type.ime()).bottom;
                    } else {
                        top = insets.getSystemWindowInsetTop();
                        bottom = insets.getSystemWindowInsetBottom();
                    }
                } catch (Throwable ignored) {
                }
                header.setPadding(hPad(), headTop + top, hPad(), dp(6));
                nav.setPadding(0, 0, 0, navBottom + Math.max(bottom, ime));
                return insets;
            }
        });

        setContentView(root);
        // edge-to-edge 下第一次 insets 不一定自动派发到 shell，主动要一次，
        // 否则标题会顶进状态栏、底栏会压到手势条上
        try {
            root.requestApplyInsets();
        } catch (Throwable ignored) {
        }

        refreshToggles();
        registerLogRx();
        selectTab(tab);
        refreshStatus();
        trimLogs();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("tab", tab);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 权限被撤销后 float_on 会残留 true，这里纠正一次，避免显示「是」但其实没跑
        if (sp.getBoolean("float_on", false) && !canOverlay()) {
            sp.edit().putBoolean("float_on", false).apply();
        }
        // 服务被系统回收后自己起回来；用户主动关掉（float_on=false）不会触发
        if (sp.getBoolean("float_on", false) && !FloatService.isRunning() && canOverlay()) {
            startFloat();
        }
        refreshToggles();
        refreshReport();
        if (tvLog != null) refreshLog();
        trimLogs();
        if (ui != null) {
            ui.removeCallbacks(statusTick);
            ui.postDelayed(statusTick, 300L);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (ui != null) ui.removeCallbacks(statusTick);
    }

    @Override
    protected void onDestroy() {
        try {
            if (logRx != null) unregisterReceiver(logRx);
        } catch (Throwable ignored) {
        }
        if (ui != null) ui.removeCallbacksAndMessages(null);
        try {
            io.shutdownNow();
        } catch (Throwable ignored) {
        }
        super.onDestroy();
    }

    // ---------------- 标题栏 ----------------

    /**
     * 全透明系统栏（v29）：状态栏、导航栏一律透明，背景图一直铺到屏幕最上沿和最下沿。
     * 各版本能力不同，逐级降级 —— 30+ 关掉 fit system windows，21~29 用 SYSTEM_UI_FLAG
     * 让内容布局到全屏；26 以下的三键导航栏不接受纯透明，退成半透明黑兜底。
     */
    private void applyEdge() {
        try {
            Window w = getWindow();
            w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                    | android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            if (Build.VERSION.SDK_INT >= 21) {
                w.setStatusBarColor(0x00000000);
                w.setNavigationBarColor(Build.VERSION.SDK_INT >= 26 ? 0x00000000 : 0x66000000);
            }
            if (Build.VERSION.SDK_INT >= 29) {
                // 系统默认会给透明栏加一层对比遮罩，深色渐变上看就是发灰的一条，关掉
                w.setStatusBarContrastEnforced(false);
                w.setNavigationBarContrastEnforced(false);
            }
            if (Build.VERSION.SDK_INT >= 30) {
                // 30+ 只走 decorFitsSystemWindows，不要再叠 systemUiVisibility：
                // 两套机制同时开会互相覆盖，个别 ROM 上 insets 直接变 0，标题就钻进状态栏
                w.setDecorFitsSystemWindows(false);
                android.view.WindowInsetsController c = w.getInsetsController();
                if (c != null) {
                    // 清掉浅色图标标志：背景是深色的，状态栏/导航栏图标要白
                    c.setSystemBarsAppearance(0,
                            android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                                    | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
                }
            } else {
                w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
            }
        } catch (Throwable ignored) {
        }
    }

    private LinearLayout buildHeader() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        // 标题栏不铺任何底色，直接压在背景图上，靠字自己的阴影拉开层次
        h.setBackgroundColor(0x00000000);
        h.setPadding(hPad(), dp(12), hPad(), dp(6));

        TextView title = new TextView(this);
        title.setText("CK广告助手");
        title.setTextSize(21);
        title.setTextColor(C_TITLE);
        // 标题直接压在背景图上，阴影给足，浅色图上也立得住
        title.setShadowLayer(8f, 0f, 2f, 0xCC000000);
        h.addView(title);

        View sp1 = new View(this);
        h.addView(sp1, new LinearLayout.LayoutParams(0, 1, 1f));

        // 顶栏右侧那串数字是群号，顺手做成加群入口：能点到，比藏在页面里好找
        TextView sub = new TextView(this);
        sub.setText(verName() + " · " + GROUP_UIN);
        sub.setTextSize(11);
        sub.setTextColor(C_SUB);
        sub.setGravity(Gravity.END);
        sub.setShadowLayer(6f, 0f, 1f, 0xCC000000);
        sub.setSingleLine(true);
        // 窄屏上标题和状态灯已经占满，这串数字宁可省略号也不能把标题挤走
        sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        sub.setMaxWidth(dp(132));
        sub.setPadding(dp(4), dp(2), 0, dp(2));
        sub.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openGroup();
            }
        });
        h.addView(sub);

        // 标题栏右侧再挂一盏小灯，任何一页都能看到 eCPM 在不在改写
        headDot = new View(this);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(7), dp(7));
        dlp.leftMargin = dp(5);
        h.addView(headDot, dlp);
        headState = new TextView(this);
        headState.setTextSize(10);
        headState.setTextColor(C_SUB);
        headState.setShadowLayer(6f, 0f, 1f, 0xCC000000);
        h.addView(headState);
        return h;
    }

    // ---------------- 反馈 / 加群 ----------------

    /**
     * 跳 QQ 加群。
     * 三个候选 scheme 挨个试：第一个是群资料卡（点一下就能加），
     * 第二个直接进群聊，第三个是国家版 QQ 的老写法。
     * 都失败（没装 QQ / 被 ROM 拦）就把群号复制到剪贴板，手动搜。
     */
    private void openGroup() {
        String[] urls = {
                "mqqapi://card/show_pslcard?src_type=internal&uin=" + GROUP_UIN
                        + "&card_type=group&source=qrcode",
                "mqq://im/chat?chat_type=group&uin=" + GROUP_UIN + "&version=1&src_type=web",
                "mqqwpa://im/chat?chat_type=group&uin=" + GROUP_UIN + "&version=1&src_type=web"
        };
        for (int i = 0; i < urls.length; i++) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(urls[i])));
                return;
            } catch (Throwable ignored) {
                // 没装 QQ 就是 ActivityNotFound，换下一个
            }
        }
        try {
            android.content.ClipboardManager cm = (android.content.ClipboardManager)
                    getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("QQ群", GROUP_UIN));
            Toast.makeText(this, "没找到 QQ，群号 " + GROUP_UIN + " 已复制，去 QQ 搜一下",
                    Toast.LENGTH_LONG).show();
        } catch (Throwable t) {
            Toast.makeText(this, "群号：" + GROUP_UIN, Toast.LENGTH_LONG).show();
        }
    }

    // ---------------- 底部导航 ----------------

    private LinearLayout buildNav() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.VERTICAL);
        // v29：底栏整条全透明，连那根 1px 分隔线也去掉 —— 有它在就还是"一条边"。
        // 文字直接压在背景图上，所以每个字都要带阴影，浅背景（用户传的白图）也读得清。
        nav.setBackgroundColor(0x00000000);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        // 平板 / 折叠屏上四个 tab 不会散到两端，和内容一样限宽居中
        row.setPadding(hPad(), dp(6), hPad(), dp(4));

        for (int i = 0; i < TAB_NAMES.length; i++) {
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setPadding(0, dp(4), 0, 0);
            item.setMinimumHeight(dp(48));

            View bar = new View(this);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(18), dp(3));
            blp.bottomMargin = dp(6);
            bar.setBackgroundDrawable(pill(0x00FFFFFF, 2));
            item.addView(bar, blp);

            TextView lb = new TextView(this);
            lb.setText(TAB_NAMES[i]);
            lb.setTextSize(12);
            lb.setGravity(Gravity.CENTER);
            lb.setTextColor(C_NAV);
            // 透明底栏上必须靠阴影把字从背景里分出来，深浅背景都能读
            lb.setShadowLayer(7f, 0f, 1f, 0xCC000000);
            // 大字体下导航文字不能折成两行，否则五个 tab 高度不齐
            lb.setSingleLine(true);
            lb.setEllipsize(android.text.TextUtils.TruncateAt.END);
            item.addView(lb);

            final int idx = i;
            item.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    selectTab(idx);
                }
            });

            row.addView(item, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            tabBars[i] = bar;
            tabLabels[i] = lb;
        }
        nav.addView(row);
        return nav;
    }

    /** 选中项用强调色，去掉配置里带的 alpha —— 半透明的颜色在深色导航条上会发灰 */
    private static int navAccent() {
        return C_ACCENT | 0xFF000000;
    }

    private void selectTab(int idx) {
        if (idx < 0 || idx >= TAB_NAMES.length) return;
        // 先建再藏：先 GONE 旧的会让这一帧是白底，看着像闪了一下
        View cur = pageAt(idx);
        tab = idx;
        for (int i = 0; i < pages.length; i++) {
            if (pages[i] != null) {
                pages[i].setVisibility(i == idx ? View.VISIBLE : View.GONE);
            }
        }
        if (cur != null) cur.setVisibility(View.VISIBLE);
        paintNav();

        if (idx == TAB_REPORT) {
            refreshReport();
            refreshLog();
            paintCap();
        } else if (idx == TAB_FLOAT) {
            refreshFloatState();
        } else if (idx == TAB_SPEED) {
            updateSpeedMode();
        } else if (idx == TAB_LOOK) {
            paintLook();
        }
    }

    /** 底部导航的选中态。换主题、切页都走这里，只有这一处改颜色 */
    private void paintNav() {
        for (int i = 0; i < TAB_NAMES.length; i++) {
            boolean on = (i == tab);
            if (tabBars[i] != null) {
                tabBars[i].setBackgroundDrawable(pill(on ? C_ACCENT : 0x00FFFFFF, 2));
            }
            if (tabLabels[i] != null) {
                tabLabels[i].setTextColor(on ? navAccent() : C_NAV);
                tabLabels[i].setTypeface(null, on ? Typeface.BOLD : Typeface.NORMAL);
                // 底栏是透明的，强调色在浅背景上同样需要阴影
                tabLabels[i].setShadowLayer(7f, 0f, 1f, 0xCC000000);
            }
        }
    }

    /** 目录页按需构建；已经建过就直接返回 */
    private View pageAt(int i) {
        if (i < 0 || i >= pages.length) return null;
        if (pages[i] != null) return pages[i];
        View v;
        switch (i) {
            case TAB_SPEED:
                v = buildSpeedPage();
                break;
            case TAB_ECPM:
                v = buildEcpmPage();
                break;
            case TAB_FLOAT:
                v = buildFloatPage();
                break;
            case TAB_REPORT:
                v = buildReportPage();
                break;
            default:
                v = buildLookPage();
                break;
        }
        pages[i] = v;
        if (holder != null) {
            holder.addView(v, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        return v;
    }

    /**
     * 换主题后重画。以前是 recreate()：整页销毁重建，会闪一下、滚动位置也回到顶部，
     * 低端机上还能看到一帧白底。这里只重设受影响的背景色和文字色。
     */
    private void repaintAll() {
        for (int i = 0; i < panels.size(); i++) {
            LinearLayout p = panels.get(i);
            if (p != null) p.setBackgroundDrawable(round(C_PANEL, 18));
        }
        for (int i = 0; i < primaries.size(); i++) {
            Button b = primaries.get(i);
            if (b != null) b.setBackgroundDrawable(round(C_ON, 14));
        }
        paintNav();
        refreshToggles();
        paintLook();
        paintCap();
    }

    // ---------------- 加速页 ----------------

    private View buildSpeedPage() {
        ScrollView sv = pageScroll();
        LinearLayout col = pageCol(sv);
        LinearLayout p = panel(col);

        section(p, "广告加速", "倒计时与播放器倍速。关闭后目标应用内不再加速。", null);
        bSpeedY = toggleBtn("是");
        bSpeedN = toggleBtn("否");
        p.addView(segRow(bSpeedY, bSpeedN), matchWrapTop(10));

        // 这一块就是为了回答「到底有没有效果」。
        // 以前只有一个总开关，用户开完看不到任何反馈，只能凭感觉猜。
        section(p, "运行状态",
                "目标应用里实时回传的数据，每 30 秒一条。", null);

        LinearLayout st = new LinearLayout(this);
        st.setOrientation(LinearLayout.HORIZONTAL);
        st.setGravity(Gravity.CENTER_VERTICAL);
        speedDot = new View(this);
        LinearLayout.LayoutParams sdp = new LinearLayout.LayoutParams(dp(8), dp(8));
        sdp.rightMargin = dp(6);
        st.addView(speedDot, sdp);
        tvSpeedState = new TextView(this);
        tvSpeedState.setTextSize(11);
        tvSpeedState.setTextColor(C_TEXT);
        st.addView(tvSpeedState);
        p.addView(st, matchWrapTop(6));

        tvSpeedStat = new TextView(this);
        tvSpeedStat.setTextSize(11);
        tvSpeedStat.setTextColor(C_SUB);
        tvSpeedStat.setLineSpacing(dp(3), 1f);
        tvSpeedStat.setPadding(0, dp(5), 0, 0);
        p.addView(tvSpeedStat);

        section(p, "智能调速",
                "按广告时长自动定倍率：1.2s 起 1.5×，2.5s 起 2×，6s 起 2.5×，15s 起 3×。"
                        + "每秒一次的广告倒计时按循环单独识别，第 2 秒起 2.5×；"
                        + "低端机自动降档。关闭则用固定倍率（普通 3×，游戏 2×）。", null);
        bSmartY = toggleBtn("是");
        bSmartN = toggleBtn("否");
        p.addView(segRow(bSmartY, bSmartN), matchWrapTop(10));

        divider(p);
        tvSpeedMode = new TextView(this);
        tvSpeedMode.setTextSize(11);
        tvSpeedMode.setTextColor(C_SUB);
        tvSpeedMode.setLineSpacing(dp(3), 1f);
        p.addView(tvSpeedMode);

        divider(p);
        Button save = primary("保存并生效");
        save.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                doSave(false);
            }
        });
        p.addView(save);

        footnote(p, "开关改完点一次保存，目标应用最多 10 秒读到；彻底生效需重启目标应用。");

        updateSpeedMode();
        bindToggles();
        refreshSpeedState();
        return sv;
    }

    /**
     * 加速运行状态。
     * 两个时间戳分开看：tick_ts 只代表「注入过」，speed_ts 才代表「真的缩过时间」。
     * 只看前者会把「装上了但没触发」误报成「加速中」。
     */
    private void refreshSpeedState() {
        if (tvSpeedState == null) return;
        long injected = Diag.tickLast(sp);
        long active = 0L;
        try {
            active = sp.getLong("speed_ts", 0L);
        } catch (Throwable ignored) {
        }
        boolean running = Diag.fresh(active, 180000L);
        int c = running ? 0xFF32D583 : 0xFF8E8E93;
        if (speedDot != null) speedDot.setBackgroundDrawable(dotDrawable(c));

        String s;
        if (running) s = "加速中";
        else if (injected > 0L) s = "已注入，未见加速";
        else s = "未注入";
        if (!s.equals(tvSpeedState.getText().toString())) tvSpeedState.setText(s);

        String stat = "";
        try {
            stat = sp.getString("speed_stat", "");
        } catch (Throwable ignored) {
        }
        String txt;
        if (stat != null && stat.length() > 0) {
            txt = stat.startsWith("tick: ") ? stat.substring(6) : stat;
            if (active > 0L) txt = txt + "\n最近一次：" + Diag.agoText(active);
            txt = txt + "\n" + (running
                    ? "倍率正常，广告倒计时和播放器都在加速。"
                    : "超过 3 分钟没有新数据，可能这段时间没打开过带广告的应用。");
        } else if (injected > 0L) {
            txt = "已成功注入目标应用，但还没缩过任何延时。\n"
                    + "先打开一个带开屏 / 激励视频的应用，看完一条广告再回来看看。";
        } else {
            txt = "还没有任何目标应用上报。\n"
                    + "检查三步：LSPosed 里勾选目标应用 → 强制停止它 → 重新打开。";
        }
        if (!txt.equals(shownSpeedStat)) {
            shownSpeedStat = txt;
            tvSpeedStat.setText(txt);
        }
    }

    private void updateSpeedMode() {
        if (tvSpeedMode == null) return;
        if (smartOn) {
            tvSpeedMode.setText("当前：智能调速\n1.2s → 1.5×    2.5s → 2×\n"
                    + "6s → 2.5×    15s → 3×\n1s 倒计时循环 → 2.5×");
        } else {
            tvSpeedMode.setText("当前：固定倍率\n普通应用 3×    游戏 2×");
        }
    }

    // ---------------- eCPM 页 ----------------

    private View buildEcpmPage() {
        ScrollView sv = pageScroll();
        LinearLayout col = pageCol(sv);
        LinearLayout p = panel(col);

        // 顶部先给结论：这会儿到底有没有在改写
        LinearLayout st = new LinearLayout(this);
        st.setOrientation(LinearLayout.HORIZONTAL);
        st.setGravity(Gravity.CENTER_VERTICAL);
        ecpmDot = new View(this);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(8), dp(8));
        dlp.rightMargin = dp(6);
        st.addView(ecpmDot, dlp);
        tvEcpmState = new TextView(this);
        tvEcpmState.setTextSize(11);
        tvEcpmState.setTextColor(C_TEXT);
        st.addView(tvEcpmState);
        p.addView(st, matchWrapTop(2));
        paintedDot = 0;
        refreshStatus();

        section(p, "eCPM 范围", "判定用的上下限，单位：分。超出区间的值会被修正回范围内。", null);
        etMin = field(String.valueOf(sp.getLong("min", 100000L)));
        p.addView(labelRow("最小值", etMin), matchWrapTop(10));
        etMax = field(String.valueOf(sp.getLong("max", 130000L)));
        p.addView(labelRow("最大值", etMax), matchWrapTop(8));

        section(p, "异常值保护", "原值 ≤0 或非数字时保持原值，不强行改写。", null);
        bSkipY = toggleBtn("是");
        bSkipN = toggleBtn("否");
        p.addView(segRow(bSkipY, bSkipN), matchWrapTop(10));

        divider(p);
        Button save = primary("保存并生效");
        save.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                doSave(true);
            }
        });
        p.addView(save);

        footnote(p, "改写记录在「报告」页。若那边一直是 0，先确认 LSPosed 里勾选了目标应用，"
                + "并且勾选后重启过它。");
        bindToggles();
        return sv;
    }

    // ---------------- 悬浮窗页 ----------------

    private View buildFloatPage() {
        ScrollView sv = pageScroll();
        LinearLayout col = pageCol(sv);
        LinearLayout p = panel(col);

        section(p, "悬浮窗",
                "在目标应用 / 游戏上层显示一个小球，点开就能切「广告加速」和「智能调速」，"
                        + "不用来回切到助手界面。", null);
        bFloatY = toggleBtn("是");
        bFloatN = toggleBtn("否");
        p.addView(segRow(bFloatY, bFloatN), matchWrapTop(10));

        tvFloatState = new TextView(this);
        tvFloatState.setTextSize(11);
        tvFloatState.setTextColor(C_SUB);
        tvFloatState.setPadding(0, dp(10), 0, 0);
        p.addView(tvFloatState);

        divider(p);
        Button perm = ghost("打开悬浮窗权限设置");
        perm.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                requestOverlay();
            }
        });
        p.addView(perm);

        section(p, "悬浮球图标", "默认是一颗纯色圆球，也可以换成相册里的图片。"
                + "改完悬浮球会自己重建一次，不用重开。", null);
        Button pickBall = ghost(hasBall() ? "更换图片" : "从相册选一张");
        pickBall.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                chooseBall();
            }
        });
        p.addView(pickBall, matchWrapTop(12));
        Button resetBall = ghost("恢复默认圆球");
        resetBall.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                clearBall();
            }
        });
        p.addView(resetBall, matchWrapTop(8));

        section(p, "关于常驻通知", null, null);
        TextView t = new TextView(this);
        t.setText("前台服务必须带一个通知，这是系统要求，关掉悬浮窗后通知会自己消失。\n"
                + "首次开启会跳到系统设置要「显示在其他应用上层」。\n"
                + "悬浮窗出任何问题都只会自己停掉，不会影响加速本身。");
        t.setTextSize(11);
        t.setTextColor(C_SUB);
        t.setLineSpacing(dp(3), 1f);
        p.addView(t, matchWrapTop(6));

        refreshFloatState();
        bindToggles();
        return sv;
    }

    private void refreshFloatState() {
        if (tvFloatState == null) return;
        boolean running = FloatService.isRunning();
        boolean perm = canOverlay();
        String s = "悬浮窗服务：" + (running ? "运行中" : "未运行")
                + "\n悬浮窗权限：" + (perm ? "已允许" : "未允许")
                + "\n" + ecpmStateText();
        if (!s.equals(tvFloatState.getText().toString())) tvFloatState.setText(s);
    }

    // ---------------- 运行状态 ----------------

    /**
     * 「eCPM 是否在运行」用最后一条改写的时间戳判断，而不是猜进程：
     * EcpmHook 每次改写都会发 nn.ecpm.LOG 广播，LogReceiver 收到就更新 ecpm_ts。
     * 这里只读本机 config，不额外碰 provider，也不参与 hook 判定。
     * 3 分钟内算运行中 —— 广告本身就有间隔，窗口取太短会一直显示"没在跑"。
     */
    private String ecpmStateText() {
        long ts = Diag.ecpmLast(this, sp);
        if (ts <= 0) return "eCPM：还没有任何改写记录";
        boolean on = Diag.fresh(ts, Diag.WIN_ECPM);
        return on
                ? "eCPM：运行中 · " + Diag.agoText(ts) + "改写"
                : "eCPM：上次改写 " + Diag.agoText(ts);
    }

    private GradientDrawable dotDrawable(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        g.setStroke(dp(1), 0x66FFFFFF);
        return g;
    }

    /** 状态灯 + 文字，3 秒一次；只在界面可见时跑 */
    private void refreshStatus() {
        // 时间来源见 Diag：广播 + logbuf.xml 的修改时间，取更晚的那个
        long ts = Diag.ecpmLast(this, sp);
        boolean on = Diag.fresh(ts, Diag.WIN_ECPM);
        int c = on ? 0xFF32D583 : 0xFF8E8E93;
        if (paintedDot != c) {
            paintedDot = c;
            if (ecpmDot != null) ecpmDot.setBackgroundDrawable(dotDrawable(c));
            if (headDot != null) headDot.setBackgroundDrawable(dotDrawable(c));
        }
        if (headState != null) {
            String s = ts <= 0 ? "无记录" : (on ? "运行中" : "已改写");
            if (!s.equals(headState.getText().toString())) headState.setText(s);
        }
        if (tvEcpmState != null) {
            String s = ecpmStateText();
            if (!s.equals(tvEcpmState.getText().toString())) tvEcpmState.setText(s);
        }
        refreshSpeedState();
        refreshFloatState();
    }


    // ---------------- 外观页 ----------------

    private View buildLookPage() {
        ScrollView sv = pageScroll();
        LinearLayout col = pageCol(sv);
        LinearLayout p = panel(col);

        section(p, "背景", "内置图片、动态渐变，或从本机相册选一张。切换立即生效。", null);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"图片", "流光", "深海", "暮紫", "本机"};
        for (int i = 0; i < names.length; i++) {
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);

            FrameLayout outer = new FrameLayout(this);
            outer.setPadding(dp(2), dp(2), dp(2), dp(2));
            View inner = new View(this);
            inner.setBackgroundDrawable(bgPreview(i));
            // 缩略图是方形位图，按圆角裁一下，不然会顶出格子的圆角描边
            inner.setOutlineProvider(new ViewOutlineProvider() {
                public void getOutline(View v, Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(9));
                }
            });
            inner.setClipToOutline(true);
            outer.addView(inner, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            // 「本机」还没选图时给个加号，选过就显示缩略图
            TextView plus = new TextView(this);
            plus.setText("+");
            plus.setTextSize(20);
            plus.setGravity(Gravity.CENTER);
            plus.setTextColor(0xCCFFFFFF);
            outer.addView(plus, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            if (i == 4) plus.setTag("plus");
            else plus.setVisibility(View.GONE);

            cell.addView(outer, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(62)));
            bgChips[i] = outer;

            TextView nm = new TextView(this);
            nm.setText(names[i]);
            nm.setTextSize(10);
            nm.setTextColor(C_SUB);
            nm.setGravity(Gravity.CENTER);
            nm.setPadding(0, dp(5), 0, 0);
            cell.addView(nm);

            final int idx = i;
            cell.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pickBg(idx);
                }
            });

            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) clp.leftMargin = dp(8);
            row.addView(cell, clp);
        }
        p.addView(row, matchWrapTop(12));

        Button pick = ghost("从本机选择图片 · 可多选");
        pick.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pickBg(4);
            }
        });
        p.addView(pick, matchWrapTop(12));

        // 我的图片：选过的都排在这一条里，点一下切过去，点右上角 × 删掉
        LinearLayout mine = new LinearLayout(this);
        mine.setOrientation(LinearLayout.VERTICAL);
        myStripBox = mine;

        TextView mt = new TextView(this);
        mt.setText("我的图片（最多 " + USER_MAX + " 张，相册原图删了也不影响）");
        mt.setTextSize(11);
        mt.setTextColor(C_SUB);
        mine.addView(mt);

        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setOverScrollMode(View.OVER_SCROLL_NEVER);
        myStrip = new LinearLayout(this);
        myStrip.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(myStrip, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hlp.topMargin = dp(8);
        mine.addView(hs, hlp);

        p.addView(mine, matchWrapTop(10));
        rebuildMyStrip();

        section(p, "主题色", "影响开关、保存按钮、底部指示条和悬浮窗小球。", null);
        LinearLayout dots = new LinearLayout(this);
        dots.setOrientation(LinearLayout.HORIZONTAL);
        String[] an = {"玫红", "蓝", "紫", "青绿"};
        for (int i = 0; i < ACCENTS.length; i++) {
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER_HORIZONTAL);

            TextView dot = new TextView(this);
            dot.setText("✓");
            dot.setTextSize(13);
            dot.setGravity(Gravity.CENTER);
            dot.setTextColor(0xFFFFFFFF);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(ACCENTS[i]);
            dot.setBackgroundDrawable(g);
            box.addView(dot, new LinearLayout.LayoutParams(dp(38), dp(38)));
            accentChips[i] = dot;

            TextView nm = new TextView(this);
            nm.setText(an[i]);
            nm.setTextSize(10);
            nm.setTextColor(C_SUB);
            nm.setGravity(Gravity.CENTER);
            nm.setPadding(0, dp(5), 0, 0);
            box.addView(nm);

            final int idx = i;
            box.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    setAccent(idx);
                }
            });

            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            dots.addView(box, blp);
        }
        p.addView(dots, matchWrapTop(12));

        section(p, "面板浓度", "背景太花时调厚一点，文字更清楚。", null);
        LinearLayout glass = new LinearLayout(this);
        glass.setOrientation(LinearLayout.HORIZONTAL);
        String[] gn = {"轻薄", "标准", "厚重"};
        for (int i = 0; i < gn.length; i++) {
            TextView b = new TextView(this);
            b.setText(gn[i]);
            b.setTextSize(13);
            b.setGravity(Gravity.CENTER);
            b.setMinHeight(dp(42));
            b.setPadding(0, dp(8), 0, dp(8));
            glassChips[i] = b;

            final int idx = i;
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    setGlass(idx);
                }
            });

            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) blp.leftMargin = dp(8);
            glass.addView(b, blp);
        }
        p.addView(glass, matchWrapTop(12));

        footnote(p, "本机图片会复制一份到应用私有目录，原图删了也不影响；"
                + "文件较大时按 1600px 压缩，不会把内存撑爆。");

        paintLook();
        return sv;
    }

    /** 刷新外观页的选中态 */
    private void paintLook() {
        for (int i = 0; i < bgChips.length; i++) {
            if (bgChips[i] == null) continue;
            boolean on = (i == bgStyle);
            bgChips[i].setBackgroundDrawable(outerFrame(on));
            View plus = bgChips[i].findViewWithTag("plus");
            if (plus != null) {
                plus.setVisibility(i == 4 && !hasUserBg() ? View.VISIBLE : View.GONE);
            }
        }
        // 「本机」格子里的缩略图要跟着当前选中的那张走，换图/删图后这里重画
        if (bgChips[4] instanceof FrameLayout) {
            FrameLayout f = (FrameLayout) bgChips[4];
            if (f.getChildCount() > 0) f.getChildAt(0).setBackgroundDrawable(bgPreview(4));
        }
        for (int i = 0; i < accentChips.length; i++) {
            if (accentChips[i] == null) continue;
            boolean on = (i == accentIdx);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(ACCENTS[i]);
            if (on) g.setStroke(dp(2), 0xFFFFFFFF);
            accentChips[i].setBackgroundDrawable(g);
            accentChips[i].setText(on ? "✓" : "");
        }
        for (int i = 0; i < glassChips.length; i++) {
            if (glassChips[i] == null) continue;
            boolean on = (i == glassIdx);
            glassChips[i].setBackgroundDrawable(round(on ? C_ON : C_OFF, 12));
            glassChips[i].setTextColor(on ? 0xFFFFFFFF : C_SUB);
        }
    }

    /** 「我的图片」横向条：点缩略图切换，右上角 × 删除。一张都没有时整条隐藏 */
    private void rebuildMyStrip() {
        if (myStrip == null) return;
        myStrip.removeAllViews();
        int n = userCount();
        if (myStripBox != null) myStripBox.setVisibility(n > 0 ? View.VISIBLE : View.GONE);
        int cur = currentUserSlot();

        for (int slot = 0; slot < USER_MAX; slot++) {
            if (!slotUsed(slot)) continue;
            final int s = slot;

            FrameLayout box = new FrameLayout(this);
            box.setPadding(dp(2), dp(2), dp(2), dp(2));
            box.setBackgroundDrawable(outerFrame(bgStyle == 4 && cur == s));

            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            if (userThumbs[s] == null) {
                Bitmap bm = decodeThumb(slotFile(s), false);
                if (bm != null) userThumbs[s] = new BitmapDrawable(getResources(), bm);
            }
            if (userThumbs[s] != null) iv.setImageDrawable(userThumbs[s]);
            iv.setOutlineProvider(new ViewOutlineProvider() {
                public void getOutline(View v, Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(9));
                }
            });
            iv.setClipToOutline(true);
            box.addView(iv, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            // 删除按钮：视觉 22dp，压在右上角；点它不会顺带切换背景
            TextView del = new TextView(this);
            del.setText("×");
            del.setTextSize(14);
            del.setGravity(Gravity.CENTER);
            del.setTextColor(0xFFFFFFFF);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(0xCC1A1A1E);
            g.setStroke(dp(1), 0x66FFFFFF);
            del.setBackgroundDrawable(g);
            del.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    deleteUserBg(s);
                }
            });
            FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(dp(22), dp(22));
            dlp.gravity = Gravity.END | Gravity.TOP;
            dlp.topMargin = dp(4);
            dlp.rightMargin = dp(4);
            box.addView(del, dlp);

            box.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pickUserBg(s);
                }
            });

            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(62), dp(62));
            if (myStrip.getChildCount() > 0) ilp.leftMargin = dp(8);
            myStrip.addView(box, ilp);
        }
    }

    /** 点缩略图切到这张 */
    private void pickUserBg(int slot) {
        if (!slotUsed(slot)) return;
        bgPick = slot;
        bgStyle = 4;
        sp.edit().putInt("bg_style", 4).putInt("bg_pick", slot).commit();
        bgBmp = null;
        bgBmpStyle = -1;
        rebuildBg();
        paintLook();
        rebuildMyStrip();
    }

    /** 删一张。删的正好是在用的那张，就顺位到剩下的第一张；一张不剩退回内置图 */
    private void deleteUserBg(int slot) {
        boolean wasCurrent = (bgStyle == 4 && currentUserSlot() == slot);
        try {
            slotFile(slot).delete();
        } catch (Throwable ignored) {
        }
        userThumbs[slot] = null;
        bgBmp = null;
        bgBmpStyle = -1;
        if (wasCurrent) {
            int next = firstUsedSlot();
            if (next >= 0) {
                bgPick = next;
            } else {
                // 一张都不剩：退回内置图，否则背景层是空的，整屏只剩窗口深色
                bgStyle = 0;
                bgPick = 0;
            }
            sp.edit().putInt("bg_style", bgStyle).putInt("bg_pick", bgPick).commit();
        }
        rebuildBg();
        paintLook();
        rebuildMyStrip();
        Toast.makeText(this, "已删除这张，相册里的原图还在", Toast.LENGTH_SHORT).show();
    }

    private Drawable outerFrame(boolean on) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setCornerRadius(dp(11));
        g.setColor(0x00000000);
        g.setStroke(dp(on ? 2 : 1), on ? C_ACCENT : C_STROKE);
        return g;
    }

    private void pickBg(int idx) {
        if (idx == 4) {
            // 已经有图：点格子就是"用这张"，直接切过去；
            // 一张都没有才弹相册。以前一律弹相册，想切回自己的图反被选图页挡住。
            if (hasUserBg()) {
                int s = currentUserSlot();
                if (s >= 0) {
                    pickUserBg(s);
                    return;
                }
            }
            chooseImage();
            return;
        }
        bgStyle = idx;
        // 用 commit 而不是 apply：选完马上可能被系统回收（返回键/相册切走），
        // apply 是异步写，进程没了设置就丢，回来还是旧背景
        sp.edit().putInt("bg_style", idx).commit();
        rebuildBg();
        paintLook();
    }

    private void setAccent(int idx) {
        accentIdx = idx;
        sp.edit().putInt("accent", idx).apply();
        applyLook();
        // 悬浮窗是另一个服务，颜色在 onCreate 时才画，只能停掉再起
        restartFloat();
        // 界面这边不重建，直接重画 —— 不闪、不丢滚动位置
        repaintAll();
    }

    private void setGlass(int idx) {
        glassIdx = idx;
        sp.edit().putInt("glass", idx).apply();
        applyLook();
        repaintAll();
    }

    /**
     * 选背景图，支持多选。
     * 用 OPEN_DOCUMENT 而不是 GET_CONTENT：国产图库对 GET_CONTENT 的多选支持参差不齐，
     * 文档选择器在 4.4 以上都是系统自带的，多选行为稳定。
     */
    private void chooseImage() {
        if (firstFreeSlot() < 0) {
            Toast.makeText(this, "最多存 " + USER_MAX + " 张，先点缩略图右上角的 × 删一张",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(Intent.createChooser(i, "选择背景图片（可多选）"), REQ_IMAGE);
        } catch (Throwable t) {
            try {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("image/*");
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(Intent.createChooser(i, "选择背景图片（可多选）"), REQ_IMAGE);
            } catch (Throwable t2) {
                Toast.makeText(this, "打不开相册：" + t2.getClass().getSimpleName(),
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * 多选保存：一张一张压到 1600px 存进空槽位，槽位满了就停，不覆盖已有图片。
     * 图库返回的 uri 重启后大概率失效（授权是临时的），所以必须复制到自己目录。
     */
    private void saveUserBgs(final java.util.List<Uri> uris) {
        int free = USER_MAX - userCount();
        if (free <= 0) {
            Toast.makeText(this, "最多存 " + USER_MAX + " 张，先删一张再选", Toast.LENGTH_SHORT).show();
            return;
        }
        final int cap = Math.min(uris.size(), free);
        Toast.makeText(this, cap < uris.size()
                        ? "最多再存 " + cap + " 张，多余的这次先跳过"
                        : "正在保存 " + cap + " 张…",
                Toast.LENGTH_SHORT).show();

        new Thread(new Runnable() {
            public void run() {
                int saved = 0;
                int firstNew = -1;
                for (int k = 0; k < uris.size(); k++) {
                    int slot = firstFreeSlot();
                    if (slot < 0) break;
                    if (writeUserBg(uris.get(k), slotFile(slot))) {
                        if (firstNew < 0) firstNew = slot;
                        saved++;
                    }
                }
                final int n = saved;
                final int fn = firstNew;
                runOnUiThread(new Runnable() {
                    public void run() {
                        // 保存期间用户可能已经退出，别再往已销毁的界面上贴图
                        if (isFinishing() || isDestroyed()) return;
                        if (n <= 0) {
                            Toast.makeText(MainActivity.this, "读取图片失败，换一张试试",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                        // 之前用的不是本机图，或选中的那张已经不在——直接切到刚加的这张
                        if (bgStyle != 4 || !slotUsed(bgPick)) {
                            bgPick = fn;
                            bgStyle = 4;
                        }
                        sp.edit().putInt("bg_style", bgStyle).putInt("bg_pick", bgPick).commit();
                        clearUserThumbs();
                        bgBmp = null;
                        bgBmpStyle = -1;
                        rebuildBg();
                        rebuildMyStrip();
                        paintLook();
                        Toast.makeText(MainActivity.this, "已添加 " + n + " 张",
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }).start();
    }

    private void clearUserThumbs() {
        for (int i = 0; i < USER_MAX; i++) userThumbs[i] = null;
    }

    /** 单张落盘。相册里 8000px 的原图直接解码会 OOM，先算采样率压到 1600px 以内 */
    private boolean writeUserBg(Uri uri, File out) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream is = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(is, null, o);
            is.close();
            if (o.outWidth <= 0 || o.outHeight <= 0) return false;

            int sample = 1;
            while (o.outWidth / sample > 1600 || o.outHeight / sample > 1600) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            // 存的是 JPEG，没有透明通道，565 就够：1600px 的图临时内存从 10MB 降到 5MB，
            // 低端机连续存 8 张时不容易被 GC 打断
            o2.inPreferredConfig = Bitmap.Config.RGB_565;
            is = getContentResolver().openInputStream(uri);
            Bitmap bm = BitmapFactory.decodeStream(is, null, o2);
            is.close();
            if (bm == null) return false;
            FileOutputStream fos = new FileOutputStream(out);
            bm.compress(Bitmap.CompressFormat.JPEG, 88, fos);
            fos.close();
            bm.recycle();
            return out.length() > 0;
        } catch (Throwable t) {
            // 写了一半的文件必须删掉，否则下次启动会拿它当有效图去解码
            try {
                out.delete();
            } catch (Throwable ignored) {
            }
            return false;
        }
    }

    // ---------------- 悬浮球图标 ----------------

    private boolean hasBall() {
        try {
            return new File(getFilesDir(), "ball.png").length() > 0;
        } catch (Throwable t) {
            return false;
        }
    }

    private void chooseBall() {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(i, "选择悬浮球图标"), REQ_BALL);
        } catch (Throwable t) {
            Toast.makeText(this, "打不开相册：" + t.getClass().getSimpleName(),
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * 悬浮球是 52dp，3 倍屏也就 156px，存 256px 足够，再大只是占空间。
     * 用 PNG 保留透明边，圆形裁切后不会有白角。
     */
    private void saveBallImage(final Uri uri) {
        new Thread(new Runnable() {
            public void run() {
                boolean ok = false;
                try {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    InputStream is = getContentResolver().openInputStream(uri);
                    BitmapFactory.decodeStream(is, null, o);
                    is.close();

                    int sample = 1;
                    while (o.outWidth / sample > 256 || o.outHeight / sample > 256) {
                        sample *= 2;
                    }
                    BitmapFactory.Options o2 = new BitmapFactory.Options();
                    o2.inSampleSize = sample;
                    is = getContentResolver().openInputStream(uri);
                    Bitmap bm = BitmapFactory.decodeStream(is, null, o2);
                    is.close();
                    if (bm != null) {
                        FileOutputStream fos = new FileOutputStream(
                                new File(getFilesDir(), "ball.png"));
                        bm.compress(Bitmap.CompressFormat.PNG, 100, fos);
                        fos.close();
                        ok = true;
                    }
                } catch (Throwable ignored) {
                }
                final boolean done = ok;
                runOnUiThread(new Runnable() {
                    public void run() {
                        Toast.makeText(MainActivity.this,
                                done ? "悬浮球图标已更新" : "读取图片失败，换一张试试",
                                Toast.LENGTH_SHORT).show();
                        if (done) restartFloat();
                    }
                });
            }
        }).start();
    }

    private void clearBall() {
        try {
            File f = new File(getFilesDir(), "ball.png");
            if (f.exists()) f.delete();
        } catch (Throwable ignored) {
        }
        Toast.makeText(this, "已恢复默认圆球", Toast.LENGTH_SHORT).show();
        restartFloat();
    }

    /** 悬浮窗的颜色/图标都是 onCreate 时画的，改完只能停掉再起 */
    private void restartFloat() {
        try {
            if (!FloatService.isRunning()) return;
            stopService(new Intent(this, FloatService.class));
            if (ui == null) ui = new Handler(getMainLooper());
            ui.postDelayed(new Runnable() {
                public void run() {
                    startFloat();
                }
            }, 450L);
        } catch (Throwable ignored) {
        }
    }

    // ---------------- 背景层 ----------------
    private void applyLook() {
        if (accentIdx < 0 || accentIdx >= ACCENTS.length) accentIdx = 0;
        if (glassIdx < 0 || glassIdx >= PANELS.length) glassIdx = 1;
        C_ACCENT = ACCENTS[accentIdx];
        // 开关底色是强调色的 40% 透明版
        C_ON = (C_ACCENT & 0x00FFFFFF) | 0x66000000;
        C_PANEL = PANELS[glassIdx];
    }

    private boolean hasUserBg() {
        return firstUsedSlot() >= 0;
    }

    // ---------------- 本机图片（多张，固定 8 个槽位） ----------------

    private File slotFile(int i) {
        return new File(getFilesDir(), "bg_user_" + i + ".jpg");
    }

    private boolean slotUsed(int i) {
        try {
            return i >= 0 && i < USER_MAX && slotFile(i).length() > 0;
        } catch (Throwable t) {
            return false;
        }
    }

    private int userCount() {
        int n = 0;
        for (int i = 0; i < USER_MAX; i++) if (slotUsed(i)) n++;
        return n;
    }

    private int firstUsedSlot() {
        for (int i = 0; i < USER_MAX; i++) if (slotUsed(i)) return i;
        return -1;
    }

    /** 第一个空槽位；返回 -1 表示 8 张都满了 */
    private int firstFreeSlot() {
        for (int i = 0; i < USER_MAX; i++) if (!slotUsed(i)) return i;
        return -1;
    }

    /** 当前在用的本机图；选中的槽位空了就退到第一张，一张都没有返回 null */
    private File currentUserFile() {
        if (slotUsed(bgPick)) return slotFile(bgPick);
        int i = firstUsedSlot();
        return i >= 0 ? slotFile(i) : null;
    }

    private int currentUserSlot() {
        if (slotUsed(bgPick)) return bgPick;
        return firstUsedSlot();
    }

    /** 旧版单张 bg_user.jpg → 0 号槽位。只搬一次，两个都存在时删掉旧的 */
    private void migrateUserBgs() {
        try {
            File old = new File(getFilesDir(), "bg_user.jpg");
            if (old.length() <= 0) return;
            if (!slotUsed(0)) old.renameTo(slotFile(0));
            else old.delete();
        } catch (Throwable ignored) {
        }
    }

    private void rebuildBg() {
        if (bgHolder == null) return;
        bgHolder.removeAllViews();

        if (bgStyle == 1 || bgStyle == 2 || bgStyle == 3) {
            View v = new View(this);
            v.setBackgroundDrawable(linear(gradientColors(bgStyle)));
            // 叠一层光斑，纯线性渐变看着太平
            View glow = new View(this);
            glow.setBackgroundDrawable(glowDrawable(bgStyle));
            FrameLayout wrap = new FrameLayout(this);
            wrap.addView(v, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            wrap.addView(glow, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            bgHolder.addView(wrap, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            return;
        }

        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        // 压暗直接写在图片上：以前是上面再盖一层全屏半透明 View，
        // 等于整屏画两遍。colorFilter 在绘制时乘一次色，省一层合成。
        iv.setColorFilter(0xB8000000);
        bgHolder.addView(iv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        int want = bgWant();
        if (bgBmp != null && bgBmpStyle == want) {
            iv.setImageBitmap(bgBmp);
            return;
        }
        // 没缓存就后台解码。以前在 onCreate 主线程解一张 1600px 的图，
        // 冷启动会白屏几十毫秒；现在窗口底色兜着，图好了再贴上去。
        loadBgAsync(want, currentUserFile());
    }

    /**
     * 当前背景的缓存键：0 = 内置图，100 + 槽位 = 本机图。
     * 渐变（1~3）走 rebuildBg 里的另一条分支，不进这里。
     */
    private int bgWant() {
        return (bgStyle == 4) ? (100 + Math.max(0, currentUserSlot())) : 0;
    }

    private void loadBgAsync(final int want, final File userFile) {
        if (bgLoading == want) return;
        bgLoading = want;
        submit(new Runnable() {
            public void run() {
                // v30 把槽位号加进 want 之后，这里还写着 want == 4，
                // 于是选本机图时一直在解内置图 —— 上传成功、缩略图也有，背景就是不变。
                // 文件在主线程先取好再传进来：后台线程里再取一次，
                // 万一这期间用户换了槽位，就会解到另一张上去
                final Bitmap b = (want >= 100) ? decodeBgFile(userFile) : decodeAssetBg();
                post(new Runnable() {
                    public void run() {
                        if (bgLoading == want) bgLoading = -1;
                        if (b == null) return;
                        // 期间可能又换过背景（或删掉了那张），这张结果就不要了
                        if (want != bgWant()) return;
                        bgBmp = b;
                        bgBmpStyle = want;
                        // 贴到"当前"这张 ImageView：期间 rebuildBg 换过实例时
                        // 按引用比较会漏贴，新图就永远不显示。这里按位置贴。
                        if (bgHolder != null && bgHolder.getChildCount() == 1
                                && bgHolder.getChildAt(0) instanceof ImageView) {
                            ((ImageView) bgHolder.getChildAt(0)).setImageBitmap(b);
                        }
                    }
                });
            }
        });
    }

    /** 背景格子里的缩略图，同样缓存 */
    private Drawable bgPreview(int idx) {
        if (idx >= 1 && idx <= 3) {
            return linear(gradientColors(idx));
        }
        if (idx == 4) {
            int slot = currentUserSlot();
            if (slot < 0) return pill(0x2BFFFFFF, 9);
            if (userThumbs[slot] == null) {
                Bitmap bm = decodeThumb(slotFile(slot), false);
                if (bm != null) userThumbs[slot] = new BitmapDrawable(getResources(), bm);
            }
            return userThumbs[slot] != null ? userThumbs[slot] : pill(0x2BFFFFFF, 9);
        }
        if (assetThumb == null) {
            Bitmap bm = decodeThumb(null, true);
            if (bm != null) assetThumb = new BitmapDrawable(getResources(), bm);
        }
        return assetThumb != null ? assetThumb : pill(0x2BFFFFFF, 9);
    }

    private Drawable linear(int[] colors) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        g.setShape(GradientDrawable.RECTANGLE);
        return g;
    }

    private int[] gradientColors(int style) {
        if (style == 2) {
            return new int[]{0xFF06121F, 0xFF0D2B45, 0xFF12405C};
        }
        if (style == 3) {
            return new int[]{0xFF1A0F24, 0xFF3D1A3A, 0xFF140B1A};
        }
        // 流光：偏中性，带一点粉，和强调色不打架
        return new int[]{0xFF161623, 0xFF3A2033, 0xFF0E1420};
    }

    private Drawable glowDrawable(int style) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        if (style == 2) {
            g.setColors(new int[]{0x442F7FBF, 0x002F7FBF});
        } else if (style == 3) {
            g.setColors(new int[]{0x44A05BC0, 0x00A05BC0});
        } else {
            g.setColors(new int[]{0x44FF5C8A, 0x00FF5C8A});
        }
        g.setGradientCenter(0.3f, 0.12f);
        g.setGradientRadius(dp(520));
        return g;
    }

    // ---------------- 报告页 ----------------

    private View buildReportPage() {
        ScrollView sv = pageScroll();
        LinearLayout col = pageCol(sv);
        LinearLayout p = panel(col);

        Button chk = smallBtn("自检");
        chk.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                selfCheck();
            }
        });
        Button ref = smallBtn("刷新");
        ref.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                refreshReport();
                refreshLog();
                Toast.makeText(MainActivity.this, "已刷新", Toast.LENGTH_SHORT).show();
            }
        });

        section(p, "运行报告", null, chk, ref);
        tvReport = new TextView(this);
        tvReport.setTextSize(12);
        tvReport.setTextColor(C_TEXT);
        tvReport.setLineSpacing(dp(4), 1f);
        tvReport.setTextIsSelectable(true);
        p.addView(tvReport, matchWrapTop(8));

        Button clr = smallBtn("清空");
        clr.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // 用 apply：两万字写盘不该压在点击这一帧上
                sp.edit().remove("buf").apply();
                spLog.edit().remove("buf").apply();
                refreshReport();
                refreshLog();
                Toast.makeText(MainActivity.this, "已清空", Toast.LENGTH_SHORT).show();
            }
        });

        // 反馈入口：不用让用户去别处找群号，报告页里直接给按钮
        section(p, "反馈与加群", "用着有问题、想要新功能，进群说一声，更新也发在群里。");
        Button join = ghost("加入交流群 · " + GROUP_UIN);
        join.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openGroup();
            }
        });
        p.addView(join, matchWrapTop(10));

        section(p, "日志上限", "超过这个行数就自动删掉最旧的记录，只保留最近的。"
                + "上限越小越省内存，日志页翻起来也越快。\n"
                + "说明：eCPM 那一路由核心写入，核心自带 2 万字符上限（约 600 行），"
                + "这里设得比它大也只保留那么多；加速那一路按你设的行数走。", clr);

        LinearLayout capRow = new LinearLayout(this);
        capRow.setOrientation(LinearLayout.HORIZONTAL);
        String[] capNames = {"500 行", "2000 行", "10000 行"};
        for (int i = 0; i < LOG_CAPS.length; i++) {
            TextView b = smallBtn(capNames[i]);
            b.setTextSize(12);
            b.setGravity(Gravity.CENTER);
            b.setMinHeight(dp(40));
            capChips[i] = b;
            final int v = LOG_CAPS[i];
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) {
                    setCap(v);
                }
            });
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) blp.leftMargin = dp(8);
            capRow.addView(b, blp);
        }
        p.addView(capRow, matchWrapTop(10));
        paintCap();

        section(p, "原始日志", "这里只显示最近 " + LOG_LINES + " 行，更早的仍在记录里，"
                + "超出上限才会被删。");
        tvLog = new TextView(this);
        tvLog.setTextSize(11);
        tvLog.setTypeface(Typeface.MONOSPACE);
        tvLog.setTextColor(C_LOG);
        tvLog.setLineSpacing(dp(2), 1f);
        tvLog.setPadding(dp(10), dp(10), dp(10), dp(10));
        tvLog.setTextIsSelectable(true);
        tvLog.setBackgroundDrawable(round(0x4D000000, 10));
        p.addView(tvLog, matchWrapTop(8));
        return sv;
    }

    /** 日志上限的三个档位，选中态 */
    private void paintCap() {
        int cap = Diag.cap(sp);
        for (int i = 0; i < capChips.length; i++) {
            TextView b = capChips[i];
            if (b == null) continue;
            boolean on = (LOG_CAPS[i] == cap);
            b.setBackgroundDrawable(round(on ? C_ON : C_OFF, 12));
            b.setTextColor(on ? 0xFFFFFFFF : C_SUB);
        }
    }

    private void setCap(int v) {
        sp.edit().putInt("log_cap", v).apply();
        paintCap();
        // 立刻按新上限裁一次，不用等下一条日志进来
        trimLogs();
        refreshReport();
        refreshLog();
    }

    /**
     * 按当前上限裁两路日志。
     * 两路来源不同：config.buf 由 LogReceiver 写（它自己会裁），
     * logbuf.buf 由 ConfigProvider 写（smali 里，动不了），所以这里补一刀。
     */
    private void trimLogs() {
        // v28：整段挪进后台。以前这里先在主线程读两路 buf（各两万字）再判断，
        // 进报告页那一下等于主线程多做了两次 4 万字扫描，日志多时能看到卡一帧。
        submit(new Runnable() {
            public void run() {
                try {
                    final int cap = Diag.cap(sp);
                    final String tick = safe(sp.getString("buf", ""));
                    final String ecpm = safe(spLog.getString("buf", ""));
                    if (Diag.lines(tick) <= cap && Diag.lines(ecpm) <= cap) return;
                    String t = Diag.trim(tick, cap, Diag.CAP_CHARS);
                    if (t.length() < tick.length()) {
                        // config.buf 只有 LogReceiver 和这里会写，同一把锁就够了
                        synchronized (Diag.LOCK) {
                            String now = safe(sp.getString("buf", ""));
                            // 期间又来了新日志，快照已经过期，这次放弃，下次再裁
                            if (now.equals(tick)) sp.edit().putString("buf", t).apply();
                        }
                    }
                    String e = Diag.trim(ecpm, cap, Diag.CAP_CHARS);
                    if (e.length() < ecpm.length()) {
                        // logbuf 由 ConfigProvider（smali，动不了）写，没法共用锁，
                        // 只能在写回前再读一次比对：内容变了就说明有新记录，放弃这次裁剪
                        String now = safe(spLog.getString("buf", ""));
                        if (now.equals(ecpm)) spLog.edit().putString("buf", e).apply();
                    }
                } catch (Throwable ignored) {
                }
            }
        });
    }

    /**
     * 配置自检。只验证模块自己的 provider 是否正常，用来区分两类问题：
     *  - 这里就异常 / 0 行  -> ConfigProvider 本身有问题，查 manifest 的 exported 和 smali
     *  - 这里正常           -> provider 没问题，是目标进程跨进程被拦，
     *                          那就靠 XSharedPreferences 通道，日志里会显示 cfg: xsp
     */
    private void selfCheck() {
        StringBuilder sb = new StringBuilder();
        sb.append("自检 ").append(nowStr()).append("\n");
        sb.append("本地配置 speed=").append(sp.getBoolean("speed_enabled", true))
                .append(" smart=").append(sp.getBoolean("smart_enabled", true)).append("\n");
        sb.append("版本 ").append(verName()).append(" / API ").append(Build.VERSION.SDK_INT).append("\n");
        sb.append("悬浮窗 ").append(FloatService.isRunning() ? "运行中" : "未运行")
                .append(canOverlay() ? " / 有权限" : " / 无权限").append("\n");
        sb.append("日志 config=").append(safe(sp.getString("buf", "")).length())
                .append(" 字 / logbuf=").append(safe(spLog.getString("buf", "")).length())
                .append(" 字\n");

        android.database.Cursor c = null;
        try {
            c = getContentResolver().query(
                    android.net.Uri.parse("content://nn.ecpm.config/config"),
                    null, null, null, null);
            if (c == null) {
                sb.append("Provider: 返回 null（exported 或进程问题）\n");
            } else {
                int ik = c.getColumnIndex("k");
                int iv = c.getColumnIndex("v");
                sb.append("Provider: ").append(c.getCount()).append(" 行");
                if (ik >= 0 && iv >= 0 && c.moveToFirst()) {
                    sb.append(" [");
                    do {
                        sb.append(c.getString(ik)).append("=").append(c.getString(iv)).append(" ");
                    } while (c.moveToNext());
                    sb.append("]");
                }
                sb.append("\n");
            }
        } catch (Throwable t) {
            sb.append("Provider: 异常 ").append(t.getClass().getSimpleName()).append("\n");
        } finally {
            if (c != null) {
                try {
                    c.close();
                } catch (Throwable ignored) {
                }
            }
        }
        sb.append("提示：目标 App 日志里 cfg: 开头那行才是真正生效的通道");
        if (tvReport != null) {
            shownReport = sb.toString();
            tvReport.setText(shownReport);
        }
    }

    /**
     * 运行报告。数字从日志正文里数出来，日志本身有 2 万字上限，
     * 所以是「最近这一段」而不是累计值。
     *
     * 口径（v22 修正）：EcpmHook.emit 只把 "[EcpmRange] " 前缀加在 logcat 那一行，
     * 广播和 provider 传的是**不带前缀**的原文，所以不能用前缀判断。
     * 真实改写记录长这样：old -> new。
     */
    private void refreshReport() {
        if (tvReport == null) return;
        final String ecpm = safe(spLog.getString("buf", ""));
        final String tick = safe(sp.getString("buf", ""));
        final long min = sp.getLong("min", 100000L);
        final long max = sp.getLong("max", 130000L);
        final boolean sOn = sp.getBoolean("speed_enabled", true);
        final boolean mOn = sp.getBoolean("smart_enabled", true);
        final int seq = ++reportSeq;
        // 两万字切行 + 统计放后台：这段在主线程跑，日志一多切到报告页会顿
        if (!submit(new Runnable() {
            public void run() {
                final String text = composeReport(ecpm, tick, min, max, sOn, mOn);
                post(new Runnable() {
                    public void run() {
                        if (seq != reportSeq || tvReport == null) return;
                        if (text.equals(shownReport)) return;
                        shownReport = text;
                        tvReport.setText(text);
                    }
                });
            }
        })) return;
    }

    /** 线程池在 onDestroy 之后就关了，晚到的刷新直接丢掉，不要往已销毁的界面里塞 */
    private boolean submit(Runnable r) {
        try {
            io.execute(r);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private void post(Runnable r) {
        if (ui == null) return;
        ui.post(r);
    }

    private static String composeReport(String ecpm, String tick, long min, long max,
                                       boolean sOn, boolean mOn) {
        int ecpmCnt = 0;
        int plusCnt = 0;
        int ecpmOther = 0;
        String lastEcpm = "";
        for (String line : ecpm.split("\n")) {
            String t = line.trim();
            if (t.length() == 0) continue;
            if (t.indexOf(" -> ") > 0) {
                ecpmCnt++;
                // 「补充 」是 v34 的扩展层写的，单独标出来，方便判断是谁改的
                if (t.startsWith("补充 ")) plusCnt++;
                lastEcpm = t;
            } else {
                ecpmOther++;
            }
        }

        int tickCnt = 0;
        int cfgCnt = 0;
        String lastCfg = "";
        for (String line : tick.split("\n")) {
            if (line.indexOf("FastTick") >= 0) tickCnt++;
            int ci = line.indexOf("cfg:");
            if (ci >= 0) {
                cfgCnt++;
                lastCfg = line.substring(ci).trim();
            }
        }

        StringBuilder b = new StringBuilder();
        // 三个 0 的时候整段数字没必要占地方，直接给结论
        if (ecpmCnt == 0 && ecpmOther == 0 && tickCnt == 0 && cfgCnt == 0) {
            b.append("还没有任何记录。确认三件事：\n")
                    .append("1. LSPosed 里勾选了目标应用\n")
                    .append("2. 勾选后重启过目标应用（不是回到桌面）\n")
                    .append("3. 目标应用里有穿山甲 / 优量汇 / 百度的广告 SDK");
            b.append("\n\n区间 ").append(min).append(" ~ ").append(max).append(" 分")
                    .append("　开关 ")
                    .append(sOn ? "加速开" : "加速关")
                    .append(" / ")
                    .append(mOn ? "智能开" : "智能关");
            return b.toString();
        }

        b.append("eCPM 改写    ").append(ecpmCnt).append(" 次");
        if (plusCnt > 0) {
            // 括号里是扩展层（带参 getter / price|bid|revenue / BigDecimal）贡献的
            b.append("（其中扩展 ").append(plusCnt).append(" 次）");
        }
        b.append("\n");
        if (ecpmOther > 0) {
            b.append("其他记录    ").append(ecpmOther).append(" 条\n");
        }
        b.append("加速注入    ").append(tickCnt).append(" 条\n");
        b.append("配置刷新    ").append(cfgCnt).append(" 次\n");
        b.append("区间        ").append(min).append(" ~ ").append(max).append(" 分\n");
        b.append("开关        ").append(sOn ? "加速开" : "加速关")
                .append(" / ").append(mOn ? "智能开" : "智能关");

        if (lastCfg.length() > 0) {
            b.append("\n当前通道    ").append(lastCfg);
        }
        if (lastEcpm.length() > 0) {
            b.append("\n最近改写    ").append(lastEcpm);
        }
        return b.toString();
    }

    /**
     * 两路日志合并显示。
     *  config.buf  <- 加速内核（PlayerScan 走广播，LogReceiver / 动态接收器写入）
     *  logbuf.buf  <- eCPM（EcpmHook 走 provider insert，ConfigProvider 写入）
     *
     * 按行截断而不是按字符：以前 tail(s, 6000) 会从中间切开，
     * 屏幕上第一行是半截 UTF-8 / 半行英文，看着像乱码。
     */
    private void refreshLog() {
        if (tvLog == null) return;
        final String tick = safe(sp.getString("buf", ""));
        final String ecpm = safe(spLog.getString("buf", ""));
        final int seq = ++logSeq;
        submit(new Runnable() {
            public void run() {
                final String text = composeLog(tick, ecpm);
                post(new Runnable() {
                    public void run() {
                        if (seq != logSeq || tvLog == null) return;
                        if (text.equals(shownLog)) return;
                        shownLog = text;
                        tvLog.setText(text);
                    }
                });
            }
        });
    }

    private static String composeLog(String tick, String ecpm) {
        if (tick.length() == 0 && ecpm.length() == 0) {
            return "还没有日志。勾选目标应用并重启它之后，这里会出现两段记录。";
        }
        StringBuilder sb = new StringBuilder();
        if (ecpm.length() > 0) {
            sb.append("——— eCPM ———\n").append(tailLines(ecpm, LOG_LINES)).append("\n");
        }
        if (tick.length() > 0) {
            sb.append("——— 加速 ———\n").append(tailLines(tick, LOG_LINES));
        }
        return sb.toString();
    }

    // ---------------- 保存 ----------------

    /**
     * @param withRange 是否同时写入 eCPM 上下限。
     * 加速页的保存不该校验这两个输入框 —— 以前不分页，现在分了页，
     * 用户在加速页点保存时若 eCPM 输入框是空的，会莫名弹「请填入有效的整数」。
     */
    private void doSave(boolean withRange) {
        long min = sp.getLong("min", 100000L);
        long max = sp.getLong("max", 130000L);
        if (withRange) {
            if (etMin == null || etMax == null) return;
            try {
                min = Long.parseLong(etMin.getText().toString().trim());
                max = Long.parseLong(etMax.getText().toString().trim());
            } catch (Throwable t) {
                Toast.makeText(this, "请填入有效的整数", Toast.LENGTH_SHORT).show();
                return;
            }
            if (min < 0 || max < 0) {
                Toast.makeText(this, "数值不能为负数", Toast.LENGTH_SHORT).show();
                return;
            }
            if (min > max) {
                Toast.makeText(this, "最小值不能大于最大值", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        SharedPreferences.Editor e = sp.edit()
                .putBoolean("speed_enabled", speedOn)
                .putBoolean("smart_enabled", smartOn)
                .putBoolean("skip_non_positive", skipOn);
        if (withRange) {
            e.putLong("min", min).putLong("max", max);
        }
        boolean ok = e.commit();

        if (ok) {
            relaxPrefs();
            // 保存后立刻刷新，否则报告里的区间/开关要退出重进才更新
            refreshReport();
            updateSpeedMode();
            Toast.makeText(this, "已保存，目标应用最多 10 秒读到", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "保存失败，请重试", Toast.LENGTH_SHORT).show();
        }
    }

    /** 配置要能被其他进程读到，沿用原实现的 chmod 策略 */
    private void relaxPrefs() {
        try {
            File dir = new File(getFilesDir().getParentFile(), "shared_prefs");
            File f = new File(dir, "config.xml");
            if (f.exists()) {
                f.setReadable(true, false);
            }
        } catch (Throwable ignored) {
        }
    }

    // ---------------- 悬浮窗 ----------------

    private void setFloat(boolean on) {
        floatOn = on;
        sp.edit().putBoolean("float_on", on).apply();
        if (!on) {
            try {
                stopService(new Intent(this, FloatService.class));
            } catch (Throwable ignored) {
            }
            refreshToggles();
            return;
        }
        if (!canOverlay()) {
            Toast.makeText(this, "请先允许「显示在其他应用上层」", Toast.LENGTH_LONG).show();
            requestOverlay();
            refreshToggles();
            return;
        }
        startFloat();
        refreshToggles();
    }

    private boolean canOverlay() {
        try {
            return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
        } catch (Throwable t) {
            return false;
        }
    }

    private void requestOverlay() {
        try {
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())), REQ_OVERLAY);
            return;
        } catch (Throwable ignored) {
        }
        try {
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION),
                    REQ_OVERLAY);
        } catch (Throwable t) {
            Toast.makeText(this, "无法打开悬浮窗设置，请手动到系统设置里开启", Toast.LENGTH_LONG).show();
        }
    }

    private void startFloat() {
        try {
            Intent i = new Intent(this, FloatService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } catch (Throwable t) {
            Toast.makeText(this, "悬浮窗启动失败：" + t.getClass().getSimpleName(),
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_IMAGE) {
            if (res == RESULT_OK && data != null) {
                java.util.ArrayList<Uri> uris = new java.util.ArrayList<Uri>();
                // 多选走 clipData，单选走 data；有的图库两个都给，这里以 clipData 为准
                android.content.ClipData cd = data.getClipData();
                if (cd != null) {
                    for (int i = 0; i < cd.getItemCount(); i++) {
                        Uri u = cd.getItemAt(i).getUri();
                        if (u != null) uris.add(u);
                    }
                } else if (data.getData() != null) {
                    uris.add(data.getData());
                }
                if (!uris.isEmpty()) saveUserBgs(uris);
            }
            return;
        }
        if (req == REQ_BALL) {
            if (res == RESULT_OK && data != null && data.getData() != null) {
                saveBallImage(data.getData());
            }
            return;
        }
        if (req != REQ_OVERLAY) return;
        if (canOverlay()) {
            if (sp.getBoolean("float_on", false)) startFloat();
        } else {
            // 用户拒了权限：把意图也清掉，否则每次 onResume 都会重弹
            sp.edit().putBoolean("float_on", false).apply();
            Toast.makeText(this, "没有悬浮窗权限，已保持关闭", Toast.LENGTH_SHORT).show();
        }
        refreshToggles();
    }

    private void refreshToggles() {
        paint(bSpeedY, speedOn);
        paint(bSpeedN, !speedOn);
        paint(bSmartY, smartOn);
        paint(bSmartN, !smartOn);
        paint(bSkipY, skipOn);
        paint(bSkipN, !skipOn);
        // 只看用户意图，不看服务运行状态：startForegroundService 是异步的，
        // 刚点完「是」那一瞬间服务还没起来，按运行状态画会把按钮又画回「否」。
        floatOn = sp.getBoolean("float_on", false);
        paint(bFloatY, floatOn);
        paint(bFloatN, !floatOn);
        refreshFloatState();
    }

    // ---------------- 广播 ----------------

    /** hook 端通过 nn.ecpm.LOG 广播发日志，这里只负责刷新显示，落盘交给清单里的 LogReceiver */
    private void registerLogRx() {
        try {
            logRx = new BroadcastReceiver() {
                public void onReceive(Context c, Intent i) {
                    // 加速内核在目标应用里每次注入都会广播一次，日志密集时
                    // 以前每次都 postDelayed 一个新任务，主线程排几十个重复刷新 —— 直接卡。
                    // 现在 250ms 内只留最后一个。
                    scheduleRefresh();
                }
            };
            IntentFilter f = new IntentFilter("nn.ecpm.LOG");
            // targetSdk 34 起必须显式声明导出标志，否则 registerReceiver 直接抛 SecurityException。
            // 三参数重载在 API 21 的编译桩里没有，走反射；失败再退回两参数。
            try {
                getClass().getMethod("registerReceiver", BroadcastReceiver.class,
                                IntentFilter.class, int.class)
                        .invoke(this, logRx, f, Integer.valueOf(2));
            } catch (Throwable t2) {
                registerReceiver(logRx, f);
            }
        } catch (Throwable ignored) {
        }
    }

    private void scheduleRefresh() {
        if (ui == null) return;
        if (logRefresh == null) {
            logRefresh = new Runnable() {
                public void run() {
                    refreshReport();
                    refreshLog();
                    refreshStatus();
                }
            };
        }
        ui.removeCallbacks(logRefresh);
        ui.postDelayed(logRefresh, 250L);
    }

    // ---------------- UI helpers ----------------

    /**
     * 读内置背景。
     * 以前是 decodeStream 全尺寸：一张 4000px 的 bg.jpg 解码成 ARGB_8888 就是 64MB，
     * 低端机直接 OOM。现在先只读尺寸算采样率，再按屏幕大小解码。
     */
    private Bitmap decodeAssetBg() {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream is = getAssets().open("bg.jpg");
            BitmapFactory.decodeStream(is, null, o);
            is.close();

            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sampleFor(o.outWidth, o.outHeight);
            // 背景图没有透明通道，565 就够：同样的图内存直接减半，
            // 低端机上这一下能省出好几 MB
            o2.inPreferredConfig = Bitmap.Config.RGB_565;
            is = getAssets().open("bg.jpg");
            Bitmap bm = BitmapFactory.decodeStream(is, null, o2);
            is.close();
            return bm;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private Bitmap decodeBgFile(File f) {
        try {
            if (f == null || !f.exists() || f.length() == 0) return null;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sampleFor(o.outWidth, o.outHeight);
            o2.inPreferredConfig = Bitmap.Config.RGB_565;
            return BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
        } catch (Throwable t) {
            return null;
        }
    }

    /** 缩略图固定 1/8 采样，asset 与文件两条来源 */
    private Bitmap decodeThumb(File f, boolean asset) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 8;
            if (asset) {
                InputStream is = getAssets().open("bg.jpg");
                Bitmap bm = BitmapFactory.decodeStream(is, null, o);
                is.close();
                return bm;
            }
            if (f == null || !f.exists() || f.length() == 0) return null;
            return BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        } catch (Throwable t) {
            return null;
        }
    }

    /** 按屏幕尺寸算采样率；宽高为 0（解码失败）时退回 1 */
    private int sampleFor(int w, int h) {
        int tw = getResources().getDisplayMetrics().widthPixels;
        int th = getResources().getDisplayMetrics().heightPixels;
        if (tw <= 0) tw = 1080;
        if (th <= 0) th = 1920;
        int s = 1;
        while (w > 0 && h > 0 && (w / s > tw || h / s > th) && s < 32) {
            s *= 2;
        }
        return s;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    /** 内容最大宽度 560dp，超出部分均分到左右内边距，平板/折叠屏上不会拉成一条长条 */
    private int hPad() {
        int w = getResources().getDisplayMetrics().widthPixels;
        int max = dp(560);
        int p = (w - max) / 2;
        return Math.max(dp(16), p);
    }

    /** 不带描边的圆角，给底部指示条这类小色块用 */
    private Drawable pill(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private Drawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(1, C_STROKE);
        return g;
    }

    private ScrollView pageScroll() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setClipToPadding(false);
        sv.setVerticalScrollBarEnabled(false);
        // 关掉边缘拉伸光效：多一层绘制，而且和背景图叠在一起会花
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(hPad(), dp(6), hPad(), dp(18));
        sv.addView(col, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return sv;
    }

    private LinearLayout pageCol(ScrollView sv) {
        return (LinearLayout) sv.getChildAt(0);
    }

    /** 一整页只有这一块面板 */
    private LinearLayout panel(LinearLayout parent) {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackgroundDrawable(round(C_PANEL, 18));
        p.setPadding(dp(16), dp(14), dp(16), dp(14));
        parent.addView(p, matchWrapTop(4));
        panels.add(p);
        return p;
    }

    /**
     * 面板内的小节标题。第一节不加分隔线，之后每节前面补一条，
     * 这样整页看起来是一块连续的板子，而不是几张叠起来的卡。
     */
    private void section(LinearLayout p, String title, String desc, Button... actions) {
        if (p.getChildCount() > 0) divider(p);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextSize(14);
        t.setTextColor(C_TITLE);
        head.addView(t, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (actions != null) {
            for (Button a : actions) {
                if (a == null) continue;
                LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
                alp.leftMargin = dp(6);
                head.addView(a, alp);
            }
        }
        p.addView(head);

        if (desc != null && desc.length() > 0) {
            TextView d = new TextView(this);
            d.setText(desc);
            d.setTextSize(11);
            d.setTextColor(C_SUB);
            d.setLineSpacing(dp(3), 1f);
            d.setPadding(0, dp(6), 0, 0);
            p.addView(d);
        }
    }

    private void divider(LinearLayout p) {
        View d = new View(this);
        d.setBackgroundColor(C_DIV);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        lp.topMargin = dp(13);
        lp.bottomMargin = dp(13);
        p.addView(d, lp);
    }

    /** 面板底部的说明小字，带一点上边距 */
    private TextView footnote(LinearLayout p, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(11);
        t.setTextColor(C_SUB);
        t.setLineSpacing(dp(2), 1f);
        t.setPadding(0, dp(10), 0, 0);
        p.addView(t);
        return t;
    }

    private LinearLayout segRow(Button yes, Button no) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.addView(yes, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        View gap = new View(this);
        r.addView(gap, new LinearLayout.LayoutParams(dp(10), 1));
        r.addView(no, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return r;
    }

    private Button toggleBtn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setMinHeight(dp(44));
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(0, dp(10), 0, dp(10));
        // 系统字体放大到 1.3 倍时「是/否」会被挤成两行，高度就撑开了
        b.setSingleLine(true);
        b.setEllipsize(android.text.TextUtils.TruncateAt.END);
        return b;
    }

    private void paint(Button b, boolean active) {
        if (b == null) return;
        b.setBackgroundDrawable(round(active ? C_ON : C_OFF, 12));
        b.setTextColor(active ? 0xFFFFFFFF : C_SUB);
    }

    private Button primary(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundDrawable(round(C_ON, 14));
        b.setMinHeight(dp(48));
        // 系统字体放到最大时按钮文字会挤成两行，这里限一行
        b.setSingleLine(true);
        b.setEllipsize(android.text.TextUtils.TruncateAt.END);
        primaries.add(b);
        return b;
    }

    private Button ghost(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTextColor(C_TEXT);
        b.setBackgroundDrawable(round(C_FIELD, 12));
        b.setMinHeight(dp(44));
        return b;
    }

    private Button smallBtn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setTextColor(C_TEXT);
        b.setBackgroundDrawable(round(C_FIELD, 10));
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(13), dp(4), dp(13), dp(4));
        b.setMinHeight(dp(34));
        b.setSingleLine(true);
        b.setEllipsize(android.text.TextUtils.TruncateAt.END);
        return b;
    }

    private EditText field(String value) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setTextColor(0xF2FFFFFF);
        e.setHintTextColor(0x66FFFFFF);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setBackgroundDrawable(null);
        e.setPadding(0, dp(8), 0, dp(8));
        return e;
    }

    /** 输入框外面套一个固定标签，框里有值时标签也一直显示 */
    private LinearLayout labelRow(String label, EditText e) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setBackgroundDrawable(round(C_FIELD, 12));
        r.setPadding(dp(14), 0, dp(14), 0);

        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(12);
        t.setTextColor(C_SUB);
        // 原来是固定 58dp，系统字体放大后「最小值」三个字会被截掉，改成最小宽度
        t.setMinWidth(dp(58));
        r.addView(t);
        r.addView(e, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return r;
    }

    private LinearLayout.LayoutParams matchWrapTop(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(top);
        return lp;
    }

    /**
     * 页面是懒加载的，每个 buildXxxPage 建完自己调一次。
     * 全部判空：加速页没建的时候 bSkipY 还是 null。
     */
    private void bindToggles() {
        if (bSpeedY != null) {
            bSpeedY.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    speedOn = true;
                    refreshToggles();
                }
            });
        }
        if (bSpeedN != null) {
            bSpeedN.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    speedOn = false;
                    refreshToggles();
                }
            });
        }
        if (bSmartY != null) {
            bSmartY.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    smartOn = true;
                    refreshToggles();
                    updateSpeedMode();
                }
            });
        }
        if (bSmartN != null) {
            bSmartN.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    smartOn = false;
                    refreshToggles();
                    updateSpeedMode();
                }
            });
        }
        if (bSkipY != null) {
            bSkipY.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    skipOn = true;
                    refreshToggles();
                }
            });
        }
        if (bSkipN != null) {
            bSkipN.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    skipOn = false;
                    refreshToggles();
                }
            });
        }
        if (bFloatY != null) {
            bFloatY.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    setFloat(true);
                }
            });
        }
        if (bFloatN != null) {
            bFloatN.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    setFloat(false);
                }
            });
        }
        // 页面是懒建的，建完得把选中态补上：onCreate 里那次 paint 时按钮还不存在
        refreshToggles();
    }

    // ---------------- 杂项 ----------------

    private String nowStr() {
        try {
            return new java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.US)
                    .format(new java.util.Date());
        } catch (Throwable t) {
            return "";
        }
    }

    private String verName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Throwable t) {
            return "?";
        }
    }

    private static String safe(String s) {
        return s == null ? "" : s;
    }

    /** 取最后 n 行，按行切不会把一行里的字符截断 */
    private static String tailLines(String s, int n) {
        if (s == null || s.length() == 0) return "";
        String[] lines = s.split("\n");
        if (lines.length <= n) return s;
        StringBuilder b = new StringBuilder();
        for (int i = lines.length - n; i < lines.length; i++) {
            if (b.length() > 0) b.append('\n');
            b.append(lines[i]);
        }
        return b.toString();
    }
}
