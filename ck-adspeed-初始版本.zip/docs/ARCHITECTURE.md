# 架构

## 分层

```
                    ┌─────────────────────────────┐
                    │  LSPosed（框架，非本仓库）   │
                    └──────────────┬──────────────┘
                                   │ 读 assets/xposed_init
          ┌────────────────────────┼────────────────────────┐
          ▼                        ▼                        ▼
┌──────────────────┐   ┌────────────────────┐   ┌──────────────────┐
│ PlayerScan       │   │ EcpmHook（smali）   │   │ EcpmPlus         │
│ classes7.dex     │   │ classes2.dex（基线）│   │ classes8.dex     │
│ 加速内核          │   │ eCPM 主判定         │   │ eCPM 补充层       │
└────────┬─────────┘   └─────────┬──────────┘   └────────┬─────────┘
         │                       │                        │
         │ 写 SharedPreferences  │ 读 content://nn.ecpm.config
         │ + 广播 nn.ecpm.LOG    │                        │
         ▼                       ▼                        ▼
┌─────────────────────────────────────────────────────────────────┐
│ classes8.dex：MainActivity / FloatService / LogReceiver / Diag  │
└─────────────────────────────────────────────────────────────────┘
```

三个入口互相独立：`PlayerScan` 排第一，因为 `EcpmHook` 在个别 ROM 上初始化会抛，不能把加速内核一起带下去。

## 加速内核（PlayerScan）

### 安装顺序

```
handleLoadPackage
├── hookContext()      先挂 Context，配置通道从第一条 hook 起可用
├── hookTimerLike()    Handler / Timer / CountDownTimer / ScheduledExecutor
├── hookAnimator()     仅非游戏进程
├── hookStart()        Activity / Service 启动时机
├── hookPlayers()      播放器倍速
└── hookScan()         类加载扫描，兜底找未覆盖的播放器
```

顺序有意义：`hookContext` 最早，因为后面任何 hook 都可能需要读配置。

### 一条延时被 hook 到的完整链路

```
App 调 postDelayed(5000)
   │
   ├─ enterForward() → 深度 0→1，返回 true（最外层）
   │     scale() 把 5000 改成 5000/2.5 = 2000
   │
   ├─ Handler 内部调 sendMessageDelayed(2000)
   │     enterForward() → 深度 1→2，返回 false，放行
   │
   └─ 再调 sendMessageAtTime(now+2000)
         enterForward() → 深度 2→3，返回 false，放行
   afterHookedMethod 逐层 leaveForward()，深度归零
```

**为什么必须这样做**：三层各缩一次的话，5000 → 2000 → 800 → 320，实际 15.6×。深度计数保证只有最外层动手。

**为什么不用 0/1 标志**：任何一条路径没走 `after`（ROM 改写实现、异常栈、被别的模块拦断），标志就永久为 1，之后所有延时被静默放过。表现是"用着用着突然不加速了"，而且没有任何日志。

### 倍率决策

```
rateFor(ms)
├── 游戏进程：只碰 ≥2000ms，倍率上限 2.0
└── 普通进程：只碰 ≥600ms
     ├── ≥15000 → 3.0
     ├── ≥6000  → 2.5
     ├── ≥2500  → 2.0
     ├── ≥1200  → 1.5
     └── <1200  → 1.0（交给 loopRate）
```

`loopRate` 处理"单次看太短、但明显在循环"的场景（广告倒计时每秒一次）：

```
同调用点、同量级参数、5 秒内出现第 2 次 → 认定循环
  ├── 参数 ≤1600ms → 普通 2.5× / 游戏 2.0×
  └── 更长          → rateFor(v × 8)
```

key 是 `调用方类名#方法名`，不是 `Method` 对象。否则全 App 的 `postDelayed` 共用一条统计。

### 熔断

```
hook 回调抛异常 → GUARD++
GUARD >= 120    → disabled = true
                  所有回调首行 `if (disabled) return;`
                  写一条 guard 日志
```

不重置、不自动恢复。要恢复只能重启目标 App。宁可没效果，也不能把宿主拖崩。

## eCPM 两层

| | EcpmHook（基线） | EcpmPlus（本仓库） |
|---|---|---|
| 位置 | `classes2.dex` | `classes8.dex` |
| 触发 | 启动扫描固定类名 | hook `ClassLoader.loadClass`，动态截获 |
| 匹配 | 无参 + 方法名含 `cpm` + 返回 String/int/long/double/float | 加带参 getter、`price`/`bid`/`revenue` 类方法、`BigDecimal` 返回 |
| 配置 | **只在启动读一次** | 每 10 秒反射写回三字段，热更新 |
| 覆盖面 | 35 条 RAW + 52 条前缀 | 补充主 hook 盲区（`mainCovers` 先排除已覆盖组合） |

`EcpmPlus` 的设计前提是**不改基线字节码**：它通过 hook `EcpmHook.emit` 拿到主 hook 实例，再反射写 `ecpmMin` / `ecpmMax` / `skipNonPositive`。

这条路径解决的是基线的一个真实缺陷——`configLoaded` 一旦为 true 就永不重读，界面改完区间必须重启目标 App 才生效。

## 状态回执

界面不能靠"猜进程"判断模块有没有工作。两个时间戳分开：

| 键 | 写入时机 | 界面显示 |
|---|---|---|
| `tick_ts` | 内核任意活动（含"注入成功"那条） | `已注入，未见加速` |
| `speed_ts` | 真的缩过时间（`tick: 缩时 N 次`） | `加速中` |

日志走 `content://nn.ecpm.config/log`，核心侧硬编码 2 万字符上限（约 600 行），超出丢最旧的整行。

## 配置通道

统一走 `SharedPreferences("config")`，`ConfigProvider` 以 `content://nn.ecpm.config/config` 暴露给目标进程——跨进程 `SharedPreferences` 不可靠，必须走 ContentProvider。

写入用 `commit()` 而不是 `apply()`：界面改完立刻要读回，`apply()` 的异步落盘会读到旧值。
