# 构建说明

## 0. 环境

```bash
export ANDROID_HOME=$HOME/Android/Sdk
export BT=$ANDROID_HOME/build-tools/34.0.0
export ANDROID_JAR=$ANDROID_HOME/platforms/android-34/android.jar
export APKTOOL=$HOME/apktool_2.9.3.jar
```

必须有：`javac`（JDK 8~17）、`d8`、`zipalign`、`apksigner`。只有完整打包需要 `apktool`。

检查：

```bash
for t in d8 zipalign apksigner; do test -x "$BT/$t" || echo "缺少 $t"; done
javac -version
```

## 1. 三条构建路径

| 脚本 | 需要基线 APK | 产物 | 用途 |
|---|---|---|---|
| `build-kernel-only.sh` | 否 | `build/kernel.jar`、`build/dex/classes.dex` | 只改内核、验证编译、CI |
| `build.sh` | 是 | 完整 APK | 热修：只替换 `classes7.dex`，其余 dex 原样保留 |
| `build_full.sh` | 是 | 完整 APK | 全量：内核 + 界面 + 清单 + 资源 + 版本号 |

### 1.1 只编内核

```bash
./build-kernel-only.sh
```

### 1.2 热修（只换内核 dex）

```bash
KS_PASS='你的口令' ./build.sh baseline.apk out.apk ./release.keystore release
```

做的事：`javac` → `d8` → 解包基线 APK → 覆盖 `classes7.dex` → `zipalign -p 4` → v1+v2+v3 签名。

### 1.3 全量

```bash
VER_CODE=36 VER_NAME=3.6 KS_PASS='你的口令' \
  ./build_full.sh baseline.apk out.apk ./release.keystore release
```

七步：编译内核 → 编译界面 → apktool 解包 → 换 `classes7/8.dex` + 写 `xposed_init` → 改清单与版本 → 重打包对齐 → 签名。

## 2. 产物结构

`build_full.sh` 输出的是一个**在原包基础上替换了两个 dex** 的 APK：

| 文件 | 来源 | 说明 |
|---|---|---|
| `classes.dex ~ classes6.dex` | 基线 APK 原样 | 一字节未改，含 `EcpmHook`（在 `classes2.dex`） |
| `classes7.dex` | `src-java/` | 加速内核 |
| `classes8.dex` | `src-ui/` | 界面 + `EcpmPlus` |
| `assets/xposed_init` | 构建时写入 | 三行入口 |

**界面 dex 不允许分包**：超过 64K 方法时 `d8` 会分出 `classes2.dex`，脚本会直接报错退出——否则 `classes8.dex` 只装了一半的类，运行时报 `NoClassDefFoundError`。

## 3. 签名

```bash
keytool -genkeypair -v -keystore release.keystore -alias release \
  -keyalg RSA -keysize 2048 -validity 10000
```

口令**只走环境变量**。`build.sh` / `build_full.sh` 里没有任何默认值，不设 `KS_PASS` 会直接报错退出——这是故意的，防止把口令写进脚本再提交。

`release.keystore` 已在 `.gitignore` 中。**已经被提交过的密钥无法通过删除文件抹掉**，必须用 `git filter-repo` 重写历史并更换密钥。

## 4. 常见错误

| 现象 | 原因 | 处理 |
|---|---|---|
| `javac: 找不到符号 de.robv...` | 没带 `-cp lib/stub.jar` | 检查脚本里的 classpath |
| `INSTALL_PARSE_FAILED_NO_CERTIFICATES` | 签名缺失或 v2 未开 | `apksigner verify` 看输出 |
| `INSTALL_FAILED_INVALID_APK` | `resources.arsc` 被压缩 | 必须 `zip -0` 存储；`build.sh` 已处理 |
| 安装后模块不生效 | 未在 LSPosed 勾选，或目标 App 未重启 | 勾选 → 强制停止目标 App → 重开 |
| 界面 dex 分包报错 | 方法数超 64K | 拆类或改用 multidex 方案 |
| `zipalign -c 4` 失败 | 打包后又改过文件 | 重新 `zipalign -f -p 4` |

## 5. 基线 APK

`build.sh` / `build_full.sh` 的第一个参数是**上游发布的原始安装包**。

本仓库不提供、不附带、不镜像这个文件（版权原因，见 `NOTICE.md`）。没有它就只能走 `build-kernel-only.sh`。

如果你只是想验证代码能不能编，用 `build-kernel-only.sh` 就够了。
