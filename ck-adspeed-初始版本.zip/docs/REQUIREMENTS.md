# 改版铁律（每次动手前先读一遍）

用户反复强调过的要求，任何一版都不能违背。

## 一、交互与界面

1. **每个功能都要有底部栏入口**，不能藏在二级页面或只有长按才能进。
2. **同一页只允许一块面板**（圆角卡片），内部用 1px 分隔线划小节；不要拆成多张卡，
   卡片缝里露出背景图会显得很碎。
3. **底部导航必须是透明的**（v28 起）：底栏不铺任何底色，整条透出背景图，
   只留一条 `0x1AFFFFFF` 的 1px 分隔线。
   透明之后文字直接压在图上，所以每个 tab 字都要带阴影
   （`setShadowLayer(6f, 0, 1f, 0xB3000000)`），未选中 `C_NAV = 0xE6FFFFFF`，
   选中用"强调色纯色 + 粗体"。不许改回不透明底色，也不许用 0xA0 这类半透明白。
4. 配色跟"外观"页走：强调色 4 选 1、面板浓度 3 档、背景图 5 种（含本机图片上传）。
   **改完当场重画（`repaintAll()`），不许 `recreate()`** —— 整页重建会闪、会丢滚动位置。
5. **要有悬浮窗**，不能什么都靠挂后台；悬浮球可拖动、贴边自动挪回屏内、可展开面板。

## 二、核心与稳定性

1. **eCPM 判定与加速内核是核心，不许动**。要扩展覆盖面只能在**独立补充层**里加
   （v34 起为 `nn.ecpm.EcpmPlus`，独立入口、单独类），不许改 `EcpmHook` 本体、
   不许改 `PlayerScan` 的判定与倍率。补充层还必须主动避开主 hook 已覆盖的组合
   （无参 + 名字含 cpm + 非 BigDecimal），同一个方法不许被改两次。
   每版构建后必须比对 `classes.dex` ~ `classes7.dex` 与上一版 md5，必须完全一致。
2. 两个 Xposed 入口的顺序不许改：`assets/xposed_init` 里
   `com.adspeed.hook.PlayerScan` 在第一行、`nn.ecpm.EcpmHook` 在第二行。
   前者初始化失败不能把后者（加速内核）带崩。
3. 适配全设备：minSdk 21 / targetSdk 34，dex `--min-api 21`，不带 native 代码，
   不依赖任何新 API 而不做版本分支。
4. 权限要"按需申请"，没有的权限不能让界面崩；`float_on` 残留要在 onResume 里纠正。

## 三、性能与状态（v26 / v27 / v28 补充）

1. **主线程不许做 IO**：写盘、读 2 万字日志、解码大图，一律挪后台。
2. 日志类广播要做**合并**，不能一条一条触发刷新。
3. 悬浮球拖动 `updateViewLayout` 限到 16ms 一帧。
4. 文本没变就不 `setText`，省一次布局重排。
5. **状态显示必须有真实数据来源**，不许靠猜进程存活。eCPM 用
   `max(config.ecpm_ts, logbuf.xml 的修改时间)`；加速直接读开关，不假装"运行中"。
   原因：Android 8.0 起跨应用隐式广播送不到静态接收器，只靠广播关掉界面就是灰的。
6. 悬浮球可换相册图片，也要能一键恢复默认。
7. **日志要有上限，超了自动删最旧的整行**（`config.log_cap`，默认 2000 行，
   可选 500 / 2000 / 10000）。按行裁，不许按字符切，切出半个汉字就是乱码。
8. 裁剪是"读旧值-写回"，和 LogReceiver 的写入必须共用 `Diag.LOCK`，否则会丢日志。
9. **页面懒加载**：只建当前页；任何 `buildXxxPage` 建完自己调一次 `bindToggles()`。
10. 背景图后台解码（`RGB_565`，内存减半），压暗用 `colorFilter` 而不是再叠一层全屏 View。
11. 日志裁剪整段（含读 `buf`）都要在后台线程，不许在主线程读两路 4 万字。

## 三·五、透明（v29 追加，硬性）

1. **透明是整屏的，不是"内容区"的**：状态栏、标题栏、内容区、底部导航、手势条，
   从上到下不许有任何一条不透明或半不透明的横带。用户已明确要求"都要透明"。
2. 实现：`applyEdge()` 里统一处理 —— `setStatusBarColor(0)`、`setNavigationBarColor(0)`、
   API 29+ 关 `setStatusBarContrastEnforced` / `setNavigationBarContrastEnforced`（系统
   会自动加灰罩）、API 30+ `setDecorFitsSystemWindows(false)`、21~29 用
   `SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | LAYOUT_HIDE_NAVIGATION`。26 以下三键导航退半透明黑兜底。
3. 透明之后**所有压在背景上的文字必须自带阴影**（标题、版本号、状态灯、底栏 5 个 tab），
   不许靠"再铺一层渐变"来救可读性 —— 那就又不透了。
4. edge-to-edge 下 `adjustResize` 不再缩窗口，键盘高度必须自己从
   `WindowInsets.Type.ime()` 取，`nav` 底 padding 取 `max(导航栏, 键盘)`。
5. 底栏不许留分隔线（`0x1AFFFFFF` 那条也算"一条边"）。


## 三·七、名字与反馈群（v33 起，硬性）

1. 应用名统一为 **CK广告助手**：界面标题、悬浮窗面板标题、前台服务通知标题、
   桌面图标下的名字（`app_name`）、LSPosed 模块描述（`xposeddescription`）五处必须一致。
   `app_name` 在 `res/values/strings.xml`，每次构建都从基准包重解，所以改名逻辑写在 `build_full.sh` 里。
2. 交流群号 **1132982709**：顶栏版本号后面那串就是它，点一下直接跳 QQ 加群；
   「报告」页另有一块「反馈与加群」和一个按钮。
3. 跳转顺序：群资料卡 → 群聊 → 老 scheme，三个都失败就把群号复制到剪贴板并提示，
   不许出现"点了没反应"。


## 三·八、eCPM 覆盖面（v34 起）

1. 主 hook 的边界是死的：**无参**、方法名含 `cpm`、返回 `String/int/long/double/float`。
   补的三块就是它的边界外：带参 getter、`price/bid/revenue/income/payout` 类方法、
   `BigDecimal` 返回值。
2. 补充层只在广告类上动手：包前缀表 + 类名关键字（adunit/adinfo/admediation/reward…）。
   系统类、androidx、kotlin 一律先排掉，别在类加载热路径上浪费时间。
3. 静态方法只有名字明确带 `cpm` 才碰，`getPrice()` 这种可能是全局算价，不能乱改。
4. 原值 ≤ 0 时跳过（`skip` 配置同主 hook），避免把"没有报价"改成"有报价"。
5. 每次改写都往 `content://nn.ecpm.config/log` 写一条 `补充 类.方法 旧值 -> 新值`，
   报告页统计里单独标"其中扩展 N 次"，方便判断是哪一层改的。


## 三·九、eCPM 配置热更新（v35 起，硬性）

1. 用户在外观页改完上下限，**目标 App 不重启也必须生效**，10 秒内。界面既然写了
   “最多 10 秒读到”，就必须做到；做不到就改文案，不许骗。
2. 实现方式：`EcpmPlus` hook `EcpmHook.emit` 拿实例，每 10 秒比对 provider，
   变了反射写回 `ecpmMin / ecpmMax / skipNonPositive` 三个字段。
   **不改 `EcpmHook` 的字节码**。
3. 拿不到实例必须静默降级，不许抛到调用方，不许影响改写本身。
4. 日志上限的说明必须写实：eCPM 一路受核心 2 万字符（约 600 行）限制，
   加速一路才按用户设定的行数。不许让用户以为设 10000 行就有 10000 行。

## 三·十、加速有效性与环境保护（v36 起，硬性）

1. 广告倒计时最常见的步长是 **1000ms**。智能档下限必须是 **1000ms**，不许抬回 1200；
   1000ms 的单次调用给 1.5×，同参重复第 2 次起按循环给 2.5×
   （`LOOP_HIT=2`、`LOOP_WIN=5000`）。理由：开屏一共 5 秒，等不到第 3 次。
2. 游戏进程的 1 秒循环也要加速（2.0×），不许像 v6 那样整段跳过。
3. 三条通道必须全接：`Handler.postDelayed / sendMessageDelayed / sendEmptyMessageDelayed`、
   `Handler.postAtTime / sendMessageAtTime`、`ScheduledExecutorService.schedule*`。
   少一条就会有一类 SDK 完全不生效。
4. Handler 投递链**只允许最外层缩一次**（`enterForward` 深度计数）。
   内层转发再缩一次会把 5 秒缩成 1 秒，属于严重偏差。
5. **循环识别必须按调用点分组**（类名#方法名），不许用 Method 当 key ——
   全 App 共用一个 `Handler.postDelayed` 方法对象，会把消息轮询和广告倒计时混成一条。
6. 热身窗口 ≤500ms，否则冷启动就弹出来的开屏广告正好被挡在外面。
7. 环境保护 = **不把目标应用与系统搞坏**，不是反检测（见第五节）：
   - 回调异常累计熔断（`GUARD_LIMIT=120`），熔断后全部放行并写一条日志；
   - 银行/券商/支付/密码管理器/输入法/系统安全/企业 MDM 一律不注入；
   - `ScheduledExecutorService.scheduleAtFixedRate` 不缩 period（Timer 的 period 跟 Handler
     循环一样缩，广告倒计时需要）；缩固定周期等于把后台定时任务变成 2.5 倍频轮询。
8. 加速页必须有「运行状态」：`tick_ts`（注入过）与 `speed_ts`（真缩过）分开判断，
   不许把"装上了没触发"显示成"加速中"。
9. 效果统计（缩时次数 / 省下秒数 / 补速次数）每 30 秒回传一条，写在日志行的
   `tick: ` 前缀里，由 LogReceiver 单独存 `config.speed_stat`，不许只留在会被裁掉的日志里。

## 四、每次交付前必须自查（不许省）

- [ ] `javac` 无 error；界面 dex 没分包（出现 `classes2.dex` 直接失败退出）
- [ ] `apktool b` 成功，`resources.arsc` / `AndroidManifest.xml` 为 Stored 且 4 字节对齐
- [ ] `zipalign -c 4` 通过（否则部分 ROM 装包报 `-124`）
- [ ] `apksigner verify` 通过，v1 + v2 + v3 全开
- [ ] `aapt2 dump badging` 版本号、minSdk/targetSdk 正确
- [ ] 逐个走查分页：切换不闪退、保存不串页、输入框不吞值、日志不是空
- [ ] 顶栏 / 底栏 / 状态栏 / 手势条全透明：深色图、浅色图（用户传白图）下文字都读得清（第一节第 3 条 + 三·五）
- [ ] 小屏（320dp）、平板（≥600dp）、横屏、分屏下悬浮球不越界、面板不顶出屏幕
- [ ] 系统字体调到最大时按钮/导航文字不折行、不截断
- [ ] 日志上限三档都点一遍：切到 500 行后日志立刻变短，报告页计数不崩
- [ ] 工作区只留**本版**安装包，旧版 APK / 旧 .idsig 一律删掉

## 五、用户明确否掉的事

- 不给旧版安装包，只给最新一版。
- 不做任何"反检测 / 隐藏模块痕迹"的东西。v36 里说的"环境保护"只指
  崩溃熔断、进程白名单、误伤范围控制这三件事，不含栈帧净化、类名伪装这类手段。
- 服务端按真实时长对账、Unity/UE/Cocos 原生计时器、WebView 内 JS 倒计时——
  客户端改不了，如实说明，不吹。

## 三·六、本机背景图（v30 追加）

1. 允许**多张**本机图片，最多 8 张，槽位固定 `bg_user_0.jpg … bg_user_7.jpg`，
   `bg_pick` 记当前用第几张。旧版单张 `bg_user.jpg` 启动时并入 0 号槽位，升级不丢图。
2. 选图按钮支持多选（`ACTION_OPEN_DOCUMENT` + `EXTRA_ALLOW_MULTIPLE`），
   返回的 `clipData` 逐张处理；`GET_CONTENT` 只作兜底。
3. 「我的图片」一条横排缩略图：点图切换，右上角 × 删除。删除当前那张要顺位到剩下的第一张，
   一张不剩必须退回内置图（否则背景层是空的）。
4. 每张都压到 1600px 再存；写一半失败的文件必须删掉，否则下次启动会拿它当有效图解码。
5. 缩略图按槽位缓存，新增/删除只失效对应项，不要每次全量解码。
