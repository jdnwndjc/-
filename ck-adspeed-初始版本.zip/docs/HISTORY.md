# CK广告助手 —— 源码（对应 v33 / FastTick v6）

## 目录

```
源码/
├── src-java/PlayerScan.java        加速内核，v5 全设备适配版（完整 Java 源）
├── src-ui/nn/ecpm/MainActivity.java 界面，纯代码构建，不用 XML
├── src-ui/nn/ecpm/FloatService.java 悬浮窗前台服务（v20 新增）
├── src-ui/nn/ecpm/LogReceiver.java  静态日志接收器（v20 新增）
├── smali/nn/ecpm/                  主模块（EcpmHook / ConfigProvider）
├── smali/com/adspeed/hook/         原 AdSpeed（MainHook / ClockShift，已从入口摘除）
├── assets/xposed_init              入口清单，两行（PlayerScan 在前）
├── AndroidManifest.xml             apktool 反编译的明文清单
├── lib/stub.jar                    Xposed API 编译桩，只用于 javac，不进 dex
├── build.sh                        热修：只重编 PlayerScan → classes7.dex
└── build_full.sh                   全量：内核 + 界面 + 清单 + 打包签名
```

## 三类代码，性质不同

| 位置 | 来源 | 可读性 |
|---|---|---|
| `src-java/PlayerScan.java` | 手写，v5 | 完整 Java，可直接改 |
| `smali/**` | APK 反编译产物 | 字节码汇编，能读但不适合大改 |
| `lib/stub.jar` | 编译桩 | 只有方法签名，无实现 |

`smali/` 里没有 Java 源，是因为原始 APK 只发布了 dex。想转 Java 可以用 jadx：

```bash
jadx -d out --no-res classes2.dex
```

## 编译

只改 `PlayerScan.java` 的话跑热修脚本，几秒出包：

```bash
BT=$ANDROID_HOME/build-tools/34.0.0 \
  ./build.sh zy广告助手最终版_v18.apk out.apk ./release.keystore release
```

改界面、清单、minSdk、版本号，用全量脚本：

```bash
BT=$ANDROID_HOME/build-tools/34.0.0 \
ANDROID_JAR=$ANDROID_HOME/platforms/android-34/android.jar \
APKTOOL=/path/to/apktool.jar \
VER_CODE=19 VER_NAME=1.9 \
  ./build_full.sh zy广告助手最终版_v18.apk out.apk ./release.keystore release
```

`build_full.sh` 做七件事：编译内核 → 编译界面 → `apktool d -s` 解包（dex 原样保留）
→ 换 classes7/8、改入口、删无用 so → 改清单与版本 → 重打包 + `zipalign -f -p 4`
→ apksigner v1+v2+v3。

**两个必须遵守的约束**（违反会装不上，报 `INSTALL_FAILED_INVALID_APK -124`）：

1. `resources.arsc` 和 `AndroidManifest.xml` 必须以 **STORED**（不压缩）写入。脚本里 `zip -0` 那行就是干这个的。
2. 打完必须 `zipalign -p 4`，让 STORED 条目 4 字节对齐。

改 `smali/` 的话走 apktool：

```bash
apktool b . -o unsigned.apk && zipalign -f -p 4 unsigned.apk a.apk && apksigner sign ...
```

但 apktool 重打包会丢掉原有的 dex 分卷结构，`classes7.dex` 会全部重新合并，容易触发 64K 方法数上限。建议还是走 `build.sh` 这条路。

## 当前实现状态（v13）

**加速链，实际生效的三条：**

- `Handler.postDelayed / sendMessageDelayed / sendEmptyMessageDelayed`：普通进程 ≥800ms ÷3，游戏进程 ≥3000ms ÷2
- `Timer.schedule / scheduleAtFixedRate`：同上
- `CountDownTimer` 构造：`total` 和 `interval` 各 ÷3
- `ValueAnimator.setDuration`：≥3000ms ÷3
- `MediaPlayer.setPlaybackParams` / `setSpeed`，以及扫描到的自定义 `setSpeed*`：强制 3.0x

**已经删掉的：**

`SystemClock.uptimeMillis / elapsedRealtime / elapsedRealtimeNanos` 的偏移链。这三个在 API 31+ 是 `@CriticalNative`，ART 直连 native 入口，不经过 JNI bridge，hook 拿不到调用点。v2 里那段代码是死代码，日志打印 "hooked" 只是没抛异常，不代表挂上了。连带删掉了 `offsetAcc / lastTick / winOn / MAX_OFFSET` 状态机——`MAX_OFFSET` 到顶后加速永久失效，本来就是个坑。

## 改代码前要知道的

**进程黑名单**是硬编码的，在 `PlayerScan.BLOCK_EXACT` / `BLOCK_PREFIX`。加包名要重新编译。当前挡了微信、QQ、支付宝、银联、各大银行、系统 UI、GMS、Chrome。

**阈值是分进程的**，不是全局一个值：

| 进程类型 | 阈值 | 倍率 | ValueAnimator |
|---|---|---|---|
| 普通 App | ≥800ms | ÷3 | 改（≥3000ms） |
| 游戏（`category == 2`） | ≥3000ms | ÷2 | 不改 |

v3.1 之前是统一的 300ms / ÷3，会把游戏的点击防抖、UI 状态机短延时全部打乱，表现为「看完广告才能点」的按钮停在锁定态。降级后游戏内只处理 3 秒以上的倒计时，1 秒级 tick 一律不动。

**但是**：如果按钮锁定来自服务端校验（本地倒计时被加速，服务端按真实时间对账，判定未看完而拒绝），改客户端没有任何作用。这类只能靠单包排除解决——LSPosed 里取消该游戏的作用域勾选。

**eCPM 那条链**（`nn/ecpm/EcpmHook.smali`）的 `apply()` 有 5 处分支，判定条件是 `cmpl-double` + `if-lez :skipret_N`，含义是"原值 ≤ 0 就跳过不改"。改这里之前先反汇编确认跳转方向，v11 之前一直是反的，导致正常正值被跳过、异常值反被改。

**`ConfigProvider` 的 `exported` 必须是 `true`**。它被目标 App 进程跨进程读取配置，设成 `false` 会让 `loadConfig()` 和 `emit()` 全部失败，表现为模块"完全没反应"。

---

## v15 界面改造（src-ui + assets）

### 新增与改动

| 位置 | 变化 |
|---|---|
| `src-ui/nn/ecpm/MainActivity.java` | 全新界面，纯代码构建，不用 XML |
| `assets/bg.jpg` | 背景图，720×1456，130KB |
| `smali/nn/ecpm/ConfigProvider.smali` | query 增加 `speed` 行 |
| `src-java/PlayerScan.java` | 增加 `speedEnabled()`，跨进程读总开关 |

原 `MainActivity` 的 smali 已从 `smali/nn/ecpm/` 删除，改由 `src-ui` 编译出的 dex 提供。类名、包名不变，Manifest 不用动。

### 跨进程开关怎么生效

```
MainActivity (nn.ecpm 进程)
    └─ SharedPreferences("config").speed_enabled
            ↓ ConfigProvider.query()  ← exported=true
PlayerScan (目标应用进程)
    └─ speedEnabled() 反射调用 ContentResolver
            ↓ 10 秒缓存
scale() / scaleCdt() / scaleAnim() / forceParams() 开头 return
```

为什么走 provider 而不是直接读文件：模块跑在**别的应用进程**里，`/data/data/nn.ecpm/shared_prefs/` 是 700 权限，读不到。`ConfigProvider` 是唯一的合法跨进程通道。

### 编译界面

需要 android.jar（API 15 就够，只做编译校验）：

```bash
curl -o lib/android-api.jar \
  https://repo1.maven.org/maven2/com/google/android/android/4.1.1.4/android-4.1.1.4.jar

javac -source 8 -target 8 -cp lib/android-api.jar -d out src-ui/nn/ecpm/MainActivity.java
d8 --min-api 24 --lib lib/android-api.jar --output dex_out $(find out -name '*.class')
# 产物改名 classes8.dex 塞进 APK
```

### 两个必须注意的坑

**1. `registerReceiver` 在 targetSdk 34 会抛 SecurityException。** 必须用三参数版本传 `RECEIVER_EXPORTED(2)`。代码里用反射调，因为 API 15 的编译桩没这个方法。

**2. 删了 smali 里的 MainActivity 后，一定要确认没有别的类引用它。** 用 `strings classes2.dex | grep MainActivity` 查，删完应该是 0（除了自己的 4 处）。

---

## v16 智能调速（FastTick v4）

原来的倍率是硬编码 `÷3`（游戏 `÷2`）。v16 改成按目标时长分段，倍率由运行时算出来。

### 分段表

普通进程：

| 目标延时 | 倍率 | 举例 |
|---|---|---|
| < 1.2s | 1×（不动） | 点击防抖、帧回调、UI 状态机 |
| 1.2–2.5s | 1.5× | 开屏 3 秒 |
| 2.5–6s | 2× | 插屏 5 秒 |
| 6–15s | 2.5× | 激励视频 10 秒 |
| ≥ 15s | 3× | 激励视频 20–30 秒 |

游戏进程整体降一档（<3s 不动，3–8s 1.5×，8–20s 2×，≥20s 2.5×），因为游戏的 UI 状态机对时间敏感。

### 三个自动调节维度

1. **按目标时长**：`rateFor(v)` 分段，短延时不动、长广告拉满。
2. **按设备性能**：`perfFactor` 由 `availableProcessors()` 决定，≤2 核 ×0.7，≤4 核 ×0.85，其余 ×1.0。低端机解码余量小，3× 会花屏。
3. **按运行压力**：一秒内缩放次数超过 80 次，说明 tick 被打得过密，接下来 5 秒整体 ×0.7。

### 递归 tick 识别（关键）

广告倒计时常见写法：

```java
void tick() { ...; handler.postDelayed(this::tick, 1000); }
```

单次看只有 1000ms，低于 1.2s 门槛，会被智能模式整段跳过 —— 20 秒广告一点都不加速。`loopRate()` 按「同一 Method + 间隔相近 + 连续 3 次」判定为一条长倒计时，改用 8 秒档位（2×）处理。

依赖 `MethodHookParam.method`，所以 `lib/stub.jar` 里补了 `public Member method` 字段（真实 Xposed 会填）。

### 冷启动保护

进程注入后 1 秒内不加速，避免打断启动动画链；开屏广告一般在首帧后 1s 才起播，窗口再长会漏掉它。

### 跨进程开关

`ConfigProvider.query()` 增加 `smart` 行，对应 `smart_enabled`（默认 true）。`PlayerScan` 与 `speed` 一起读，共用 10 秒缓存。

关闭智能调速 → 退回 v15 的固定倍率（普通 3×、游戏 2×、阈值 800/3000ms）。

### 版本号

v16 起 `versionCode=16`、`versionName=1.6`，写在**二进制** `AndroidManifest.xml` 里（apktool 解码出来的文本清单不含这两项，打包时由原清单保留）。

改法是直接改 AXML：`versionCode` 是 `TYPE_INT_DEC` 属性，原地写 int；`versionName` 指向字符串池里的 `"1.0"`，改成 `"1.6"` 时长度不变，可原地覆盖，不用重建字符串池、不用 aapt2 重编资源。

---

## v16 复核修复（6 项）

| 编号 | 问题 | 修法 |
|---|---|---|
| B1 | `loopRate()` 在**固定模式**和**游戏进程**里也生效 | 加 `smartOn && !gameMode` 守卫。固定模式原本 500ms 不缩，被递归识别偷偷缩成 250ms；游戏里会重新打乱 UI 状态机 |
| B2 | `div` 字段只写不读；`smartEnabled()` 无调用方 | 删除 |
| B3 | 日志前缀 v3 / v4 混用 | 统一 v4，排查时不会把新旧版本混在一起 |
| B4 | 界面「运行日志」永远为空 | 界面注册了 `nn.ecpm.LOG` receiver，但**从来没有发送方**。新增 `emit()`，注入完成后推一条 |
| B5 | 文案写「关闭则固定 3×」 | 游戏进程实际是 2×，改成「普通 3×，游戏 2×」 |
| B6 | `LOOP_MIN_MS=400` 会误伤 400ms 轮询 | 抬到 500ms |

### B4 的实现细节

`handleLoadPackage` 触发时 `currentApplication()` 还是 null（Application 没 attach），所以不能直接 `sendBroadcast`。做法是起一个 daemon 线程，每 500ms 试一次，最多 10 秒，拿到 Context 就发完退出。广播用 `setPackage("nn.ecpm")` 限定接收方，避免被其他应用监听到包名和倍率。

界面侧不用改：`registerReceiver` 已经用三参数 + `RECEIVER_EXPORTED(2)` 注册过了。

---

## v17 复核修复（5 项，全部是真实缺陷）

### R1｜Handler 延时被缩了两次（最严重）

`android.os.Handler` 的调用链是：

```
postDelayed(r, 1000)  ->  sendMessageDelayed(getPostMessage(r), 1000)
sendEmptyMessageDelayed(what, 1000)  ->  sendMessageDelayed(...)
```

v16 及更早把这三个方法**都**挂了 hook，所以同一条 1000ms 延时：

1. `postDelayed` 的 before 里 1000 → 333
2. 内部调 `sendMessageDelayed(333)`，before 里 333 → 111

3× 档实际是 **9×**。这也是为什么有些 App 的广告"点开就没了"、奖励却不到账 —— 客户端倒计时跑到 0，服务端按真实时长对账直接拒绝。

修法：`postDelayed` / `sendEmptyMessageDelayed` 的 before 里置线程内标记，内层 `sendMessageDelayed` 看到标记就跳过并清除。标记在 `beforeHookedMethod` 里消费，不是只在 `afterHookedMethod` 里清 —— 外层抛异常时 after 不会执行，只靠 after 会让标记永久残留，那之后**所有**消息都不再加速。

### R2｜CountDownTimer 的 interval 不该缩

`CountDownTimer` 的剩余时间是 `mStopTimeInFuture - elapsedRealtime()`，由**真实时钟**驱动，和 interval 无关。所以：

- 缩 `total` → 总时长变短，有效
- 缩 `interval` → tick 的 delay 变小，再被 `sendMessageDelayed` 缩一次，回调密度变成 **r² 倍**，数字跳变不均匀、白烧 CPU

v16 两个都缩，倒计时看起来"跳着走"。v17 只缩 `a[0]`，interval 原样。

### R3｜`forceParams` 的兜底分支没有作用

```java
// 旧：PlaybackParams 没有 (float) 构造器，这行必然抛异常
XposedHelpers.newInstance(cur.getClass(), Float.valueOf(sp));
```

改成无参构造再 `setSpeed`，才是真的兜底。

### R4｜配置读取失败没有退避

`ConfigProvider` 不可用时（模块被停用、权限异常），每次 TTL 到期都要走一遍完整反射 + Binder 调用 + 异常构造，而异常栈比 query 本身还贵。加 `cfgOk` 标记：成功 10 秒刷新，失败退避 60 秒。

例外：`currentApplication()` 返回 null 不算失败（Application 还没 attach），只等 2 秒重试。否则界面刚关掉加速时，目标 App 在退避期内仍会加速。

### R5｜方法名每个都 `toLowerCase()`

F3 只改了类名匹配，方法名还在分配临时 String。改成 `equalsIgnoreCase`，每个命中类的每个方法省一次分配。

### 顺带

界面里「智能调速」说明写的是「3s 起 2×」，代码实际是 2.5s，已对齐。

---

## v18 配置读不到 + Android 17 / LSPosed 2.x 适配

### 一、为什么「一些设备读不到配置」

原来的读取只有一条通道：`ContentResolver.query` → `ConfigProvider`。它要跨进程走 Binder，会被下面几种情况打断，而每一种都只发生在**部分机型**上：

| 情况 | 表现 |
|---|---|
| ROM 拦截跨应用 provider（华为/小米/OPPO 的隐私保护） | query 抛 SecurityException，或返回 0 行 |
| 模块被「应用休眠」冻结（Android 12+） | provider 进程不响应，query 超时或返回 null |
| 应用双开 / 工作资料（多用户） | authority 在当前用户下没有对应 provider |
| 目标 App 进程早于 Application attach | `currentApplication()` 为 null，直接 return |

v18 改成三条通道，按顺序试：

```
1. XSharedPreferences("nn.ecpm", "config")
     直接读模块 prefs 文件，不走 Binder。
     LSPosed 2.0.1 专门修过它的初始化、目录权限、目录缺失。
2. ContentProvider.query
     原有通道，做兜底。
3. /data/data/<目标包>/shared_prefs/nn_ecpm_cache.xml
     目标进程自己的缓存，存上次成功读到的值。
```

第 3 条是关键：原来两个通道都失败时会退回默认值 `true`，等于**用户明明关了加速，在某些机型上照样加速**。现在退回的是上次成功的值，最差才是默认值。

缓存只在值变化时写一次（`apply()` 异步落盘），不会在 hook 线程上做同步 IO。

### 二、诊断

目标 App 的日志里会多一行：

```
cfg: xsp speed=true smart=true
cfg: provider speed=false smart=true
cfg: cache speed=false smart=true
cfg: default speed=true smart=true
```

`xsp` = 走文件通道；`provider` = 走 Binder；`cache` = 用了缓存（说明前两条都断了）；`default` = 三条全断，用的是默认值（此时加速会开启，需要排查）。

界面「运行日志」右侧多了一个 **自检** 按钮，它只验证模块自己的 provider：

- 显示「Provider: 返回 null / 异常」→ provider 本身有问题
- 显示「Provider: 4 行 [speed=1 smart=1 ...]」→ provider 正常，问题在目标进程的跨进程访问，靠 xsp 通道

### 三、Android 17（API 37）

Android 17 于 2026-06 发布，几个和这个模块相关的点：

| 变化 | 影响 | 处理 |
|---|---|---|
| 强制 edge-to-edge（Android 15 起，16/17 对所有 targetSdk 生效） | 标题会被状态栏压住 | `setOnApplyWindowInsetsListener` 把系统栏 inset 叠到内容 padding |
| lock-free MessageQueue | 无 | 我们 hook 的是 `Handler` 层，不碰 MessageQueue |
| static final 字段不可反射修改 | 无 | 模块不改字段 |
| 反射限制加强 | 无 | 配置读取只用公开 API + Xposed 自己的类 |
| `usesCleartextTraffic` 弃用 | 无 | 模块不联网；该属性留在原清单里，只是弃用警告 |

**targetSdk 保持 34 不改**。理由：模块不需要高 targetSdk，提升会引入前台服务类型声明、精确闹钟权限、edge-to-edge 强制（虽然已经处理）等一串新约束，收益为零。Android 17 对 targetSdk 34 的应用仍可安装运行。

### 四、LSPosed 2.x

- LSPosed **2.0.1**（2026-04）起支持 Android 8.1–17，**2.2.1**（2026-10）是最新。
- 2.x **移除的是 libxposed API 100**，`rovo89 Xposed API`（`de.robv.android.xposed.*`，本模块用的就是这套）**不受影响**。
- 所以模块在 1.9.2 / 2.x / Vector 上都能加载，不需要改成 `io.github.libxposed`。
- `XSharedPreferences` 在 2.0.1 被专门修复过，这也是把它放在第一通道的原因。

### 五、界面编译要用 API 34 的平台包

v18 的界面用了 `WindowInsets`，之前那个 API 15 的 `android-api.jar` 里没有。改用 platform-34：

```bash
# 下载后解压出 android.jar
curl -O https://dl.google.com/android/repository/platform-34-ext7_r03.zip
unzip -q platform-34-ext7_r03.zip -d p34

javac -source 8 -target 8 -cp p34/android-34/android.jar -d out src-ui/nn/ecpm/MainActivity.java
d8 --min-api 24 --lib p34/android-34/android.jar --output dex_out $(find out -name '*.class')
# 产物改名 classes8.dex
```

`WindowInsets.Type` 是 API 30 的类，在 Android 24–29 上不会执行到（`SDK_INT >= 30` 分支），并且整段用 `catch (Throwable)` 包住，`NoClassDefFoundError` 也能兜。

### 六、stub.jar 增加了 XSharedPreferences

`lib/stub.jar` 里补了 `de.robv.android.xposed.XSharedPreferences`，只声明 `PlayerScan` 用到的成员（构造器、`reload`、`contains`、`getBoolean`）。真实实现在框架里，编译桩只用于 javac。

---

## v19 全设备适配（FastTick v5）

目标不是"功能更多"，而是**同一份 APK 尽量在所有机器上都能装、能加载、不添乱**。
下面每一条都对应一类具体的机型/系统差异，不是泛泛的兼容声明。

### 一、装得上 / 不挑机型

| 项 | v18 | v19 | 为什么 |
|---|---|---|---|
| `minSdkVersion` | 24（Android 7.0） | **21（Android 5.0）** | 老机器 + rovo89 原版 Xposed 也能装 |
| `native-code` | arm64-v8a / armeabi-v7a / x86 / x86_64 | **无** | 删掉从未被 `loadLibrary` 的 `libtoolChecker.so`，APK 变成纯 Java，任何 ABI 都装 |
| `debuggable` | true | **false** | 部分 ROM 的安全中心、企业 MDM 对 debuggable 包更敏感 |
| dex `min-api` | 24 | **21** | 与 minSdk 对齐，d8 按 API 21 做 desugar |

那个 `.so` 只有 4–5 KB，是全工程唯一可能踩到 **Android 15+ 16 KB 页**（4 KB 对齐的 .so 在 16 KB 页内核上加载失败）的东西。
它在 8 个 dex 里没有任何 `System.loadLibrary` 引用，删掉最干净。

### 二、起得来 / 不拖主线程

**D1｜取 Context 不再靠隐藏 API。**
旧代码用 `android.app.AndroidAppHelper.currentApplication()`，这是隐藏 API。
Android 9+ 开了反射拦截的 ROM 上会抛 `NoSuchMethodException`，表现就是"配置读不到、退回默认值"。
v19 改成 hook 框架自己的生命周期：

```
Instrumentation.callApplicationOnCreate(Application)   ← 主通道，不受自定义 Application 影响
Application.attachBaseContext(Context)                 ← 备选，比 onCreate 更早
AndroidAppHelper.currentApplication()                  ← 只做最后兜底
```

**D2｜配置读取搬出 hook 线程。**
`loadCfg()` 原来是直接在 `Handler.postDelayed` 的 before 里同步跑的。
provider 被"应用休眠"冻结时，一次 Binder 调用能卡几秒 —— 等于让目标 App 主线程陪着等，低端机直接 ANR。
v19 只在 `fasttick-cfg` 后台线程读，hook 里只读 volatile 字段，读不到就沿用上一次的值。

**D3｜系统进程直接跳过。**
`uid < 10000`（system / radio / 各类系统 uid）或带 `FLAG_PERSISTENT` 的进程一律不 hook。
这类进程出事就是整机卡开机，属于"一台都不能碰"的范围。

**D4｜类扫描加名字预过滤。**
原来 `ClassLoader.loadClass` 成功一次就进 `scan()` 做反射遍历，一个 App 冷启动几千次调用。
v19 先在 after 回调里看类名，不匹配直接返回；`DONE` 集合超过 1500 条会清空，长时间挂后台的进程不会无限涨。

### 三、跑得对 / 各版本行为一致

**D5｜起播补倍速，同时把 MainHook 摘掉。**
v18 的入口有三行，`com.adspeed.hook.MainHook` 也在里面，它有两个问题：

- 挂了 `SystemClock.elapsedRealtime/elapsedRealtimeNanos` 的偏移链 —— 这两个在 API 31+ 是 `@CriticalNative`，hook 根本不生效，纯死代码；
- 完全不读用户开关，关了加速照样改播放器倍速。

v19 把 `MediaPlayer / IjkMediaPlayer / ExoPlayerImpl / SimpleExoPlayer / AliPlayer / TXVodPlayer`
的 `start | play | startPlay` 收进 PlayerScan，统一走 `speedEnabled()`，`MainHook` 从 `xposed_init` 移除（类还留在包里，不影响别的代码）。

**D6｜API 分级。**
`PlaybackParams` 是 API 23、`ValueAnimator.setDuration` 是 API 11、`Build.SUPPORTED_ABIS` 是 API 21。
低版本上对应分支直接不装，不靠"抛异常再 catch"来决定行为。

**D7｜入口顺序。**
`PlayerScan` 放第一行、`EcpmHook` 第二。
两个入口各自独立加载，`EcpmHook` 在个别 ROM / 新系统上初始化失败时，不会把加速内核一起带下去。

**D8｜游戏识别兜底。**
`ApplicationInfo.category` 是 API 26 才有，而且大量游戏在 8+ 上也没标 `CATEGORY_GAME`。
v19 在 category 不是 2 时，再看 `nativeLibraryDir` 里有没有 `libunity / libil2cpp / libcocos / libUE4 / libmonobdwgc / libgodot`，
最后退回 `/proc/self/maps`。命中就按游戏档（≥3s、1.5/2/2.5×、不改动画、不补起播倍速），避免把游戏的 UI 状态机打乱。

### 四、界面

平板 / 折叠屏 / 横屏内容最大宽度 560dp 居中（`hPad()`），手机上仍是 18dp 边距；
保存按钮从固定 48dp 高度改成 `minHeight`，大字号不截断；
Activity 加 `windowSoftInputMode="adjustResize"`，小屏弹键盘不遮输入框；
edge-to-edge 仍由 `setOnApplyWindowInsetsListener` 把系统栏 inset 叠进内容 padding。

### 五、兼容矩阵

| 维度 | 覆盖 |
|---|---|
| Android 版本 | 5.0–17（API 21–37）；8.1+ 走 LSPosed，5.0–7.1 走原版 Xposed |
| 架构 | 全 ABI（无 native 代码） |
| 框架 | LSPosed 1.9.x / 2.x、Vector、EdXposed、rovo89 Xposed |
| 页面尺寸 | 手机 / 平板 / 折叠屏 / 横竖屏 / 大字号 |
| 权限 | 不加新权限，不需要 root 单独授权 |

### 六、仍然覆盖不到的场景（改客户端无解）

| 场景 | 原因 |
|---|---|
| Unity / UE / Cocos 的 native 计时器 | 不走 `Handler`/`Timer`/`CountDownTimer`，Java 层 hook 拿不到 |
| H5 / WebView 广告倒计时 | 由 JS 定时器驱动，需要注入 WebView，副作用大于收益，没做 |
| 服务端按真实时长对账的奖励 | 本地倒计时跑到 0，服务端仍判"未看完"，只能单包排除 |

### 七、升级与回退

- 与 v18 同签名（`05:9B:1D:AC…`），可直接覆盖安装，配置沿用。
- 回退：装回 v18 即可，`nn.ecpm` 的 `SharedPreferences("config")` 结构没变。
- 装完在 LSPosed 里勾选目标应用 + 重启目标应用；界面「自检」能看到 provider 行数，
  目标应用日志里 `cfg:` 那行才是真正生效的通道（`xsp` / `provider` / `cache` / `default`）。

---

## v20（FastTick v6）—— 修复 + 悬浮窗

这一版的前提：**eCPM 判定逻辑一行未动**，改的全部是加速内核的边界条件、日志链路和界面。

### 一、修的 bug

| 编号 | 问题 | 实际影响 | 修法 |
|---|---|---|---|
| F1 | `attachBaseContext` 挂在 `Application` 上 | 这个方法属于 `ContextWrapper`，`getDeclaredMethod` 必定抛异常 —— 这条「备选取 Context」的通道**从来没生效过** | 改 hook `ContextWrapper.attachBaseContext`，用类名回溯只认 `Application` 本体 |
| F2 | 固定模式不分游戏档 | `playerSpeed()` 在 `smartOn=false` 时一律返回 3.0，游戏里的播放器同样被拉到 3× | 固定档按 `gameMode` 取 2× |
| F3 | 低端机下限反噬 | `1.5 × 0.7 = 1.05` 被固定下限 1.3 又抬回去，等于低端机降档形同虚设 | 下限改为 `max(1.05, 1.3 × perfFactor)`；`perfFactor` 调成 0.8 / 0.9 / 1.0 |
| F4 | 固定档不过收敛 | `rateFor` 的固定分支直接 `return 3`，不吃 `perfFactor` | 统一走 `clamp()` |
| F5 | `NEST` 用 0/1 标志 | 只要有一条路径没走 `after`（ROM 改写实现、异常栈），标志残留 1，之后**所有** `sendMessageDelayed` 都被放过，加速静默失效 | 改成线程内重入计数，`before` +1、`after` -1 |
| F6 | 日志一个线程一条 | 冷启动几十条日志 = 几十个线程同时抢 CPU | 有界队列（128）+ 单个 daemon 线程顺序发 |
| F7 | 日志只在界面开着时才有 | 动态接收器随 Activity 销毁，界面一关日志全丢 —— 这就是「运行日志一直空的」 | 清单里加 `LogReceiver` 静态接收并落盘，界面那个只负责刷新显示 |
| F8 | `AndroidAppHelper` 只试一次 | 第一次赶上类还没加载，就永远拿不到 Context | 30 秒退避重试 |

### 二、冲突检查结论

**没有功能性冲突**，但有两处叠加需要说明：

| 检查项 | 结论 |
|---|---|
| `ClassLoader.loadClass` | 两个入口都挂了。`EcpmHook` 找 `getEcpm`，`PlayerScan` 找播放器倍速，各自有 `DONE` 去重，不会 hook 到同一个方法。代价是每次类加载跑两遍回调；`PlayerScan` 侧已有类名预过滤，只有含 `player/media/video/exo/ijk` 等关键词的类才进反射 |
| `MediaPlayer` / `Handler` / `Timer` / `CountDownTimer` | `EcpmHook` 完全不碰，只有 `PlayerScan` 挂 |
| `SystemClock` | v19 起 `MainHook` 已从 `xposed_init` 摘掉，全包没有 `elapsedRealtime` 的 hook |
| 配置读写 | `EcpmHook` 读 `min`/`max`，`PlayerScan` 读 `speed_enabled`/`smart_enabled`，key 不重叠 |
| Activity | 只有 `nn.ecpm.MainActivity` 一个 launcher；`com.adspeed.hook.MainActivity` 是死类，不在清单里 |
| Provider authority | 只有 `nn.ecpm.config` 一个，无重复 |

### 三、悬浮窗

**用法**：主界面 →「悬浮窗」→ 是 → 系统设置里允许「显示在其他应用上层」→ 回到目标应用，
屏幕上会出现一个蓝色小球（默认距左 8dp、距上 160dp）。

- 拖动可以挪位置，松手记住坐标
- 点一下展开面板：**广告加速 / 智能调速** 两组开关，点完立刻写 `SharedPreferences`，不用回主界面
- 面板贴边展开时会自动把窗口挪回屏内，不会顶出可视区
- 面板底部：「打开助手」/「关闭悬浮窗」

**实现**：`FloatService` 是前台服务，`foregroundServiceType="specialUse"`，通知优先级 `MIN`（不响不震）。
所有 `WindowManager` 操作都包在 `try/catch` 里，加不上就 `stopSelf` + Toast ——
悬浮窗出任何问题都不会影响到 hook 本身。

改完的配置走原有通道生效：目标进程下一次 `cfg` 刷新（最多 10 秒）就能读到，
日志里 `cfg: provider speed=false smart=true` 那行会跟着变。

### 四、新增权限

| 权限 | 用途 | 不给会怎样 |
|---|---|---|
| `SYSTEM_ALERT_WINDOW` | 悬浮窗（v18 就已声明，这次才真正用上） | 只能用主界面，悬浮窗开关点不动 |
| `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_SPECIAL_USE` | Android 8+ 保活（targetSdk 34 强制要求类型） | 悬浮窗会被系统回收 |
| `POST_NOTIFICATIONS` | 前台服务通知（Android 13+ 运行时权限） | 服务照跑，只是看不到通知 |

### 五、验证

- `versionCode=20 / versionName=2.0`，minSdk 21、targetSdk 34，无 native-code
- 8 个 dex、1424 个类；`classes7.dex` 20 类（内核）、`classes8.dex` 24 类（界面 + 服务 + 接收器）
- `resources.arsc` / `AndroidManifest.xml` 仍为 Stored，`zipalign -c 4` 通过
- v1 + v2 + v3 签名，证书 SHA-256 `059b1dac…` 与 v19 相同，**可直接覆盖安装**
- 清单校验：`nn.ecpm.FloatService`（`foregroundServiceType=0x40000000`）、`nn.ecpm.LogReceiver`（`exported=true`）均在位

### 六、仍未覆盖

与 v19 相同：Unity / UE / Cocos 的 native 计时器、WebView 里的 JS 倒计时、服务端按真实时长对账的奖励。
这三类改客户端无解，不在这一版范围内。

---

## v21（2.1）—— eCPM 运行记录为什么一直是空的

### 根因：两套 SharedPreferences，界面只读了其中一套

| 来源 | 写入方 | 落到哪 | 界面旧代码读的是 |
|---|---|---|---|
| eCPM 改写记录 | `EcpmHook.emit()` → `ContentResolver.insert(content://nn.ecpm.config/log)` → `ConfigProvider.insert()` | `SharedPreferences("logbuf")` 的 `buf` | ❌ 没读 |
| 加速 / 注入日志 | `PlayerScan.pushLog()` → 广播 `nn.ecpm.LOG` → 接收器 | `SharedPreferences("config")` 的 `buf` | ✅ 读了 |

所以「运行日志」里**永远只有加速那半边**，eCPM 的 `[EcpmRange] 100000 -> 130000` 这类记录一条都看不到 ——
不是 eCPM 没工作，是它写在了另一个文件里，界面根本没去读。

### 修法

1. `MainActivity` 同时持有 `config` 和 `logbuf` 两个 SP，日志按来源分段显示：

```
——— eCPM ———
[EcpmRange] xxx -> yyy
——— 加速 ———
FastTick v6: installed in ...
```

2. 新增**运行报告**卡片（保存按钮下方）：

```
eCPM 改写    12 次
加速注入     3 条
配置刷新     8 次
eCPM 区间    100000 ~ 130000 分
当前开关     加速开 / 智能开
当前通道     cfg: provider speed=true smart=true
最近改写     [EcpmRange] 100000 -> 130000
```

当 eCPM 计数为 0 时，报告里直接列出三条排查项（勾选 / 重启 / 有没有广告 SDK），
不用再去翻 logcat。

3. **去重**：`EcpmHook` 的 `emit()` 是「广播 + provider 双写」，同一个 `[EcpmRange]` 会被两条路各落一次。
`LogReceiver` 现在把 `[EcpmRange]` 开头的消息直接放过，交给 provider 写 `logbuf`，
避免界面上重复两遍。

4. 清空按钮同时清两个 SP；自检里加了一行 `日志 config=N 字 / logbuf=M 字`，
一眼能看出哪一路没有数据。

### 数字口径

报告里的次数是从日志正文里数出来的，日志本身有 **20000 字上限**，滚出去的旧记录不计入，
所以它是「最近这一段」而不是历史累计。要做真正的累计计数得在 `EcpmHook` 里加计数器 ——
那属于改 eCPM 核心，按你的要求没动。

### 验证

- `versionCode=21 / versionName=2.1`，minSdk 21、targetSdk 34
- 与 v20 同签名（`059b1dac…`），可直接覆盖
- `classes.dex` ~ `classes6.dex` 与 v20 **md5 完全一致**（eCPM 逻辑零改动）

---

## v22（2.2）—— 底部导航分页 + 日志链路的两个真 bug

### 一、界面：四个分页，各管一件事

原来是一整条长滚动：标题、广告加速、智能调速、eCPM、异常值保护、悬浮窗、保存、报告、日志全堆在一起，
要改一个开关得先滑半天，改完还得滑回去找保存。现在拆成四个分页，底部固定导航：

| 分页 | 内容 |
|---|---|
| **加速** | 广告加速、智能调速、当前档位（`1.2s→1.5× / 2.5s→2× / 6s→2.5× / 15s→3×`）、保存 |
| **eCPM** | 最小值 / 最大值、异常值保护、保存 |
| **悬浮窗** | 开关、服务与权限实时状态、跳系统设置 |
| **报告** | 运行报告、自检、刷新、原始日志、清空 |

- 分页用 `FrameLayout` + 4 个 `ScrollView`，切换只改 `visibility`，滚动位置各自保留；
- 底部导航 48dp 触摸高度、选中项粉色指示条 + 白色加粗，宽屏（平板/折叠屏）限宽 560dp 居中；
- 切页时按需刷新：进「报告」刷数据、进「悬浮窗」刷状态、进「加速」刷档位；
- 旋转屏幕保持当前分页（`onSaveInstanceState` 存 `tab`）；
- 两个分页各有一个「保存并生效」，都走同一个 `doSave()`，字段一次全写，幂等。

### 二、修的 bug

| 编号 | 问题 | 实际影响 |
|---|---|---|
| G1 | `refreshReport()` 用 `line.startsWith("[EcpmRange]")` 统计改写次数 | `EcpmHook.emit()` 只把 `[EcpmRange] ` 前缀加在 `XposedBridge.log` 那一行，广播和 `provider` 传的 `msg` 是**不带前缀**的原文。这个判断永远为 false，所以「eCPM 改写」一直是 0 —— 上一版只修了「读错 SharedPreferences」，计数口径还是错的。真实改写记录格式是 `old -> new`，改用 `" -> "` 判断 |
| G2 | `LogReceiver` 也用 `startsWith("[EcpmRange]")` 去重 | 同上，去重永远不生效，eCPM 记录会被同时写进 `config.buf`，界面上同一段日志出现两遍。改为内核广播带 `src=tick` 标记，只写带了标记的；旧内核没有标记时退回内容前缀判断 |
| G3 | 保存后不刷新报告 | 改完上下限点保存，报告里的「eCPM 区间」「当前开关」还是旧值，要退出重进才更新 |
| G4 | 报告 / 日志 `TextView` 套了 `ScrollingMovementMethod` + `maxLines` | 内部滚动和外层 `ScrollView` 抢触摸，手指停在文字上滑不动整页。内容本来就不长，去掉内部滚动交给外层 |
| G5 | 自检 / 刷新 / 清空按钮 `minHeight=28dp` | 低于 48dp 最小触摸目标，单手点容易点错。抬到 34dp 并加内边距 |
| G6 | `assets` 里的声明文件是中文名 | apktool 按 CP437 还原成乱码条目名 `хг░цШО.txt`（功能无影响，但解压工具里很难看）。构建脚本统一改成 `NOTICE.txt`，内容原样保留 |

### 三、日志链路的正确形状

```
加速日志  PlayerScan.pushLog()  → 广播 nn.ecpm.LOG (src=tick)  →  LogReceiver  →  config.buf
eCPM 记录 EcpmHook.emit()       → 广播 nn.ecpm.LOG (无 src)    →  动态接收器只刷新，不落盘
                                →  ContentResolver.insert()    →  ConfigProvider →  logbuf.buf
```

两条路各写各的文件，界面按来源分段显示；只有带 `src=tick` 的才进 `config.buf`，不会互相串。

### 四、验证

- `versionCode=22 / versionName=2.2`，minSdk 21、targetSdk 34，无 native-code
- 8 个 dex、1428 类；`classes7.dex` 20 类（内核）、`classes8.dex` 28 类（界面 + 服务 + 接收器）
- `classes.dex` ~ `classes6.dex` 与 v21 **md5 完全一致**（eCPM 判定逻辑与广告 SDK hook 一行未动）
- `resources.arsc` / `AndroidManifest.xml` 为 Stored，`zipalign -c 4` 通过，v1+v2+v3 签名
- 证书 SHA-256 `059b1dac…` 与 v21 相同，可直接覆盖安装
- `assets/` 只剩 `bg.jpg`、`NOTICE.txt`、`xposed_init`，无乱码条目

---

## v23（2.3）—— 一页一块面板

### 一、为什么合并

v22 每页是两三张分离的圆角卡，卡片之间露出背景图，滑起来一块一块的：
报告页「运行报告」和「原始日志」被一条背景缝劈成两半，eCPM 页「范围」和「异常值保护」同样。
现在每页只有**一块面板**，面板内部用 1px 分隔线划小节，视觉上是一个整体。

| 分页 | 合并后的结构 |
|---|---|
| 加速 | 广告加速 ── 智能调速 ── 当前档位 ── 保存 ── 说明 |
| eCPM | eCPM 范围 ── 异常值保护 ── 保存 ── 说明 |
| 悬浮窗 | 开关与状态 ── 权限设置 ── 关于常驻通知 |
| 报告 | 运行报告 ── 原始日志 |

实现上把 `card()` 换成 `panel()` + `section()`：`panel()` 建整块底板，
`section()` 只在**不是第一个**子视图时补分隔线，所以增删小节不会留下多余的线。

### 二、顺手修的

| 编号 | 问题 | 实际影响 |
|---|---|---|
| H1 | 加速页的保存也校验 eCPM 输入框 | 分页后两个保存按钮共用一个 `doSave()`，在加速页点保存时如果 eCPM 输入框是空的，会莫名弹「请填入有效的整数」，而用户根本没碰那一页。改成 `doSave(boolean withRange)`：加速页只写三个开关，eCPM 页才校验并写入上下限 |
| H2 | 日志按字符截断 | `tail(s, 6000)` 有可能从半个汉字、半行英文处切开，屏幕上第一行看着像乱码。改成 `tailLines(s, 60)` 按行取 |
| H3 | 报告空态重复 | 四个计数全为 0 时不再列一排 0，直接给三条排查 + 区间和开关一行，少占半屏 |
| H4 | 背景压字 | 遮罩从 45% 提到 55%，面板白 12% → 20%，正文 82% → 90%；日志框改等宽字体，`100000 -> 130000` 这类数字对得齐 |
| H5 | 「其他记录」噪音 | 只在大于 0 时显示，没有就不占一行 |

### 三、验证

- `versionCode=23 / versionName=2.3`，minSdk 21、targetSdk 34，无 native-code
- 8 个 dex、1428 类；`zipalign -c 4` 通过，v1+v2+v3 签名
- 证书 SHA-256 `059b1dac…`，与 v22 同签名，可直接覆盖安装
- **`classes.dex` ~ `classes7.dex` 与 v22 的 md5 完全一致**（eCPM 判定与加速内核一行未动），
  本轮只改了 `classes8.dex`（界面）

### 四、文件整理

工作区以前堆了 v13–v22 十个 APK 和十个源码包，容易装错版本。
本轮已全部清理，只保留：

```
zy广告助手最终版_v23.apk      ← 唯一安装包
zy广告助手_源码_v23.zip        ← 对应源码
界面预览_v23.html             ← 浏览器里点着看布局
```

---

## v24（2.4）—— 外观：背景可换 + 主题色

新增第 5 个分页「外观」，对应截图里那套「主题与外观」。仍然是一页一块面板。

### 一、背景

| 选项 | 实现 |
|---|---|
| 图片 | 现在这张 `assets/bg.jpg`（默认） |
| 流光 / 深海 / 暮紫 | 程序生成的渐变 + 一层径向光斑，不占包体 |
| 本机 | 相册选图，`ACTION_GET_CONTENT` |

**选图这条链有三个坑，都处理了：**

1. **uri 会失效。** `ACTION_GET_CONTENT` 给的授权是临时的，App 一重启就读不到。
   所以选完立刻把图复制到 `filesDir/bg_user.jpg`，之后只读自己的文件，原图删了也不影响。
2. **原图会 OOM。** 相册里 8000×6000 的照片按 ARGB_8888 解码是 192MB。
   现在先 `inJustDecodeBounds` 只读尺寸算采样率，再按 1600px 上限解码，落盘 JPEG 88。
3. **内置背景同样会 OOM。** 顺手把 `loadBg()` 也改成采样解码 —— 以前是 `decodeStream` 全尺寸，
   背景图一旦换成 4K，低端机启动就崩。

### 二、主题色

四套：玫红（默认）/ 蓝 / 紫 / 青绿。改的是 `C_ACCENT` 与 `C_ON`（强调色 40% 透明），
影响开关底色、保存按钮、底部指示条、外观页选中框。

切换后 `recreate()` 重建界面 —— 已经画好的控件背景不会自己变，重建是最省事也最不容易漏的做法；
当前分页由 `onSaveInstanceState` 带回来，不会跳回第一页。

**悬浮窗也跟着变。** `FloatService` 在 `onCreate` 里画小球，只 `startForegroundService` 不会重建，
所以改色时要先 `stopService`，450ms 后再起（等 `onDestroy` 走完）。否则球还是旧颜色。

### 三、面板浓度

轻薄 / 标准 / 厚重，对应面板白 15% / 20% / 28%。
背景换成很花的实拍图时，调厚一点文字才看得清。

### 四、底部导航

从 4 项变 5 项（加速 / eCPM / 悬浮窗 / 报告 / 外观），每项 48dp 触摸高度、等分宽度，
390dp 宽的屏幕上每项 78dp，不会挤。

### 五、验证

- `versionCode=24 / versionName=2.4`，minSdk 21、targetSdk 34，无 native-code
- 8 个 dex、1436 类；`zipalign -c 4` 通过，v1+v2+v3 签名
- 证书 SHA-256 `059b1dac…`，与 v23 同签名，可直接覆盖安装
- **`classes.dex` ~ `classes7.dex` 与 v23 的 md5 完全一致**（eCPM 判定与加速内核一行未动），
  本轮只改 `classes8.dex`（界面 + 悬浮窗）

### 六、说明

外观配置存在 `SharedPreferences("config")` 里，三个 key：

```
bg_style  int  0=图片 1=流光 2=深海 3=暮紫 4=本机
accent    int  0=玫红 1=蓝 2=紫 3=青绿
glass     int  0=轻薄 1=标准 2=厚重
```

和 `speed_enabled` / `smart_enabled` 同一个文件，卸载或清数据会一起丢。

## v25（2.5）—— 底部导航文字发黑 + 全局次要文字提亮

### 一、问题

用户截图里底部导航的四个未选中项（加速 / 悬浮窗 / 报告 / 外观）看着是"黑字"，
选中项是白色粗体 + 强调色下划线，对比反而更怪。

不是配色写错，是**透明度选错了**：导航条底色是 `0xE6101014`（近黑），
未选中文字用 `C_SUB = 0xA0FFFFFF`（62% 白）。半透明白压在近黑底上，
实际渲染出来是 #A0A0A0 的灰，在 AMOLED 屏 + 低亮度下就接近"黑字"。

### 二、改法

| 位置 | 改前 | 改后 |
|---|---|---|
| 底部导航未选中 | `C_SUB` 0xA0FFFFFF | **`C_NAV` 0xE6FFFFFF**（90% 白） |
| 底部导航选中 | 纯白粗体 + 强调色下划线 | **强调色纯色 + 粗体** + 强调色下划线 |
| 全局次要文字 `C_SUB` | 0xA0FFFFFF | 0xB8FFFFFF（72% 白，仍弱于正文） |

选中项的颜色走 `navAccent()`：`C_ACCENT | 0xFF000000`。强调色在配置里带 alpha，
直接拿来画字会再被透明度削一次亮度，所以先补满 alpha。

### 三、验证

- `versionCode=25 / versionName=2.5`，minSdk 21、targetSdk 34，无 native-code
- `zipalign -c 4` 通过，v1+v2+v3 签名，证书 SHA-256 `059b1dac…`，可覆盖安装
- **`classes.dex` ~ `classes7.dex` 与 v24 的 md5 完全一致**（eCPM 判定、加速内核一行未动），
  只有 `classes8.dex` 变了（界面）
- `classes8.dex` 反编译确认：`0xE6FFFFFF` 出现在 `buildNav` / `selectTab` / 常量池，
  `navAccent()` 方法存在且被 `selectTab` 调用

### 四、顺带

- `需求清单.md`：把你历次提的要求（每功能一个底部栏、一页一块面板、旧版不给、
  核心不许动、每次交付前自查）固化成文件，改版前先读。
- `build_full.sh` 构建时会把这份清单的第一条打印出来，避免"改着改着又忘了"。

## v26（2.6）—— 运行状态灯 + 悬浮球换图 + 卡顿清理

### 一、eCPM 到底在不在跑

三个地方实时显示，3 秒刷新一次：

| 位置 | 显示 |
|---|---|
| 标题栏右上 | 小圆点 + 运行中 / 已连接 / 无记录（任何一页都看得见） |
| eCPM 页顶部 | `eCPM：运行中 · 12 秒前改写` |
| 悬浮窗面板 | `eCPM 运行中   加速 运行中` |

判定链路（**没有动 hook 一行代码**）：

```
EcpmHook.emit()  →  广播 nn.ecpm.LOG（不带 src）
                 →  LogReceiver（静态注册，助手进程）
                 →  config.ecpm_ts = now
                 →  界面 / 悬浮窗读这个时间戳
```

- 3 分钟内有改写 → 「运行中」；超过 → 「已连接 · N 分钟前」；从没有 → 「无记录」
- 加速内核同理，用 `tick_ts`，窗口 60 秒
- 之前想改 `ConfigProvider.smali` 顺手写时间戳，但 smali 目录只用来留档，
  构建只替换 classes7 / classes8，改了也不会进包 —— 所以改成走广播，一行 smali 都不用碰

### 二、悬浮球换图片

外观页 →「悬浮球图标」→「从相册选一张」，压到 256px 存 `filesDir/ball.png`，
悬浮球圆形裁切显示，带 1px 描边和右下角状态灯。「恢复默认圆球」删掉文件即可。

### 三、卡顿：找到的四处，逐条修

| 位置 | 原来 | 现在 |
|---|---|---|
| `LogReceiver` | 每来一条日志：读 2 万字 → 拼接 → **主线程 commit 写盘** | 250ms 合并 + 后台线程 commit |
| 日志广播刷新 | 每次广播都 `postDelayed` 一个新任务，密集时排几十个 | `removeCallbacks` 后只留最后一个 |
| `refreshReport/refreshLog` | 2 万字 `split` + 统计在**主线程** | 后台线程算，主线程只 `setText` |
| 悬浮球拖动 | 每个 MOVE 事件都 `updateViewLayout` | 限制到 16ms 一帧，抬手补最后一次 |
| 背景图 | 每次换背景/重建都重新解码 1600px 原图 | 解码一次缓存，缩略图也缓存 |

另外：文本内容没变就不 `setText`（省掉一次布局重排）；`config` 里新增
`ecpm_ts` / `tick_ts` 两个 long，只做展示用。

### 四、删掉的东西

- `LOOK_BG_NAMES`（外观页自己另写了一份名字数组，这个常量从 v24 起就没用过）
- `FloatService.ballIcon`（v26 加图时引入，随后就没人读）
- `FloatService.prefsLog()`（改成读 config 后没人调用）
- 悬浮球状态灯不再每 2 秒重建 Drawable，状态不变就不重设

### 五、验证

- `versionCode=26 / versionName=2.6`，minSdk 21、targetSdk 34，无 native-code
- `zipalign -c 4` 通过，v1+v2+v3 签名，证书 SHA-256 `059b1dac…`，可覆盖安装
- **`classes.dex` ~ `classes7.dex` 与 v25 的 md5 完全一致**（eCPM 判定、加速内核一行未动）
- 清单确认含 `nn.ecpm.FloatService`、`nn.ecpm.LogReceiver`、action `nn.ecpm.LOG`
- `classes8.dex` 反编译确认 `ecpm_ts` / `tick_ts` / `ball.png` 均已编入

## v27（2.7）—— 日志上限 / 更稳的渲染 / 悬浮窗状态 / 全设备

### 一、超过上限就删（用户要求）

报告页新增「日志上限」：**500 / 2000 / 10000 行**，默认 2000。

- 存在 `config.log_cap`，`LogReceiver` 每次落盘按行裁剪，超出就丢最旧的整行；
- 报告页点档位后立刻裁一次（`trimLogs()`），不用等下一条日志；
- 按行裁，不按字符裁 —— 按字符切会把一行切成半个汉字，屏幕上就是乱码。

竞态处理：裁剪是「读旧值 → 写回」，和 `LogReceiver` 的写入不在同一线程。
两边共用 `Diag.LOCK`；`logbuf.buf` 的写入方是 smali 里的 `ConfigProvider`（动不了，
也不该动），所以那边改成写回前再读一次比对，内容变了就放弃这次裁剪。

### 二、更稳的渲染

| 原来 | 现在 |
|---|---|
| 换主题 `recreate()`，整页重建、闪一下、滚动回顶部 | `repaintAll()` 只重设面板/主按钮/导航的颜色，界面不动 |
| 五个页面在 onCreate 一次建完（200+ View） | 懒加载，只建当前页，其余点到了再建 |
| 背景图在主线程解码，冷启动白屏几十毫秒 | 后台解码 + 窗口深色底兜着，好了再贴 |
| 背景图 + 全屏半透明 View 两层 | 压暗写进图片的 `colorFilter`，少一层全屏绘制 |
| 背景 `ARGB_8888`，1600px 图约 10MB | `RGB_565`，同样一张图 5MB |
| ScrollView 边缘拉伸光效 | 关掉（多一层绘制，和背景叠在一起还发花） |

### 三、悬浮窗里的 eCPM 状态

v26 靠 `nn.ecpm.LOG` 广播写 `ecpm_ts`。但 **Android 8.0 起，跨应用的隐式广播
送不到静态注册的接收器**，界面一关就收不到，灯一直是灰的 —— 用户在悬浮窗里看到的就是这个。

v27 换成读文件属性：

```
EcpmHook.emit() → ContentResolver.insert(content://nn.ecpm.config/log)
               → ConfigProvider 把日志写进 shared_prefs/logbuf.xml
               → 这个文件的 lastModified 就是「最后一次改写」
```

`Diag.ecpmLast()` 取 `max(ecpm_ts, logbuf.xml 的 mtime)`，两条链路谁有信号用谁。
读文件属性不跨进程、不需要改 hook 一行代码、进程被杀也还在。

面板上的两行现在是：

```
eCPM  运行中 · 12 秒前
加速  已开启
```

加速不再显示"未检测"——它是设了就生效的开关，直接读开关比猜运行状态有用。

### 四、全设备 / 全版本

- 悬浮球 46 / 52 / 58dp 按 `screenWidthDp` 分档；面板宽 `min(232dp, 屏宽-24dp)`；
- 屏幕尺寸用 API 30 的 `WindowMetrics`（分屏、折叠屏展开、旋转都是新值），
  取不到退 `getRealMetrics`，再退资源里的 `DisplayMetrics`；
- `onConfigurationChanged` 里重新夹回屏内，横屏不会留在屏外；
- 首次摆放的 y 从状态栏高度往下算，不压信号/电量；
- 展开时按 `measure()` 实测高度挪窗口，状态行两行也不会顶出屏幕；
- 系统字体放到最大：按钮、导航、标签全部 `singleLine + ellipsize`，
  输入框标签从固定宽度改最小宽度（原来「最小值」会被截掉）；
- `ScrollView` 关 `overScrollMode`；`statusTick` 整个包 try/catch，抛一次也不会让状态灯停更。

### 五、验证

- `versionCode=27 / versionName=2.7`，minSdk 21、targetSdk 34，无 native-code
- **`classes.dex` ~ `classes7.dex` 与 v26 的 md5 逐个一致**（eCPM 判定、加速内核一行未动）
- `dexdump` 确认 `Diag` 的 `trim` / `cap` / `ecpmLast` / `fresh` / `agoText` 均被调用
- 裁剪逻辑单独跑过边界测试：末尾换行、正好等于上限、上限=1、无换行、中文日志、空串
- `zipalign -c 4` 通过，v1+v2+v3 签名，证书 `059b1dac…`，可覆盖安装

## v28（2.8）—— 核心体检 / 底部导航透明 / bug 收尾

### 一、核心能不能用（这次是实测，不是"我看过了"）

用户问"eCPM 和加速是否可用"，分两条分别验：

**加速内核（`PlayerScan`，有 Java 源码）**：把它单独编到 JVM 上，
反射调用 `rateFor` / `clamp` / `playerSpeed` / `blocked` 跑断言，8 组全过：

| 断言 | 结果 |
|---|---|
| 倍率始终落在 `[1.05, 3.0]` 或 `1.0`（不加速），3 档性能 × 两档 × 14 个时长 | 通过 |
| 时长越长倍率不降（单调不减） | 通过 |
| 游戏档 ≤ 普通档 | 通过 |
| 800ms 这种短延时不去碰 | 通过 |
| 固定档（关智能）也过 `clamp` | 通过 |
| `clamp` 边界：-5 / 0 / 1 / 9 | 通过 |
| 播放器倍率也夹在范围内，游戏档不高于普通档 | 通过 |
| 进程过滤：systemui / 微信 / LSPosed / 银行 / providers 拦截，普通 App 放行 | 通过 |

实测取值：普通 6000ms → 2.5×，游戏 6000ms → 1.5×，播放器 → 3.0×，符合设计。

**eCPM 判定（`EcpmHook`，只有 smali）**：这条没法在 JVM 上跑（依赖 Xposed 运行时），
改成两层静态验证：

1. **目标表结构**：`<clinit>` 里手工解析 `RAW` 二维数组，
   35 条目标全部是「类名 + 方法名」两元素，没有越界、没有空串。
   这一步必须做——`buildTargets()` 在 `<clinit>` 里跑，只要有一行少一个元素，
   类初始化就抛 `ArrayIndexOutOfBounds`，**整个 eCPM 模块直接不加载**。
2. **改写路径**：`emit → 广播(setPackage) + ContentResolver.insert(content://nn.ecpm.config/log)`
   → `ConfigProvider` 写 `logbuf` → 界面/悬浮窗读文件时间。类型映射逐个核对：
   `int→clampInt(Integer)`、`long→Long`、`double→Double`、`float→Float`、`String→String`，
   每个分支都有 null 判断和 `skipNonPositive` 判断。

**已知限制（不是这版引入的，也不打算动核心）**：

- `findMethod` 只匹配**无参** getter，带 Context 参数的 getter 接不到；
- 类存在但方法名对不上时标记完成、不再重试 —— SDK 大版本改签名后需要更新目标表；
- 穿山甲主包只覆盖了 `MediationAdEcpmInfo.getEcpm`，非 mediation 的 `AdInfo` 没在表里。

### 二、底部导航透明

`nav.setBackgroundColor(0xE6101014)` → `0x00000000`，分隔线从 `0x1FFFFFFF` 降到 `0x1AFFFFFF`。

透明之后文字直接压在背景图上，所以每个 tab 字都加了阴影
（`setShadowLayer(6f, 0, 1f, 0xB3000000)`），选中态切色时也重新补一次阴影。
深色图、渐变图、用户传的白图三种情况下都验过对比度。

`dexdump` 核对：`buildNav` 里 `const/4 v2, #int 0` → `setBackgroundColor`，
`const v4, #1affffff` → 分隔线；整份 `classes8.dex` 里 `0xE6101014` 出现 **0 次**；
`setShadowLayer` 覆盖到 3 个 TextView（标题 / 底栏未选中 / 底栏选中）。
未选中文字从 `0xE6FFFFFF` 提到 `0xF0FFFFFF`，阴影从 0.7 黑提到 0.8 黑、blur 6→7，
这样用户传浅色背景图时也压得住。

### 三、检查出来的 bug

| 位置 | 问题 | 处理 |
|---|---|---|
| `trimLogs()` | 在主线程读两路 `buf`（各 2 万字）再判断，进报告页会卡一帧 | 整段挪进后台线程 |
| `assets/xposed_init`（源码留档） | 还是三行、且 `MainHook` 在第一行，和构建脚本写出去的两行不一致，容易误导下版 | 统一成两行，`PlayerScan` 在前 |
| 底栏透明后文字 | 白字压在浅色背景上会糊 | 每个 tab 加黑阴影，选中态切色时补回 |
| `MainHook` 类 | 仍留在 `classes6.dex` 里（入口早已摘掉，不会执行） | 不动 dex，避免重排 dex 编号出问题；只在文档里记明它不在入口 |

### 四、验证

- `versionCode=28 / versionName=2.8`，minSdk 21、targetSdk 34，无 native-code
- **`classes.dex` ~ `classes7.dex` 与 v27 的 md5 逐个一致**（eCPM 判定、加速内核一行未动），
  只有 `classes8.dex`（界面）变了
- 入口仍是 `PlayerScan` 在前、`EcpmHook` 在后
- `javac` 零 error、无未引用成员
- `zipalign -c 4` 通过，v1+v2+v3 签名，证书 `059b1dac…`，可覆盖安装

---

# v29 —— 整屏透明（状态栏 / 标题栏 / 底栏 / 手势条）

## 一、问题

用户截图反馈："上面和下面至什么回事，要的是透明，都要透明"。

截图里标题那条、底部导航那条各是一块深色横带，中间才是背景图。v28 只把**内容区**的底栏改透明了，
系统栏（状态栏、导航栏）和标题栏仍然各占一块，视觉上就是屏幕最上和最下贴了两条胶带。
用户要的是整块背景，从头铺到尾。

## 二、改动

1. 新增 `applyEdge()`，在 `onCreate` 最前面调用，一次性把系统栏铺平：

   | 版本 | 做法 |
   |---|---|
   | 全部 21+ | `setStatusBarColor(0x00000000)`、`setNavigationBarColor(0)`（26 以下退 `0x66000000`，老 ROM 不接受纯透明） |
   | 29+ | `setStatusBarContrastEnforced(false)` / `setNavigationBarContrastEnforced(false)`，关掉系统自动加的那层灰罩 |
   | 30+ | `setDecorFitsSystemWindows(false)` |
   | 21~29 | `SYSTEM_UI_FLAG_LAYOUT_STABLE \| LAYOUT_FULLSCREEN \| LAYOUT_HIDE_NAVIGATION` |

2. 标题栏 `setBackgroundColor(0x00000000)` 显式写死；底栏连 `0x1AFFFFFF` 那根 1px 分隔线也删了
   —— 有它在就还是"一条边"。
3. 标题 / 版本号 / 状态灯 / 5 个 tab 全部补黑阴影（`0xCC000000`），透明之后靠阴影立字。
4. `setContentView` 后主动 `requestApplyInsets()`，保证第一次 insets 一定派发到 shell
   （否则标题会顶进状态栏）。
5. edge-to-edge 后 `adjustResize` 不再缩窗口，补 `WindowInsets.Type.ime()`：
   `nav` 底 padding = `max(系统导航栏, 键盘高度)`，输入框不会被键盘顶住。

## 三、验证

- `versionCode=29 / versionName=2.9`
- **`classes.dex` ~ `classes7.dex` 与 v28 的 md5 逐个一致**（eCPM 判定 + 加速内核一行未动），
  只有 `classes8.dex`（界面）和清单变了
- `classes8.dex` 里 `setDecorFitsSystemWindows` / `setStatusBarContrastEnforced` /
  `setNavigationBarContrastEnforced` / `setStatusBarColor` / `setNavigationBarColor` 五个符号都在
- `javac` 零 error，界面 dex 未分包
- `zipalign -c 4` 通过，v1+v2+v3 签名，证书 `059b1dac…`
- 入口仍为 `PlayerScan` 在前、`EcpmHook` 在后

---

# v30 —— 本机背景图支持多张上传、可删除

## 一、需求

"这个本机使用图片，可以用的多上传吗删除图片"—— 以前只能存一张 `bg_user.jpg`，
再选就是覆盖，删也只能靠清数据。

## 二、改动

1. 槽位化：`bg_user_0.jpg … bg_user_7.jpg`，最多 **8 张**，`bg_pick` 记当前用第几张。
   旧版单张 `bg_user.jpg` 在 `onCreate` 里由 `migrateUserBgs()` 并入 0 号槽位，升级不丢图。
2. 选图改多选：`ACTION_OPEN_DOCUMENT` + `EXTRA_ALLOW_MULTIPLE`，回调里先读 `clipData`
   （单选再退回 `data`），`GET_CONTENT` 只作没有文档选择器时的兜底。
   一张一张压到 1600px 存进空槽位，槽位满了就停，不覆盖已有的图。
3. 外观页新增「我的图片」横向缩略图条（`HorizontalScrollView`）：
   - 点缩略图 → `pickUserBg(slot)` 直接切到那张；
   - 点右上角 × → `deleteUserBg(slot)` 删除，删完立即刷新背景和缩略图条；
   - 没有图时整条隐藏，不占位置。
4. 删除当前那张会顺位到剩下的第一张；一张不剩退回内置图 —— 否则背景层是空的，整屏只剩窗口深色。
5. 缩略图按槽位缓存（`userThumbs[]`），删除只失效那一格。

## 三、检查出来的问题

| 位置 | 问题 | 处理 |
|---|---|---|
| `writeUserBg()` | 写盘中途失败会留下半张图，下次启动当成有效图解码 | catch 里删掉目标文件 |
| `saveUserBgs()` 回调 | 保存期间用户退出，回调仍往已销毁的界面贴图 | 回调首行 `isFinishing() \|\| isDestroyed()` 直接返回 |
| 槽位为空 | `currentUserSlot()` 返回 -1，若直接拿去算背景缓存 key 会撞到内置图 | 背景 key 用 `100 + max(0, slot)`，空槽返回 null 走兜底底色 |
| 满 8 张再选 | 循环会一直找空位 | `firstFreeSlot()` 返回 -1 就 break，入口先提示"先删一张" |

## 四、验证

- 槽位算法单独抽出来在 JVM 上跑了 16 条断言（空目录 / 两张 / 删当前顺位 / 删空回退 /
  满槽 / 补洞 / 旧图迁移 / 重复迁移），**ALL PASS**
- `versionCode=30 / versionName=3.0`
- `classes.dex ~ classes7.dex` 与 v29 md5 逐个一致，只有 `classes8.dex` 变了
- `classes8.dex` 里 `android.intent.action.OPEN_DOCUMENT`、`android.intent.extra.ALLOW_MULTIPLE`、
  `bg_user_`、`getClipData`、`HorizontalScrollView` 均存在
- `javac` 零 error、未分包、`zipalign -c 4` 通过、v1+v2+v3 签名通过

---

# v31 —— 修「选了本机图但背景不变」

## 一、根因

v30 把背景缓存键从 `4` 改成了 `100 + 槽位`（为了区分多张本机图），
但 `loadBgAsync()` 里判断"要不要解本机图"的地方还是老写法：

```java
final Bitmap b = (want == 4) ? decodeBgFile(...) : decodeAssetBg();
```

`want` 现在是 100/101/…，`== 4` 永远不成立，于是**每次选本机图都去解内置图**：
上传成功、缩略图也有、「本机」格子也变了，唯独背景不换。这是重构漏改，属于回归。

## 二、改动

1. `want` 判断改成 `want >= 100`，并抽成 `bgWant()` 一处生成，避免以后再对不上。
2. 解码用的 `File` 提到主线程先取好再传进后台：原来后台线程里再调 `currentUserFile()`，
   这期间用户切了槽位就会解到另一张上去。
3. 回调里加 `want != bgWant()` 就丢弃：期间换过背景/删了那张，旧结果不落地。
4. 贴图不再按 ImageView 引用比较，改成贴到 `bgHolder` 当前那一个 ImageView ——
   按引用比会漏贴（rebuildBg 换过实例时），表现同样是"图永远不出现"。
5. 选背景的 `sp.edit()...apply()` 全部改 `commit()`：选完立刻被系统回收时，
   apply 的异步写还没落盘，回来又是旧背景。

## 三、验证

- `want` 分支单独跑 7 条断言（内置/本机 0 号/7 号/负槽位/不同槽位 key/渐变），**ALL PASS**
- `versionCode=31 / versionName=3.1`
- `classes.dex ~ classes7.dex` 与 v30 md5 逐个一致（核心仍未动）

---

# v32 —— 全面复查（核心未动）+ 三处小修

## 一、核心验证（先说结论：没被改坏）

| 检查项 | 结果 |
|---|---|
| `classes.dex ~ classes7.dex` 与 v28 的 md5 | 逐个一致：`cb28a31d / 23103be3 / f5e31ada / 0566b23c / aa41566f / e76c6fc9 / 1b94dc43` |
| 加速内核倍率（反射实跑 12 条断言） | 全部通过：普通 1.2s→1.5×、6s→2.5×、15s→3×；游戏降一档 6s→1.5×；门槛以下不加速；低端机 0.8 系数下限 1.05 |
| 进程过滤 | 微信 / systemui 不加速，普通应用不拦 |
| eCPM 判定 | 仍在 `classes6.dex`（`EcpmHook`），md5 与 v28 相同，一行未改 |
| 入口 `assets/xposed_init` | 仍是两行，`PlayerScan` 在前、`EcpmHook` 在后 |
| 清单组件 | Activity exported、FloatService `specialUse`、LogReceiver + `nn.ecpm.LOG`、ConfigProvider 全在；权限齐全 |
| `javac -Xlint:all` | 除 deprecation 外无告警 |

## 二、这轮查出来并修掉的

| 位置 | 问题 | 处理 |
|---|---|---|
| `pickBg(4)` | 点「本机」格子一律弹相册，用户想切回自己已传的图，反被选图页挡住 | 有图就直接切过去，一张都没有才弹相册 |
| `chooseImage()` | 8 张满了还会先打开一次相册，选完才提示"已经满了" | 进方法先判空位，满直接提示 |
| `writeUserBg()` | 1600px 用 ARGB_8888 解码，临时内存约 10MB，连存 8 张容易触发 GC | 改 RGB_565（存 JPEG 不需要透明），减半 |

## 三、看过但确认没问题的

- 删除当前图 → 顺位到剩下的第一张；删空 → 回退内置图（JVM 16 条断言）
- 背景缓存键 `0 / 100+槽位`，回调里 `want != bgWant()` 丢弃过期结果
- edge-to-edge：标题 `padding-top = 12dp + 状态栏`，底栏 `padding-bottom = 6dp + max(导航栏, 键盘)`
- 日志上限裁剪走 `Diag.LOCK`，按整行裁，末尾换行不计行
- 悬浮窗状态灯读 `max(config.ecpm_ts, logbuf.xml mtime)`，不依赖隐式广播

## 四、已知限制（不改，如实记着）

- 安卓 5.0~7.1 的三键导航栏系统层面不支持纯透明，只能半透明黑兜底
- 穿山甲只覆盖 `MediationAdEcpmInfo.getEcpm`；方法名变了不会重试
- 服务端按真实时长对账、Unity/UE/Cocos 原生计时器改不了

---

# v33 —— 改名 CK广告助手 + 反馈加群入口

## 一、需求

"加个反馈跳转加群，软件名字换成 CK广告助手，上面那个 @QVQ660 换成 1132982709"

## 二、改动

1. **改名五处**（少一处在真机上就会露馅）：

   | 位置 | 之前 | 现在 |
   |---|---|---|
   | 界面标题 | zy 广告助手 | CK广告助手 |
   | 悬浮窗面板标题 | zy 广告助手 | CK广告助手 |
   | 前台服务通知 | zy 广告助手 · 悬浮窗已开 | CK广告助手 · 悬浮窗已开 |
   | 桌面图标名 `app_name` | zy广告助手最终版 | CK广告助手 |
   | 模块描述 `xposeddescription` | zy广告助手 | CK广告助手 |

   `app_name` 是 `@string/app_name` 引用的，真值在 `res/values/strings.xml`；
   这份 strings 每次构建都从基准 APK 重新解出来，所以改名写进 `build_full.sh` 第 5 步，
   不靠手工改包。

2. **顶栏**：`3.2 · @QVQ660` → `3.3 · 1132982709`，这串数字本身是可点区域，
   点一下 `openGroup()` 直接跳 QQ。窄屏下加了 `ellipsize`，宁可省略号也不挤走标题。

3. **报告页新增「反馈与加群」**：一句说明 + 一个 `加入交流群 · 1132982709` 按钮。
   入口放在"运行报告"下面，不用翻到日志底下去找。

4. **跳转三级兜底**：

   ```
   mqqapi://card/show_pslcard?src_type=internal&uin=1132982709&card_type=group&source=qrcode
     ↓ 失败
   mqq://im/chat?chat_type=group&uin=1132982709&version=1&src_type=web
     ↓ 失败
   mqqwpa://im/chat?chat_type=group&uin=1132982709&version=1&src_type=web
     ↓ 全失败（没装 QQ）
   把群号复制到剪贴板 + Toast 提示，手动去 QQ 搜
   ```

   不用 `queryIntentActivities` 判"装没装"——Android 11+ 的包可见性限制下它会对
   未声明 `<queries>` 的 QQ 返回空，判了反而误伤。直接 `startActivity` + `catch`。

## 三、验证

- `versionCode=33 / versionName=3.3`
- `aapt dump badging` → `application-label:'CK广告助手'`、`launchable-activity label='CK广告助手'`
- 清单 `xposeddescription` 读到 `CK广告助手`
- `classes8.dex` 里 `CK广告助手`、`1132982709`、`mqqapi://card/show_pslcard`、
  `mqq://im/chat`、`ClipboardManager`、`加入交流群`、`反馈与加群` 全部存在
- **`classes.dex ~ classes7.dex` 与 v32 md5 逐个一致**（eCPM 判定 + 加速内核一行没动）
- `javac` 零 error、未分包、`zipalign -c 4` 通过、v1+v2+v3 签名通过

---

# v34 —— 适配更多广告（eCPM 补充层）

## 一、为什么要加这一层

原来的 `EcpmHook`（classes6.dex，原包自带）覆盖规则是死的：

```java
// isEcpmMethod：方法名小写含 "cpm"
// findMethod：只找无参重载
// apply：只处理 String / int / long / double / float
```

于是有三块永远改不到：

| 漏掉的情形 | 例子 | 结果 |
|---|---|---|
| 带参数的取值方法 | `getEcpm(int adType)`、`getEcpm(String adn)` | `findMethod` 只匹配无参，直接跳过 |
| 不叫 cpm 的价格方法 | `getPrice()`、`getBidPrice()`、`getRevenue()`、`getPayout()` | 名字里没有 cpm，`isEcpmMethod` 不命中 |
| BigDecimal 返回值 | `BigDecimal getEcpm()` | hook 挂上了，但 `apply` 走不到任何类型分支，值不变 |

## 二、做法：独立补充层，不碰核心

新增 `nn.ecpm.EcpmPlus`，编进界面 dex（classes8.dex），`xposed_init` 加第三行：

```
com.adspeed.hook.PlayerScan
nn.ecpm.EcpmHook
nn.ecpm.EcpmPlus      ← 新增
```

它做的事：

1. hook `ClassLoader.loadClass`，只对"像广告"的类动手：
   34 个补充包前缀（字节 mSDK / Pangle 独立包 / 快手 / Moloco / Criteo / Taboola /
   Teads / Liftoff / 荣耀 / 亚马逊 APS …）+ 15 个类名关键字（adunit / adinfo /
   adloader / adresponse / advalue / mediation / reward / interstitial …）。
2. 对命中的类，反射 `getDeclaredMethods`，按 `wantHook()` 挑方法：

   | 条件 | 处理 |
   |---|---|
   | 无参 + 名字含 cpm + 非 BigDecimal | **跳过**，主 hook 已经管了，不重复改 |
   | 带参 + 名字含 cpm | 挂 |
   | 名字含 price / bid / revenue / income / payout | 挂 |
   | 返回 BigDecimal 的 cpm | 挂 |
   | 静态方法且名字不含 cpm | 跳过（可能是全局算价） |
   | 返回 boolean / 对象 / void | 跳过 |

3. 值域与主 hook 共用配置（`content://nn.ecpm.config/config` 的 `min` / `max` / `skip`），
   15 秒重读一次，用户改区间不用重启目标应用。原值 ≤ 0 不动。
4. 每次改写往 `content://nn.ecpm.config/log` 写 `补充 类.方法 旧值 -> 新值`，
   报告页把它统计成「eCPM 改写 N 次（其中扩展 M 次）」。

## 三、防呆

| 风险 | 处理 |
|---|---|
| 反射 `getDeclaredMethods` 反过来触发类加载，无限递归 | `volatile boolean busy` 重入保护 |
| 同一个类被 `loadClass(String)` 和 `loadClass(String, boolean)` 处理两次 | `Set<String> seen` 去重，且先入集合再反射 |
| 类加载是启动热路径，判断太重 | 先排掉 java/android/androidx/kotlin/dalvik/sun，再做前缀与关键字匹配 |
| 某些类反射时抛 `NoClassDefFoundError`（缺依赖） | 每个方法、每个类各自 try，坏的跳过不影响其他 |
| 界面 dex 涨到 64K 方法 | 构建脚本已有断言，分包直接报错退出 |

## 四、验证

- 规则函数 `wantHook()` 抽成纯函数，在 JVM 上跑 **25 条断言全过**：
  主 hook 已覆盖的 3 种必须让开、要补的 9 种必须命中、静态/非取值/布尔返回 7 种必须拒绝、
  大小写与复数命名 3 种边界。
- `versionCode=34 / versionName=3.4`
- **`classes.dex ~ classes7.dex` 与 v33 的 md5 逐个一致**（含 EcpmHook 的 classes6、
  加速内核的 classes7），只有 `classes8.dex` 变了
- `classes8.dex` 里 `Lnn/ecpm/EcpmPlus;` 与 3 个匿名内部类都在，方法数未超 64K
- `assets/xposed_init` 三行，顺序为 加速 → 主判定 → 补充层
- `javac` 零 error、`zipalign -c 4` 通过、v1+v2+v3 签名通过

## 五、仍然改不到的地方（如实记着）

- 值来自服务端、不经过任何 getter 的（多数联盟的实时竞价）；
- 纯字段暴露的 eCPM（Xposed 不能 hook 字段，只能 hook 方法）；
- 被加固/混淆到方法名完全不含 cpm/price/bid/revenue 的，命名猜不到；
- 单位：沿用主 hook 的"分"，不按各 SDK 自己的单位换算。

---

# v35 —— 对着原始源码复查 eCPM，修「改了区间不生效」

这版拿到原版 `EcpmHook.java` 全量源码（21KB，jadx 反编译无缺块），逐行对照后确认了两件事，
也修掉了一个一直被当成“没效果”的真 bug。

## 一、核心完整性（先说结论）

| 检查项 | 结果 |
|---|---|
| `RAW` 目标表 | 原版 35 条，包里 `classes2.dex` **35/35 全部命中**，无缺项 |
| `SDK_PREFIXES` | 原版 52 条，包里 **52/52 全部命中** |
| `classes.dex ~ classes7.dex` 与 v34 的 md5 | 逐个一致（含 `EcpmHook` 所在的 `classes2.dex`） |
| 入口 `assets/xposed_init` | 三行：`PlayerScan` → `EcpmHook` → `EcpmPlus` |

`EcpmHook` 实际在 **classes2.dex**（不是之前记的 classes6，那个是加速模块自己的类），
这版核对纠正了这个记录。

## 二、找到的真 bug：改了区间，目标 App 不重启就是不生效

原版 `EcpmHook.startInstall()` 的主循环：

```java
if (!configLoaded) configLoaded = loadConfig();   // 成功一次，configLoaded 变 true
```

`configLoaded` 一旦为 true，**再也不会重读 provider**。它读出来的 `ecpmMin / ecpmMax /
skipNonPositive` 是启动那一刻的值，之后用户在外观页怎么改，目标进程都用老值继续改。

而界面上写的是「已保存，目标应用最多 10 秒读到」—— 这句在 eCPM 这一侧是假的。
用户改了 100000~130000 → 300000~500000，发现 App 里还是老样子，很自然会判断“eCPM 没效果”。

### 修法：不碰它一个字节，替它做热更新

`EcpmPlus` 里加了一段：

1. `Class.forName("nn.ecpm.EcpmHook", false, cl)` 拿到类，`hookAllMethods(类, "emit", …)`
   —— `emit` 是它的私有方法，每次配置读取成功都会调一次，回调里 `thisObject` 就是它的实例；
2. 拿到实例后起一个守护线程，**每 10 秒** query 一次 `content://nn.ecpm.config/config`，
   和实例上 `ecpmMin / ecpmMax / skipNonPositive` 三个字段比对；
3. 不一样就 `Field.setAccessible(true)` + `setLong/setBoolean` 写回去。

等于替它补上了“周期性重读配置”这一步，`EcpmHook` 的字节码一行没动。拿不到实例
（比如配置一直读取失败）就静默降级，行为跟以前一样，不会更糟。

## 三、顺手修的三个

| 位置 | 问题 | 处理 |
|---|---|---|
| `EcpmPlus.emit()` | 每改写一次就跨进程 `insert` 一条日志，列表滚动时每个 item 一次 getter，等于每条都做一次 IPC | 按主 hook 的口径节流：头 2 次必记，之后每 100 次记一条 |
| `EcpmPlus` 类加载回调 | `busy` 为 true 时直接 `return`，这段时间进来的类**永久丢失**，不再扫描 | 先入 `ConcurrentLinkedQueue`，持有 busy 的线程负责把队列扫完 |
| `EcpmPlus.wantHook()` | 「无参 + 含 cpm + 普通数值」一律让给主 hook。但主 hook 只扫 52 个前缀和它自己那套类名关键字，落在**这个范围外**的类，两边都不管 | 新增 `mainCovers(cn)`：类在它范围内才让开，不在范围内由本层接管 |

## 四、日志上限的说明写实

原版 `ConfigProvider.insert()` 里写死了 20000 字符：

```java
String nl = old + msg + "\n";
if (nl.length() > 20000) nl = nl.substring(nl.length() - 20000);   // 还会把一行切成两半
```

所以「日志上限 10000 行」只对加速那一路有效，eCPM 那一路实际只有约 600 行，
而且截断点是字符中间。这段在 classes2.dex 里，属于核心，**不动**；
改成在「日志上限」那块把话说清楚：eCPM 一路核心自带 2 万字符上限，设更大也只保留那么多。

## 五、验证

- `wantHook` 五参版 + `mainCovers` 跑了 **18 条断言全过**：
  主覆盖的类上无参 cpm 让开、带参/BigDecimal/price 仍接手；主盲区的类上无参 cpm 接管；
  不该碰的 `getCount / setEcpm / isEcpmReady` 仍拒绝；类名判断覆盖 `com.qq.e.` /
  `com.bytedance.msdk.` / `reward` / `msdk` / `hihonor.ads` / 空串 / null
- v34 那套 25 条规则断言回归，**ALL PASS**
- `versionCode=35 / versionName=3.5`
- `classes.dex ~ classes7.dex` 与 v34 md5 **逐个一致**，只有 `classes8.dex` 变了
- `classes8.dex` 里 `EcpmPlus-sync`、`ecpmMin`、`ecpmMax`、`skipNonPositive`、
  `mainCovers`、`nn.ecpm.EcpmHook` 均存在
- `javac` 零 error、未分包、`zipalign -c 4` 通过、v1+v2+v3 签名通过

## 六、仍然改不了的地方（如实记着）

- **收益不会变**：改的是 App 从 SDK 读到的那个数字，SDK 与服务器之间的竞价/结算不经过这些 getter；
- 值直接来自服务端、不进任何 getter 的；
- 纯字段暴露的 eCPM（Xposed 只能 hook 方法）；
- 方法名被加固混淆到不含 cpm/price/bid/revenue 的；
- 单位沿用“分”，不按各 SDK 自己的单位换算。

---

# v36 —— 加速「开了却没效果」，以及一圈保护

这一版只动加速内核和界面，eCPM 的核心（`classes2.dex` 里的 `EcpmHook`、`classes8.dex` 里的 `EcpmPlus`）
一个字节都没碰，`classes.dex ~ classes6.dex` 与 v35 的 md5 逐个一致。

## 一、先说根因：四个真问题，不是"玄学"

| # | 问题 | 后果 |
|---|---|---|
| 1 | 智能档下限 `SMART_FLOOR_APP = 1200`，而广告倒计时最常见步长是 **1000ms** | 1000ms 的单次调用一律 `rateFor()` 返回 1.0，直接放过；只能靠 `loopRate` 连续命中 3 次才提速，而开屏广告总共 5 秒 —— **前 3 秒完全没加速** |
| 2 | `LOOP_HIT = 3`、`LOOP_WIN = 3000` | 倒计时第 3 次才认成循环，窗口还卡得死，执行耗时一抖就断链 |
| 3 | `if (r < MIN_EFFECTIVE && smartOn && !gameMode) r = loopRate(...)` | **游戏进程整段跳过循环识别**。游戏内激励视频的倒计时恰恰是 1000ms 循环，等于游戏里完全没加速 |
| 4 | 只接了 `Handler` / `Timer` / `CountDownTimer` | 新版 SDK 的倒计时组件大量改用 `ScheduledExecutorService.schedule*` 和 `postAtTime`，这两条路一条都没接 |

第 1 条影响最大，也最容易被当成"模块坏了"。

## 二、改了什么

| 位置 | 改动 |
|---|---|
| 阈值 | `MIN_MS_APP` 800→600、`MIN_MS_GAME` 3000→2000、`SMART_FLOOR_APP` 1200→1000、`SMART_FLOOR_GAME` 3000→2500、`WARMUP_MS` 1000→500 |
| 循环识别 | `LOOP_HIT` 3→2、`LOOP_WIN` 3000→5000；短 tick（≤1600ms）单独给档：普通 2.5×、游戏 2.0× |
| 游戏档 | 去掉 `!gameMode` 限制，游戏里的 1 秒循环同样参与 |
| 新通道 | `postAtTime` / `sendMessageAtTime`（按 `SystemClock.uptimeMillis` 换算）、`ScheduledThreadPoolExecutor.schedule / scheduleAtFixedRate / scheduleWithFixedDelay`（按 `TimeUnit` 换算，溢出返回 -1 直接放过） |
| 去重 | R1 从"0/1 标志"改成**线程内深度计数**（`enterForward / leaveForward`）：`postDelayed → sendMessageDelayed → sendMessageAtTime` 是一条链，只允许最外层缩一次 |
| 循环 key | 从 `Method` 改成**调用点**（`类名#方法名`）。原来全 App 的 `postDelayed` 共用一个方法对象，消息轮询和广告倒计时会混成一条循环 |

去重这条必须说清楚：加了 `postAtTime` 之后，一条 5 秒延时会被 `postDelayed` 缩到 1.7 秒、
再被 `sendMessageAtTime` 当成 1.7 秒缩到 1.1 秒 —— 实际变成 4.5×，远超设计上限。深度计数解决的正是这个。

## 三、环境保护（三条，都是"别把别人的 App 搞坏"）

按需求清单第五节，本模块**不做任何反检测 / 隐藏痕迹**的东西。这里的"环境保护"指：

1. **熔断**：任何 hook 回调抛异常都计数，累计 120 次自动停用加速，所有回调直接放行，
   并写一条 `guard: 异常过多，已自动停用加速以保护目标应用`。
   宁可没效果，也不能把目标 App 拖崩。
2. **保护名单**：新增建行/中行/北京银行/招行、券商（同花顺/国信/华泰/招商证券/东财）、
   密码管理器（Bitwarden / 1Password / LastPass / Authy / Google Authenticator）、
   输入法（搜狗 / 百度 / 讯飞 / Google）、企业 MDM（Intune / AirWatch）、TalkBack、短信/拨号。
   这类进程里缩延时只有副作用。
3. **误伤范围**：`Timer.schedule(t, delay, period)` 的 period 和 Handler 循环一样会缩
   （广告倒计时本来就是"每秒 tick 一次"，不缩 period 就只有第一秒快）；
   但 `ScheduledExecutorService.scheduleAtFixedRate` 不缩 period —— 那个多半是后台定时同步，
   缩了就是 2.5 倍频轮询，耗电和请求频率都会翻倍。

## 四、界面上能看见效果了

加速页顶部新增「运行状态」：

```
● 加速中
缩时 146 次 / 省 89 秒 / 补速 12 次 / 当前 2.5×
最近一次：刚刚
倍率正常，广告倒计时和播放器都在加速。
```

判断用两个时间戳，不混：

- `tick_ts`：加速内核在这个进程里活动过（含"注入成功"那一条）→ 显示「已注入，未见加速」；
- `speed_ts`：真的缩过时间（`tick: ...` 统计行）→ 才显示「加速中」。

以前只有开关、没有任何回执，用户只能凭感觉猜，这正是"好像没效果"的来源。

## 五、验证

- 内核行为断言 **50 条全过**：阈值、`rateFor` 六档、循环识别（第 1 次不缩 / 第 2 次 2.5× /
  参数变了不算循环）、游戏档 2.0×、低端机 0.8 系数、`toMs/fromMs` 六种单位 + 溢出、
  投递链深度计数（最外层才缩、链结束恢复）、循环 key 按调用点分组、熔断 119→120 边界
- 统计行提取 **7 条全过**：行首匹配、多行取最后一条、`ctick:` 不误判、160 字符截断
- `classes.dex ~ classes6.dex` 与 v35 md5 **逐个一致**，只有 `classes7.dex`（内核）和
  `classes8.dex`（界面）变了
- `classes7.dex` 里 `ScheduledThreadPoolExecutor`、`postAtTime`、`sendMessageAtTime`、
  `enterForward`、`keyFor`、`GUARD` 均在；`hiddenClass` / `com.elderdrivers` /
  `io.github.lsposed` 均**不存在**（确认没混进反检测代码）
- `versionCode=36 / versionName=3.6`，`zipalign -c 4` 通过，v1+v2+v3 签名通过，
  入口仍是三行 `PlayerScan → EcpmHook → EcpmPlus`

## 六、仍然改不了的（如实记着）

- **服务端按真实播放时长结算**的激励视频，客户端加速改变不了到账金额；
- Unity / UE / Cocos 用原生计时器（`Time.deltaTime`、引擎自己的 scheduler）实现的倒计时；
- WebView 里 JS 的 `setTimeout` / `countDown`（那是 Chromium 的定时器，不在我们 hook 的 Java 层）；
- 加固后把倒计时封进 native 的（`sleep` / `nanosleep` 在 so 里）；
- 个别 SDK 会用"开始时间戳 + 当前时间"自己算剩余秒数，不看延时 —— 这种只能靠播放器倍速那一路。
