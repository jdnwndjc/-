## 改了什么

<!-- 一句话说明，以及不改会怎样 -->

## 为什么

<!-- 如果是阈值/倍率调整，给数据：什么设备、什么广告、改前改后各是多少 -->

## 自检

- [ ] `./build-kernel-only.sh` 通过
- [ ] 界面层 `javac` 无 error
- [ ] 没有提交 `*.keystore` / `*.apk` / `baseline.apk`
- [ ] 没有把口令写进脚本或注释
- [ ] 动了 `PlayerScan` 的话，说明了改了哪条阈值、影响哪些进程
- [ ] 改了行为的话，同步更新了 `docs/ARCHITECTURE.md`
- [ ] 不是反检测类改动（见 `CONTRIBUTING.md`）
