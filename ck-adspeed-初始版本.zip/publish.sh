#!/usr/bin/env bash
# 一键发布。详细说明见 PUBLISH.md
#
#   ./publish.sh github <github用户名> [仓库名]
#   ./publish.sh gitee  <gitee用户名>  [仓库名]
#   ./publish.sh both   <github用户名> <gitee用户名> [仓库名]
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
DEF_NAME="ck-adspeed"
cd "$ROOT"

die() { echo "错误：$*" >&2; exit 1; }

need_clean() {
  if [ -n "$(git status --porcelain)" ]; then
    echo "工作区有未提交的改动，先 commit 再发布：" >&2
    git status --short >&2
    exit 1
  fi
}

push_github() {
  local user="${1:?用法: ./publish.sh github <用户名> [仓库名]}"
  local name="${2:-$DEF_NAME}"
  command -v gh >/dev/null 2>&1 || die "缺少 gh CLI，见 https://cli.github.com"
  gh auth status >/dev/null 2>&1 || die "未登录，先运行 gh auth login"

  if git remote get-url origin >/dev/null 2>&1; then
    echo "origin 已存在 -> $(git remote get-url origin)"
    git push -u origin main
  else
    gh repo create "$name" --public --source=. --remote=origin --push \
      --description "Android delay / playback-speed hook framework for LSPosed"
    echo "已创建 https://github.com/$user/$name"
  fi
}

push_gitee() {
  local user="${1:?用法: ./publish.sh gitee <用户名> [仓库名]}"
  local name="${2:-$DEF_NAME}"
  local url="https://gitee.com/$user/$name.git"

  echo "提示：Gitee 需要先在网页建空仓（不要勾 Readme 初始化）"
  echo "      https://gitee.com/projects/new"
  echo "      仓库名：$name"

  if ! git remote get-url gitee >/dev/null 2>&1; then
    git remote add gitee "$url"
  fi
  git push -u gitee main
  echo "已推送 https://gitee.com/$user/$name"
}

case "${1:-}" in
  github)
    need_clean
    push_github "${2:-}" "${3:-}"
    ;;
  gitee)
    need_clean
    push_gitee "${2:-}" "${3:-}"
    ;;
  both)
    need_clean
    push_github "${2:-}" "${4:-}"
    push_gitee "${3:-}" "${4:-}"
    ;;
  *)
    cat <<'EOF'
用法：
  ./publish.sh github <github用户名> [仓库名]
  ./publish.sh gitee  <gitee用户名>  [仓库名]
  ./publish.sh both   <github用户名> <gitee用户名> [仓库名]

详见 PUBLISH.md
EOF
    exit 1
    ;;
esac
