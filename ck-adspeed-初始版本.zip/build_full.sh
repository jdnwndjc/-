#!/usr/bin/env bash
# 全量重建：编译两个 Java 源 → 换 dex → 改清单 → apktool 重打包 → 对齐 → 签名
#
# 用法:
#   BT=/path/to/build-tools/34.0.0 \
#   ANDROID_JAR=/path/to/platform-34/android.jar \
#   APKTOOL=/path/to/apktool.jar \
#   ./build_full.sh baseline.apk out.apk ./release.keystore release
#
# 与 build.sh 的区别：build.sh 只换 classes7.dex（热修），这里连 classes8.dex（界面）、
# 清单、assets 一起处理，用于改 minSdk / 权限 / 版本号这类需要动资源的改动。
set -euo pipefail

# 改版前先过一遍铁律，完整版见同目录 需求清单.md
echo "┌─ 需求清单（每次构建都会打印）───────────────────────────────"
echo "│ 1. 每个功能都要有底部栏入口       2. 一页只允许一块面板"
echo "│ 3. 底部导航文字不许用半透明白     4. eCPM 判定 / 加速内核不许动"
echo "│ 5. 只交付最新版，旧 APK 一律删掉"
echo "└────────────────────────────────────────────────────────────"

APK_IN="${1:?缺少基准 APK}"
APK_OUT="${2:?缺少输出 APK}"
KS="${3:?缺少 keystore}"
ALIAS="${4:?缺少 key alias}"
KS_PASS="${KS_PASS:?请设置 KS_PASS 环境变量（密钥库口令，不要写进脚本）}"

ROOT="$(cd "$(dirname "$0")" && pwd)"
BT="${BT:?请设置 BT 指向 build-tools 目录}"
ANDROID_JAR="${ANDROID_JAR:?请设置 ANDROID_JAR 指向 platform android.jar}"
APKTOOL="${APKTOOL:?请设置 APKTOOL 指向 apktool.jar}"

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

echo "[1/7] 编译加速内核"
mkdir -p "$WORK/pc" "$WORK/pd"
javac -nowarn -source 8 -target 8 -cp "$ROOT/lib/stub.jar" \
  -d "$WORK/pc" "$ROOT/src-java/PlayerScan.java"
"$BT/d8" --min-api 21 --lib "$ANDROID_JAR" --classpath "$ROOT/lib/stub.jar" \
  --output "$WORK/pd" $(find "$WORK/pc" -name '*.class')

echo "[2/7] 编译界面"
mkdir -p "$WORK/uc" "$WORK/ud"
# 界面 dex 里现在还有 EcpmPlus（eCPM 补充层），它要 Xposed API，
# 所以 classpath 必须带上 stub.jar；否则编译期就找不到 IXposedHookLoadPackage
javac -nowarn -source 8 -target 8 -cp "$ANDROID_JAR:$ROOT/lib/stub.jar" \
  -d "$WORK/uc" "$ROOT"/src-ui/nn/ecpm/*.java
"$BT/d8" --min-api 21 --lib "$ANDROID_JAR" --classpath "$ROOT/lib/stub.jar" \
  --output "$WORK/ud" $(find "$WORK/uc" -name '*.class')
# 界面层如果哪天涨到 64K 方法，d8 会分出 classes2.dex，这里必须显式报错，
# 否则 classes8.dex 只装了一半的类，运行时会 NoClassDefFoundError
if [ ! -f "$WORK/ud/classes.dex" ] || [ -f "$WORK/ud/classes2.dex" ]; then
  echo "界面 dex 分包了（超过 64K 方法），需要调整 dex 分配" >&2
  exit 1
fi

echo "[3/7] 解包基准 APK"
java -jar "$APKTOOL" d -s -f "$APK_IN" -o "$WORK/apk" >/dev/null

echo "[4/7] 换 dex / 入口 / 去无用 so"
cp "$WORK/pd/classes.dex" "$WORK/apk/classes7.dex"
cp "$WORK/ud/classes.dex" "$WORK/apk/classes8.dex"
rm -rf "$WORK/apk/lib"
# PlayerScan 放第一行：EcpmHook 在个别 ROM / 新系统上初始化失败时，
# 不能把加速内核一起带下去
# 三行入口：加速内核 → eCPM 主判定 → eCPM 补充层。
# 三个都各自 try 自己的，谁挂了不影响别人
printf 'com.adspeed.hook.PlayerScan\nnn.ecpm.EcpmHook\nnn.ecpm.EcpmPlus\n' > "$WORK/apk/assets/xposed_init"
rm -f "$WORK/apk/AndroidManifest.xml.bak"

# 免责声明原本的文件名是中文，apktool 解包时按 CP437 还原成乱码，
# 打包后 zip 里就是一个乱码条目名（功能无影响，但解压工具里很难看）。
# 统一改成 NOTICE.txt，内容原样保留。
NOTICE="$WORK/apk/assets/NOTICE.txt"
for f in "$WORK"/apk/assets/*.txt; do
  [ -e "$f" ] || continue
  [ "$f" = "$NOTICE" ] && continue
  [ -s "$NOTICE" ] || mv "$f" "$NOTICE"
  [ "$f" != "$NOTICE" ] && rm -f "$f"
done

echo "[5/7] 改清单与版本"
MAN="$WORK/apk/AndroidManifest.xml"
sed -i 's/android:debuggable="true"/android:debuggable="false"/' "$MAN"
if ! grep -q 'windowSoftInputMode' "$MAN"; then
  sed -i 's#<activity android:exported="true" android:label="@string/app_name" android:name="nn.ecpm.MainActivity">#<activity android:exported="true" android:label="@string/app_name" android:name="nn.ecpm.MainActivity" android:windowSoftInputMode="adjustResize">#' "$MAN"
fi
python3 - "$MAN" <<'PYMAN'
import io, os, re, sys
p = sys.argv[1]
s = io.open(p, encoding='utf-8').read()

# 悬浮窗服务 + 日志接收器
add = '''
        <service android:name="nn.ecpm.FloatService" android:exported="false"
            android:foregroundServiceType="specialUse"/>
        <receiver android:name="nn.ecpm.LogReceiver" android:exported="true">
            <intent-filter>
                <action android:name="nn.ecpm.LOG"/>
            </intent-filter>
        </receiver>
'''
if 'nn.ecpm.FloatService' not in s:
    s = s.replace('</application>', add + '    </application>')

perm = '''
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
'''
if 'FOREGROUND_SERVICE' not in s:
    s = s.replace('</manifest>', perm + '</manifest>')

# 应用名 / 模块描述统一成 CK广告助手。label 写的是 @string/app_name，真值在
# res/values/strings.xml，而这份 strings 每次构建都从基准 APK 重新解出来，
# 所以改名必须放在构建里，否则桌面图标下面还是旧名字。
s = s.replace('android:value="zy广告助手"', 'android:value="CK广告助手"')
res = os.path.join(os.path.dirname(p), 'res', 'values', 'strings.xml')
if os.path.exists(res):
    r = io.open(res, encoding='utf-8').read()
    r2 = re.sub(r'<string name="app_name">[^<]*</string>',
                '<string name="app_name">CK广告助手</string>', r)
    if r2 != r:
        io.open(res, 'w', encoding='utf-8').write(r2)
        print('[5/7] app_name -> CK广告助手')

io.open(p, 'w', encoding='utf-8').write(s)
PYMAN
YML="$WORK/apk/apktool.yml"
VER_CODE="${VER_CODE:-20}"
VER_NAME="${VER_NAME:-2.0}"
sed -i "s/^  minSdkVersion: .*/  minSdkVersion: 21/" "$YML"
sed -i "s/^  versionCode: .*/  versionCode: $VER_CODE/" "$YML"
sed -i "s/^  versionName: .*/  versionName: $VER_NAME/" "$YML"

echo "[6/7] 重打包 + 对齐"
java -jar "$APKTOOL" b "$WORK/apk" -o "$WORK/raw.apk" >/dev/null
"$BT/zipalign" -f -p 4 "$WORK/raw.apk" "$WORK/aligned.apk"
"$BT/zipalign" -c 4 "$WORK/aligned.apk"

echo "[7/7] 签名"
"$BT/apksigner" sign \
  --ks "$KS" --ks-key-alias "$ALIAS" \
  --ks-pass "pass:$KS_PASS" --key-pass "pass:$KS_PASS" \
  --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
  --out "$APK_OUT" "$WORK/aligned.apk"

"$BT/apksigner" verify "$APK_OUT" && echo "OK -> $APK_OUT"
