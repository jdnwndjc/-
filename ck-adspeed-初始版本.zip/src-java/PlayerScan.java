package com.adspeed.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * FastTick v7（加速有效性 + 环境保护版）
 *
 * v7 分两块：先把"明明开了却没效果"的几处真问题修掉，再给模块加一层
 * 「不把目标应用和系统搞坏」的保护。
 *
 * 注意：这里说的"环境保护"是**保护运行环境不被模块拖崩**，
 * 不是反检测。按需求清单第五节，本模块不做任何隐藏痕迹的东西。
 *
 * 一、有效性（E1–E5）
 *
 *  E1 最常见的广告倒计时是每秒一次的 1000ms 延时，而 v6 的智能档下限是
 *     1200ms —— 1000ms 的单次调用一律返回 1.0，只能靠 loopRate 连续命中
 *     3 次才提速，而开屏只有 5 秒，等于前 3 秒白等。现在下限降到 1000ms，
 *     且循环识别第 2 次就生效（LOOP_HIT 3→2，窗口 3s→5s）。
 *
 *  E2 游戏进程里 loopRate 被整段跳过（`smartOn && !gameMode`），
 *     而游戏内激励视频的倒计时恰恰是 1000ms 循环，等于游戏里完全没加速。
 *     现在游戏档也有循环通道，只是倍率低一档。
 *
 *  E3 补 ScheduledExecutorService。新版 SDK 的倒计时组件大量改用
 *     schedule / scheduleAtFixedRate，v6 一个都没接。
 *
 *  E4 补 Handler.postAtTime / sendMessageAtTime。倒计时为了对齐秒边界，
 *     常用绝对时间投递，这类调用以前直接漏掉。
 *
 *  E5 热身时间 1s → 0.5s。开屏广告在冷启动 1 秒内就开始倒计时，
 *     原来的热身窗正好把它挡在外面。
 *
 * 二、环境保护（G1–G3）
 *
 *  G1 熔断：任何 hook 回调抛异常都计数，累计到阈值自动停用加速，
 *     保证"宁可没效果，也不能把目标应用拖崩"。
 *  G2 保护名单：银行/券商/支付/密码管理器/输入法/系统安全等进程一律不注入。
 *  G3 循环识别按调用点分组：v6 拿 Method 当 key，全 App 的 postDelayed
 *     共用一个 Handler.postDelayed 方法对象，消息轮询和广告倒计时会混成
 *     同一条循环，把不相干的 1 秒轮询也一起拉快。现在按类名#方法名分组。
 *
 * v6 保留了 v4 的智能调速与 v17 的 R1（Handler 去重）、R2（只缩 CountDownTimer
 * 总时长）。下面这段是 v6 的原始说明，仍然有效：
 *
 * 相对 v4 的改动，全部围绕「同一份 dex 在 Android 5.0–17、32/64 位、
 * 各家 ROM、LSPosed 1.x/2.x 上都能安全跑」：
 *
 *  D1 取 Context 不再依赖 android.app.AndroidAppHelper（隐藏 API）。
 *     改为 hook Application.attachBaseContext / onCreate，拿到 Context 存下来；
 *     AndroidAppHelper 只做最后的兜底。否则在开了隐藏 API 拦截的 ROM 上，
 *     配置读取会静默失败，退回默认值（关了加速还是加速）。
 *
 *  D2 配置读取移出 hook 线程。provider 被 ROM 冻结时 query 会卡几秒，
 *     以前是在 Handler.postDelayed 的 before 里同步调用 —— 等于让目标 App
 *     主线程陪着等，低端机上直接 ANR。现在只在后台线程读，hook 只读 volatile。
 *
 *  D3 系统进程保护：uid < 10000 或 FLAG_PERSISTENT 的进程直接跳过。
 *     这类进程挂了就是整机卡开机，属于「一台设备都不能碰」的范围。
 *
 *  D4 类扫描加名字预过滤。原来每次 ClassLoader.loadClass 成功都进 scan()，
 *     一个 App 冷启动几千次调用，低端机上白烧 CPU；现在先看类名再决定。
 *
 *  D5 播放器 start 时补一次倍速（原来在 MainHook 里，且不看用户开关）。
 *     现在 MediaPlayer / Ijk / ExoPlayer / AliPlayer / TXVod 的 start|play
 *     结束后按开关补 setSpeed，MainHook 整个从入口摘掉。
 *
 *  D6 API 分级：PlaybackParams 是 API 23，ValueAnimator.setDuration 是 API 11，
 *     Build.SUPPORTED_ABIS 是 API 21。低版本上对应分支直接不装，不再靠抛异常。
 *
 *  D7 所有 install 各自 try/catch，一个失败不影响其余；日志带 api/abi/rom。
 *
 * 保留 v4 的智能调速（rateFor / loopRate / perfFactor / 突发保护）与
 * v17 的 R1（Handler 去重）、R2（只缩 CountDownTimer 总时长）。
 */
public class PlayerScan implements IXposedHookLoadPackage {

    /** 普通进程：≥600ms 的延时才缩（1000ms 的每秒倒计时必须能进来） */
    private static final long MIN_MS_APP = 600L;
    /** 游戏进程：只碰 ≥2 秒的延时 */
    private static final long MIN_MS_GAME = 2000L;
    private static final long MAX_MS = 900000L;
    private static final int DIV_APP = 3;
    private static final int DIV_GAME = 2;

    private static final long SMART_FLOOR_APP = 1000L;
    private static final long SMART_FLOOR_GAME = 2500L;
    /** 循环识别时的短 tick 上限：这个区间的重复延时按倒计时处理 */
    private static final long TICK_MAX_MS = 1600L;

    private static volatile long minMs = MIN_MS_APP;
    private static volatile boolean gameMode = false;

    private static final float SPEED = 3.0f;
    private static final float SPEED_MIN = 1.3f;
    private static final float SPEED_MAX = 3.0f;
    /** 低于这个倍率缩时间没有意义，直接放过（scale 里的 1.05 阈值同步） */
    private static final float MIN_EFFECTIVE = 1.05f;
    private static final int HOOK_CAP = 400;
    private static final int MAX_DEPTH = 6;
    private static final long ANIM_MIN_MS = 3000L;

    private static final String[] NAME_KEYS = {
            "player", "video", "media", "exo", "ijk", "ttve", "ttvideo",
            "playback", "avplay", "videoview", "kernel", "vod", "stream"
    };
    private static final String[] SPEED_M = {
            "setspeed", "setrate", "setplaybackspeed", "setplayspeed",
            "setvelocity", "setspeedrate", "setplayspeedratio", "setratex", "setspeedx",
            "setplayrate"
    };

    /** 不参与 hook 的进程：支付/金融/系统核心/社交/密码/输入法 */
    private static final String[] BLOCK_EXACT = {
            "android",
            "com.android.systemui", "com.android.settings", "com.android.phone",
            "com.android.bluetooth", "com.android.nfc", "com.android.vending",
            "com.android.chrome", "com.android.providers.media", "com.android.providers.contacts",
            "com.android.mms", "com.android.dialer", "com.android.incallui",
            "com.google.android.gms", "com.google.android.gsf",
            "com.google.android.dialer", "com.google.android.contacts",
            "com.google.android.packageinstaller", "com.google.android.permissioncontroller",
            "com.google.android.inputmethod.latin",
            "com.tencent.mm", "com.tencent.mobileqq", "com.eg.android.AlipayGphone",
            "com.unionpay", "com.tencent.androidqqmail",
            "com.miui.securitycenter", "com.coloros.safecenter", "com.oplus.safecenter",
            "com.huawei.systemmanager", "com.lbe.security.miui",
            "com.qihoo.security", "com.tencent.tmsecure",
            // 密码管理器：加速会让解锁/填充超时，收益为零
            "com.bitwarden", "com.onepassword.android", "com.lastpass.lpandroid",
            "com.x8bit.bitwarden", "com.authy.authy", "com.google.android.apps.authenticator2",
            // 输入法：延时被缩会让候选词/长按逻辑错乱
            "com.sohu.inputmethod.sogou", "com.baidu.input",
            "com.iflytek.inputmethod", "com.iflytek.inputmethod.miui",
            "com.google.android.apps.inputmethod.hindi",
            // 企业设备管理 / 无障碍：属于"碰了会出事"的一类
            "com.microsoft.intune", "com.airwatch.androidagent",
            "com.google.android.marvin.talkback",
            "com.adspeed.hook", "nn.ecpm"
    };
    private static final String[] BLOCK_PREFIX = {
            "com.icbc.", "com.ccb.", "com.abchina.", "com.bankcomm.", "com.cmbchina.",
            "com.cgbchina.", "com.spdb.", "com.cebbank.", "com.psbc.",
            "com.bankofbeijing.", "com.boc.", "com.chinamworld.", "com.cmb.",
            "com.alipay.", "com.unionpay.",
            // 券商：行情刷新被加速只会多烧流量
            "com.hexin.", "com.guosen.", "com.htsc.", "com.cmschina.", "com.eastmoney.",
            "com.android.providers.", "com.android.server.",
            "com.google.android.packageinstaller",
            "de.robv."
    };

    /** 扫描时要跳过的包前缀：这些类不是广告播放器，扫了纯浪费 */
    private static final String[] SKIP_PREFIX = {
            "java.", "javax.", "android.", "com.android.", "kotlin.", "kotlinx.",
            "de.robv.", "com.adspeed.", "nn.ecpm.", "sun.", "dalvik.",
            "org.apache.", "com.google.android.gms.", "com.google.firebase."
    };

    private static final Set<String> DONE = Collections.synchronizedSet(new HashSet<String>());
    private static final AtomicBoolean INSTALLED = new AtomicBoolean(false);
    private static final AtomicInteger HOOKED = new AtomicInteger(0);
    private static final AtomicBoolean CFG_LOADING = new AtomicBoolean(false);

    // ---------- G1 熔断 + 效果统计 ----------

    /**
     * 熔断：hook 回调里抛异常一次记一次。正常路径全部 try/catch 过，
     * 真抛出来的都是"这套 hook 在当前 ROM 上跑不通"的信号。
     * 累计到 GUARD_LIMIT 就自动停用加速 —— 宁可没效果，也不能把目标应用拖崩。
     */
    private static final int GUARD_LIMIT = 120;
    private static final AtomicInteger FAULTS = new AtomicInteger(0);
    private static volatile boolean GUARD = false;

    private static void fault(String where) {
        if (GUARD) return;
        int n = FAULTS.incrementAndGet();
        if (n == 1 || n == 10 || n == 50 || n == GUARD_LIMIT) {
            emit("guard: " + where + " 异常 " + n + " 次");
        }
        if (n >= GUARD_LIMIT) {
            GUARD = true;
            emit("guard: 异常过多，已自动停用加速以保护目标应用"
                    + "（重启目标应用即可恢复；请把这条日志反馈给作者）");
        }
    }

    /** 累计缩时次数 / 累计省掉的毫秒 / 播放器补速次数，用来回答"到底有没有效果" */
    private static final AtomicLong N_SCALE = new AtomicLong(0);
    private static final AtomicLong N_SAVE_MS = new AtomicLong(0);
    private static final AtomicLong N_SPEED = new AtomicLong(0);
    private static volatile long statAt = 0L;
    private static final long STAT_EVERY_MS = 30000L;

    private static void statReport() {
        long now = nowMs();
        long last = statAt;
        if (last != 0L && now - last < STAT_EVERY_MS) return;
        statAt = now;
        long n = N_SCALE.get();
        if (n == 0L) return;
        long save = N_SAVE_MS.get();
        emit("tick: 缩时 " + n + " 次 / 省 " + (save / 1000L) + " 秒 / 补速 "
                + N_SPEED.get() + " 次 / 当前 " + String.format("%.1f", playerSpeed()) + "×");
    }

    private static final ThreadLocal<int[]> DEPTH = new ThreadLocal<int[]>() {
        @Override
        protected int[] initialValue() {
            return new int[1];
        }
    };

    /**
     * R1：Handler 投递链的嵌套深度。
     * postDelayed → sendMessageDelayed → sendMessageAtTime 是一条链，
     * 每层都 hook 到，只允许最外层缩一次（见 enterForward）。
     *
     * 用深度计数而不是 0/1 标志：外层 before 时 +1、after 时 -1。
     * 以前用 0/1 标志，只要有一条路径没走 after（ROM 改写实现 / 异常栈），
     * 标志残留 1 就会把之后所有投递全部放过，加速静默失效。
     */
    private static final ThreadLocal<int[]> NEST = new ThreadLocal<int[]>() {
        @Override
        protected int[] initialValue() {
            return new int[1];
        }
    };

    // ---------- 设备信息（全部反射，避免编译期依赖 android.jar） ----------
    private static final int SDK = sdkInt();

    private static int sdkInt() {
        try {
            return Class.forName("android.os.Build$VERSION").getField("SDK_INT").getInt(null);
        } catch (Throwable t) {
            return 0;
        }
    }

    private static String abi() {
        try {
            Object v = Class.forName("android.os.Build").getField("SUPPORTED_ABIS").get(null);
            if (v instanceof String[] && ((String[]) v).length > 0) return ((String[]) v)[0];
        } catch (Throwable ignored) {
        }
        return "?";
    }

    private static String rom() {
        try {
            Object v = Class.forName("android.os.Build").getField("MANUFACTURER").get(null);
            String s = String.valueOf(v);
            return s.replace(' ', '_');
        } catch (Throwable ignored) {
            return "?";
        }
    }

    private static boolean blocked(String pkg) {
        for (String s : BLOCK_EXACT) {
            if (s.equals(pkg)) return true;
        }
        for (String s : BLOCK_PREFIX) {
            if (pkg.startsWith(s)) return true;
        }
        return false;
    }

    /**
     * D3：系统进程保护。uid < 10000 是所有系统 uid（1000 = system，
     * 1001 = radio…），FLAG_PERSISTENT 是常驻进程。碰这两类没有任何收益，
     * 一旦 hook 出问题就是开机卡屏。
     */
    private static boolean isSystemProcess(XC_LoadPackage.LoadPackageParam p) {
        try {
            if (p.appInfo == null) return false;
            Class<?> ai = p.appInfo.getClass();
            int uid = ai.getField("uid").getInt(p.appInfo);
            if (uid < 10000) return true;
            int flags = ai.getField("flags").getInt(p.appInfo);
            // ApplicationInfo.FLAG_PERSISTENT = 0x8
            if ((flags & 0x00000008) != 0) return true;
        } catch (Throwable ignored) {
        }
        return false;
    }

    // ---------- 0. 总开关（跨进程读 nn.ecpm.config） ----------
    private static volatile boolean speedOn = true;
    private static volatile boolean smartOn = true;
    private static volatile long cfgAt = 0L;
    private static final long CFG_TTL_MS = 10000L;
    private static final long CFG_RETRY_MS = 60000L;
    private static volatile boolean cfgOk = false;
    private static volatile String cfgSrc = "default";
    private static volatile String lastSaved = "";
    private static volatile String lastCfgLog = "";

    private static volatile float perfFactor = 1.0f;
    private static volatile long procStart = 0L;
    private static final long WARMUP_MS = 500L;
    private static final int BURST_LIMIT = 80;
    private static final long BURST_HOLD_MS = 5000L;
    private static final AtomicInteger BURST = new AtomicInteger(0);
    private static volatile long burstWin = 0L;
    private static volatile long burstUntil = 0L;

    /** D1：Application.attachBaseContext / onCreate 里抓到的 Context */
    private static volatile Object appCtx = null;
    private static final AtomicBoolean CTX_HOOKED = new AtomicBoolean(false);
    private static volatile Method mCurrentApplication = null;
    private static volatile long mCurAppNext = 0L;
    private static final long CUR_APP_RETRY_MS = 30000L;

    private static long nowMs() {
        return System.nanoTime() / 1000000L;
    }

    // ---------- 0a. Context 获取 ----------

    /**
     * D1：Xposed 的 AndroidAppHelper.currentApplication() 是隐藏 API，
     * Android 9+ 开了反射拦截的 ROM 上会直接抛 NoSuchMethodException。
     * 这里改成 hook 系统自己的 Application 生命周期，拿公开接口的对象。
     */
    private static void hookContext(ClassLoader cl) {
        if (!CTX_HOOKED.compareAndSet(false, true)) return;

        // 主通道：Instrumentation.callApplicationOnCreate 由框架直接调用，
        // 不受自定义 Application 是否 super 的影响，拿到的是 Application 本体。
        try {
            Class<?> ins = XposedHelpers.findClass("android.app.Instrumentation", cl);
            Class<?> appCls = XposedHelpers.findClass("android.app.Application", cl);
            Method m = ins.getMethod("callApplicationOnCreate", appCls);
            XposedBridge.hookMethod(m, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        if (appCtx == null && param.args != null && param.args.length > 0
                                && param.args[0] != null) {
                            appCtx = param.args[0];
                        }
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("FastTick v7: Instrumentation hook fail " + t);
        }

        // 备选：attachBaseContext 比 onCreate 早，部分进程里 onCreate 还没跑到。
        // 注意 attachBaseContext 是 ContextWrapper 的方法，Application 并没有覆写它，
        // 以前在 Application 上 getDeclaredMethod 必定抛异常 —— 这条通道一直没生效过。
        try {
            Class<?> cw = XposedHelpers.findClass("android.content.ContextWrapper", cl);
            Class<?> ctxCls = XposedHelpers.findClass("android.content.Context", cl);
            Method m = cw.getDeclaredMethod("attachBaseContext", ctxCls);
            m.setAccessible(true);
            XposedBridge.hookMethod(m, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        if (appCtx != null) return;
                        Object self = param.thisObject;
                        if (self == null || param.args == null || param.args.length == 0
                                || param.args[0] == null) return;
                        // 同一条链上 Activity / Service 也会调到，只要 Application 本体。
                        // 这里按类名往父类找，不写 instanceof android.app.Application：
                        // 热修脚本只用 stub.jar 编译，编译期没有 android 类可用。
                        if (!isApplication(self.getClass())) return;
                        appCtx = self;
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("FastTick v7: attachBaseContext hook fail " + t);
        }
    }

    private static boolean isApplication(Class<?> c) {
        for (int i = 0; c != null && i < 12; i++) {
            if ("android.app.Application".equals(c.getName())) return true;
            c = c.getSuperclass();
        }
        return false;
    }

    private static Object appCtx() {
        Object c = appCtx;
        if (c != null) return c;
        // 兜底：老框架 / 极早期调用，只有这条路能拿到
        try {
            if (mCurrentApplication == null && nowMs() >= mCurAppNext) {
                // 只试一次的话，第一次赶上类还没加载就永远拿不到了，改成 30 秒退避重试
                mCurAppNext = nowMs() + CUR_APP_RETRY_MS;
                try {
                    Class<?> h = Class.forName("android.app.AndroidAppHelper");
                    mCurrentApplication = h.getMethod("currentApplication");
                } catch (Throwable ignored) {
                }
            }
            if (mCurrentApplication != null) {
                Object a = mCurrentApplication.invoke(null);
                if (a != null) appCtx = a;
                return a;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    // ---------- 0b. 日志回传 ----------

    private static boolean pushLog(String msg) {
        Object app = appCtx();
        if (app == null) return false;
        try {
            Class<?> intentCls = Class.forName("android.content.Intent");
            Object it = intentCls.getConstructor(String.class).newInstance("nn.ecpm.LOG");
            Method put = intentCls.getMethod("putExtra", String.class, String.class);
            put.invoke(it, "msg", msg);
            // 打来源标记：EcpmHook 也发同一个 action，接收器靠这个区分两路日志，
            // 否则 eCPM 记录会被写进 config.buf，界面上重复两遍
            try {
                put.invoke(it, "src", "tick");
            } catch (Throwable ignored) {
            }
            try {
                intentCls.getMethod("setPackage", String.class).invoke(it, "nn.ecpm");
            } catch (Throwable ignored) {
            }
            Class.forName("android.content.Context")
                    .getMethod("sendBroadcast", intentCls).invoke(app, it);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * 日志队列。以前每条日志开一个线程、最多睡 3 秒，
     * 目标 App 冷启动时几十条日志就是几十个线程同时抢 CPU。
     * 现在统一进有界队列，一个 daemon 线程顺序发，发不掉就丢。
     */
    private static final java.util.concurrent.LinkedBlockingQueue<String> LOGQ =
            new java.util.concurrent.LinkedBlockingQueue<String>(128);
    private static final AtomicBoolean LOG_THREAD = new AtomicBoolean(false);

    private static void emit(final String msg) {
        try {
            XposedBridge.log(msg);
        } catch (Throwable ignored) {
        }
        try {
            if (LOGQ.size() >= 128) LOGQ.poll();
            LOGQ.offer(msg);
        } catch (Throwable ignored) {
            return;
        }
        if (!LOG_THREAD.compareAndSet(false, true)) return;
        Thread t = new Thread(new Runnable() {
            public void run() {
                while (true) {
                    try {
                        String m = LOGQ.poll(30L, java.util.concurrent.TimeUnit.SECONDS);
                        if (m == null) continue;
                        for (int i = 0; i < 3; i++) {
                            if (pushLog(m)) break;
                            Thread.sleep(400L);
                        }
                    } catch (InterruptedException ie) {
                        return;
                    } catch (Throwable ignored) {
                    }
                }
            }
        });
        t.setDaemon(true);
        t.setName("fasttick-log");
        t.start();
    }

    // ---------- 0c. 三条配置通道 ----------

    private static java.lang.reflect.Method ctx(String name, Class<?>... types) throws Exception {
        return Class.forName("android.content.Context").getMethod(name, types);
    }

    private static boolean loadFromXsp() {
        try {
            Class<?> c = Class.forName("de.robv.android.xposed.XSharedPreferences");
            Object sp = c.getConstructor(String.class, String.class)
                    .newInstance("nn.ecpm", "config");
            try {
                // 老 Xposed 靠这个放开文件权限；LSPosed 上是空实现，调了也不亏
                c.getMethod("makeWorldReadable").invoke(sp);
            } catch (Throwable ignored) {
            }
            c.getMethod("reload").invoke(sp);
            // contains 而不是 hasFile：文件存在但键缺失时读出来是默认值，
            // 会把用户的「关闭」变成「开启」
            Object has = c.getMethod("contains", String.class).invoke(sp, "speed_enabled");
            if (!Boolean.TRUE.equals(has)) return false;
            Object sl = c.getMethod("getBoolean", String.class, boolean.class)
                    .invoke(sp, "speed_enabled", Boolean.TRUE);
            Object sm = c.getMethod("getBoolean", String.class, boolean.class)
                    .invoke(sp, "smart_enabled", Boolean.TRUE);
            if (sl instanceof Boolean) speedOn = ((Boolean) sl).booleanValue();
            if (sm instanceof Boolean) smartOn = ((Boolean) sm).booleanValue();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean loadFromProvider(Object app) {
        if (app == null) return false;
        Object cursor = null;
        try {
            Object cr = ctx("getContentResolver").invoke(app);
            if (cr == null) return false;
            Class<?> uriCls = Class.forName("android.net.Uri");
            Object uri = uriCls.getMethod("parse", String.class)
                    .invoke(null, "content://nn.ecpm.config/config");
            Class<?> crCls = Class.forName("android.content.ContentResolver");
            cursor = crCls.getMethod("query", uriCls, String[].class, String.class,
                            String[].class, String.class)
                    .invoke(cr, uri, null, null, null, null);
            if (cursor == null) return false;

            Class<?> curCls = Class.forName("android.database.Cursor");
            Method mv = curCls.getMethod("moveToNext");
            Method gs = curCls.getMethod("getString", int.class);
            Method gi = curCls.getMethod("getColumnIndex", String.class);
            int ik = ((Integer) gi.invoke(cursor, "k")).intValue();
            int iv = ((Integer) gi.invoke(cursor, "v")).intValue();
            if (ik < 0 || iv < 0) return false;

            boolean got = false;
            while (((Boolean) mv.invoke(cursor)).booleanValue()) {
                Object k = gs.invoke(cursor, ik);
                Object v = gs.invoke(cursor, iv);
                if ("speed".equals(k)) {
                    speedOn = "1".equals(v);
                    got = true;
                } else if ("smart".equals(k)) {
                    smartOn = "1".equals(v);
                    got = true;
                }
            }
            return got;
        } catch (Throwable t) {
            return false;
        } finally {
            if (cursor != null) {
                try {
                    Class.forName("android.database.Cursor").getMethod("close").invoke(cursor);
                } catch (Throwable ignored) {
                }
            }
        }
    }

    private static Object prefs(Object app, String name) {
        if (app == null) return null;
        try {
            return ctx("getSharedPreferences", String.class, int.class)
                    .invoke(app, name, Integer.valueOf(0));
        } catch (Throwable t) {
            return null;
        }
    }

    private static boolean loadFromCache(Object app) {
        try {
            Object sp = prefs(app, "nn_ecpm_cache");
            if (sp == null) return false;
            Class<?> spCls = Class.forName("android.content.SharedPreferences");
            Object has = spCls.getMethod("contains", String.class).invoke(sp, "speed_enabled");
            if (!Boolean.TRUE.equals(has)) return false;
            Method gb = spCls.getMethod("getBoolean", String.class, boolean.class);
            speedOn = ((Boolean) gb.invoke(sp, "speed_enabled", Boolean.TRUE)).booleanValue();
            smartOn = ((Boolean) gb.invoke(sp, "smart_enabled", Boolean.TRUE)).booleanValue();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static void saveCache(Object app) {
        String sig = speedOn + "/" + smartOn;
        if (sig.equals(lastSaved)) return;
        try {
            Object sp = prefs(app, "nn_ecpm_cache");
            if (sp == null) return;
            Class<?> spCls = Class.forName("android.content.SharedPreferences");
            Object ed = spCls.getMethod("edit").invoke(sp);
            Class<?> edCls = Class.forName("android.content.SharedPreferences$Editor");
            edCls.getMethod("putBoolean", String.class, boolean.class)
                    .invoke(ed, "speed_enabled", Boolean.valueOf(speedOn));
            edCls.getMethod("putBoolean", String.class, boolean.class)
                    .invoke(ed, "smart_enabled", Boolean.valueOf(smartOn));
            edCls.getMethod("apply").invoke(ed);
            lastSaved = sig;
        } catch (Throwable ignored) {
        }
    }

    private static void logCfg() {
        String cur = cfgSrc + " speed=" + speedOn + " smart=" + smartOn;
        if (cur.equals(lastCfgLog)) return;
        lastCfgLog = cur;
        emit("cfg: " + cur);
    }

    private static void loadCfg() {
        Object app = appCtx();

        if (loadFromXsp()) {
            cfgOk = true;
            cfgSrc = "xsp";
            saveCache(app);
            logCfg();
            return;
        }
        if (app != null && loadFromProvider(app)) {
            cfgOk = true;
            cfgSrc = "provider";
            saveCache(app);
            logCfg();
            return;
        }

        cfgOk = false;
        if (loadFromCache(app)) {
            cfgSrc = "cache";
        } else {
            cfgSrc = "default";
        }
        // Application 还没 attach 时不要退避 60 秒，1.5 秒后重试，
        // 否则界面刚关掉加速，目标应用在这段时间里仍会按默认值加速
        if (app == null) cfgAt = nowMs() - CFG_TTL_MS + 1500L;
        logCfg();
    }

    /**
     * D2：配置只在后台线程读。
     * 原来 loadCfg() 是在 Handler.postDelayed 的 beforeHookedMethod 里同步跑的，
     * provider 被 ROM 冻结 / 应用休眠时会卡住 Binder 调用，
     * 直接拖着目标 App 主线程一起等 —— 低端机上就是 ANR。
     */
    private static void kickCfg() {
        cfgAt = nowMs();
        if (!CFG_LOADING.compareAndSet(false, true)) return;
        Thread t = new Thread(new Runnable() {
            public void run() {
                try {
                    loadCfg();
                } catch (Throwable ignored) {
                } finally {
                    CFG_LOADING.set(false);
                }
            }
        });
        t.setDaemon(true);
        t.setName("fasttick-cfg");
        t.start();
    }

    private static boolean speedEnabled() {
        long now = nowMs();
        if (now - cfgAt >= (cfgOk ? CFG_TTL_MS : CFG_RETRY_MS)) kickCfg();
        return speedOn;
    }

    /**
     * 智能调速核心：按目标时长决定倍率。
     */
    private static float rateFor(long v) {
        if (!smartOn) {
            if (v < minMs) return 1.0f;
            // 固定档也要过 clamp：否则低端机在固定模式下仍是满倍率，
            // 和智能档「低端机降档」的行为对不上
            return clamp(gameMode ? DIV_GAME : DIV_APP);
        }
        long floor = gameMode ? SMART_FLOOR_GAME : SMART_FLOOR_APP;
        if (v < floor) return 1.0f;

        float r;
        if (gameMode) {
            if (v < 8000L) r = 1.5f;
            else if (v < 20000L) r = 2.0f;
            else r = 2.5f;
        } else {
            if (v < 2500L) r = 1.5f;
            else if (v < 6000L) r = 2.0f;
            else if (v < 15000L) r = 2.5f;
            else r = 3.0f;
        }
        r *= perfFactor;
        if (nowMs() < burstUntil) r *= 0.7f;
        return clamp(r);
    }

    /**
     * 倍率收敛。下限跟着 perfFactor 走：
     * 原来固定 1.3 会把低端机的 1.5 x 0.7 = 1.05 又抬回 1.3，
     * 等于低端机档位形同虚设。
     */
    private static float clamp(float r) {
        float lo = Math.max(MIN_EFFECTIVE, SPEED_MIN * perfFactor);
        if (r < lo) r = lo;
        if (r > SPEED_MAX) r = SPEED_MAX;
        return r;
    }

    private static float playerSpeed() {
        if (!smartOn) {
            // 固定模式也要分游戏档，否则游戏进程里的播放器同样被拉到 3×
            float s = (gameMode ? DIV_GAME : SPEED) * perfFactor;
            if (nowMs() < burstUntil) s *= 0.8f;
            return clamp(s);
        }
        float s = SPEED * perfFactor;
        if (nowMs() < burstUntil) s *= 0.8f;
        return clamp(s);
    }

    private static final java.util.concurrent.ConcurrentHashMap<Object, long[]> LOOP =
            new java.util.concurrent.ConcurrentHashMap<Object, long[]>();
    /** 倒计时 tick 间隔一般 1000ms，窗口必须能容下一次执行耗时 + 一点抖动 */
    private static final long LOOP_WIN = 5000L;
    /** 第 2 次同参重复就认：5 秒开屏等不到第 3 次 */
    private static final int LOOP_HIT = 2;
    private static final long LOOP_MIN_MS = 500L;
    /** 短 tick 的循环倍率：广告倒计时的主战场 */
    private static final float APP_TICK = 2.5f;
    private static final float GAME_TICK = 2.0f;

    /**
     * 循环识别的 key。
     *
     * v6 直接用 Method 当 key，问题是全 App 的 postDelayed 都是同一个
     * Handler.postDelayed 方法对象 —— 消息轮询和广告倒计时会混成一条循环，
     * 界面上"看起来在加速"，实际把不相干的轮询也一起拉快了。
     * 现在短 tick 改成按调用点（类名#方法名）分组，两类业务各算各的。
     */
    private static Object keyFor(Member m, long v) {
        if (v > TICK_MAX_MS) return m;
        String c = caller();
        return c.length() == 0 ? (Object) m : (Object) c;
    }

    private static String caller() {
        try {
            StackTraceElement[] st = new Throwable().getStackTrace();
            for (int i = 2; i < st.length && i < 14; i++) {
                String c = st[i].getClassName();
                if (c == null) continue;
                if (c.startsWith("android.") || c.startsWith("java.")
                        || c.startsWith("com.android.") || c.startsWith("androidx.")
                        || c.startsWith("kotlin.") || c.startsWith("kotlinx.")
                        // 自己这几层必须跳过，否则每个短 tick 都会算到 PlayerScan#scale 头上，
                        // 等于又回到"全 App 共用一条循环"
                        || c.startsWith("com.adspeed.hook") || c.startsWith("nn.ecpm")
                        || c.startsWith("de.robv.")) continue;
                return c + "#" + st[i].getMethodName();
            }
        } catch (Throwable ignored) {
        }
        return "";
    }

    private static float loopRate(Object key, long v) {
        if (key == null || v < LOOP_MIN_MS) return 1.0f;
        long now = nowMs();
        long[] st = LOOP.get(key);
        if (st == null) {
            if (LOOP.size() > 96) LOOP.clear();
            st = new long[]{now, 1L, v, 100L};
            LOOP.put(key, st);
            return 1.0f;
        }
        if (now - st[0] < 20L) return st[3] / 100.0f;

        boolean same = Math.abs(v - st[2]) <= Math.max(50L, st[2] / 5L);
        if (now - st[0] <= LOOP_WIN && same) {
            st[1]++;
        } else {
            st[1] = 1L;
            st[2] = v;
        }
        st[0] = now;

        float r = 1.0f;
        if (st[1] >= LOOP_HIT) {
            // 短 tick 单独给档：rateFor(v*8) 对 600ms 算出 4800ms 只到 2.0×，
            // 而广告倒计时该按"循环"处理，直接给到 2.5×
            if (v <= TICK_MAX_MS) {
                r = (gameMode ? GAME_TICK : APP_TICK) * perfFactor;
                if (nowMs() < burstUntil) r *= 0.7f;
                r = clamp(r);
            } else {
                r = rateFor(v * 8L);
            }
        }
        st[3] = (long) (r * 100.0f);
        return r;
    }

    private static void tick() {
        long now = nowMs();
        if (now - burstWin > 1000L) {
            burstWin = now;
            BURST.set(0);
        }
        if (BURST.incrementAndGet() > BURST_LIMIT) burstUntil = now + BURST_HOLD_MS;
    }

    private static boolean warm() {
        long st = procStart;
        if (st == 0L) return true;
        return nowMs() - st >= WARMUP_MS;
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam p) {
        if (p == null || p.classLoader == null || p.packageName == null) return;
        String pkg = p.packageName;
        if (blocked(pkg)) return;
        if (isSystemProcess(p)) return;
        if (!INSTALLED.compareAndSet(false, true)) return;

        int cat = -1;
        try {
            if (p.appInfo != null) {
                java.lang.reflect.Field f = p.appInfo.getClass().getField("category");
                cat = f.getInt(p.appInfo);
            }
        } catch (Throwable ignored) {
        }
        if (cat == 2) {
            gameMode = true;
            minMs = MIN_MS_GAME;
        } else if (looksLikeGame(p)) {
            // Android 8 以下没有 ApplicationInfo.category，
            // 很多游戏在 8+ 也没标 CATEGORY_GAME。用引擎 so 兜一层，
            // 否则游戏会被当普通 App 处理（≥800ms ÷3），UI 状态机容易被打断。
            gameMode = true;
            minMs = MIN_MS_GAME;
        }

        try {
            int cpus = Runtime.getRuntime().availableProcessors();
            // 低端机降档，但不要降到看不出加速：0.8 档在 1.5× 上还剩 1.2×
            if (cpus <= 2) perfFactor = 0.8f;
            else if (cpus <= 4) perfFactor = 0.9f;
            else perfFactor = 1.0f;
        } catch (Throwable ignored) {
        }
        procStart = nowMs();

        ClassLoader cl = p.classLoader;

        // 先挂 Context，配置通道从第一条 hook 起就能用
        hookContext(cl);

        hookTimerLike(cl);
        if (!gameMode) {
            hookAnimator(cl);
            hookStart(cl);
        }
        hookPlayers(cl);
        hookScan(cl);

        // 冷启动就把配置读一次，别等第一条延时
        kickCfg();

        emit("FastTick v7: installed in " + pkg + " ["
                + (gameMode ? "game" : "app") + " smart=" + smartOn
                + " cpu=" + Runtime.getRuntime().availableProcessors()
                + " factor=" + perfFactor
                + " api=" + SDK + " abi=" + abi() + " rom=" + rom()
                + "]");
    }

    /**
     * 游戏识别兜底。
     * handleLoadPackage 触发时游戏引擎的 so 还没 dlopen，/proc/self/maps 里是看不到的，
     * 所以先看 APK 装好的 nativeLibraryDir（安装时就解压好了），再退回 maps。
     */
    private static boolean looksLikeGame(XC_LoadPackage.LoadPackageParam p) {
        try {
            if (p.appInfo != null) {
                Object d = p.appInfo.getClass().getField("nativeLibraryDir").get(p.appInfo);
                if (d instanceof String) {
                    String[] fs = new java.io.File((String) d).list();
                    if (fs != null) {
                        for (String f : fs) {
                            if (isGameLib(f)) return true;
                        }
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        java.io.BufferedReader r = null;
        try {
            r = new java.io.BufferedReader(new java.io.FileReader("/proc/self/maps"));
            String line;
            int n = 0;
            while ((line = r.readLine()) != null && n++ < 4000) {
                if (isGameLib(line)) return true;
            }
        } catch (Throwable ignored) {
        } finally {
            if (r != null) {
                try {
                    r.close();
                } catch (Throwable ignored) {
                }
            }
        }
        return false;
    }

    private static boolean isGameLib(String s) {
        if (s == null) return false;
        // 只认引擎本体，别把普通 App 里的 libflutter / libmedia 误判成游戏
        return s.indexOf("libunity") >= 0 || s.indexOf("libil2cpp") >= 0
                || s.indexOf("libcocos") >= 0 || s.indexOf("libUE4") >= 0
                || s.indexOf("libmonobdwgc") >= 0 || s.indexOf("libgodot") >= 0;
    }

    // ---------- 1. 计时器 ----------

    /**
     * 投递链去重（R1 的统一版）。
     *
     * Handler 的投递是一条链：postDelayed → sendMessageDelayed → sendMessageAtTime，
     * 每一步都会被 hook 到。要是每层都缩一次，5 秒会被缩成 1 秒多。
     * 这里用线程内深度：只有最外层那次调用真正缩放，内层转发一律放行。
     * 以前用 0/1 标志，只要有一条路径没走 after（ROM 改写实现 / 异常栈），
     * 标志就会残留，之后所有延时都被放过 —— 加速静默失效。深度计数不会。
     */
    private static boolean enterForward() {
        try {
            int[] n = NEST.get();
            boolean outer = n[0] == 0;
            n[0]++;
            return outer;
        } catch (Throwable t) {
            return false;
        }
    }

    private static void leaveForward() {
        try {
            int[] n = NEST.get();
            if (n[0] > 0) n[0]--;
        } catch (Throwable ignored) {
        }
    }

    private static void hookTimerLike(ClassLoader cl) {
        try {
            Class<?> h = XposedHelpers.findClass("android.os.Handler", cl);

            // 相对延时：postDelayed / sendEmptyMessageDelayed / sendMessageDelayed
            String[] rel = {"postDelayed", "sendEmptyMessageDelayed", "sendMessageDelayed"};
            for (String mn : rel) {
                XposedBridge.hookAllMethods(h, mn, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        if (enterForward()) scale(param, MAX_MS);
                    }

                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        leaveForward();
                    }
                });
            }

            // E4：倒计时为了对齐秒边界，常用绝对时间投递（postAtTime / sendMessageAtTime）。
            // 这类调用以前完全漏掉，现在按「绝对时间 - 当前 uptime」换算成延时再缩。
            String[] abs = {"postAtTime", "sendMessageAtTime"};
            for (String mn : abs) {
                XposedBridge.hookAllMethods(h, mn, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        if (enterForward()) scaleAtTime(param);
                    }

                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        leaveForward();
                    }
                });
            }
        } catch (Throwable t) {
            XposedBridge.log("FastTick v7: Handler fail " + t);
        }

        try {
            Class<?> tm = XposedHelpers.findClass("java.util.Timer", cl);
            String[] mns = {"schedule", "scheduleAtFixedRate"};
            for (String mn : mns) {
                XposedBridge.hookAllMethods(tm, mn, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        scale(param, MAX_MS);
                    }
                });
            }
        } catch (Throwable t) {
            XposedBridge.log("FastTick v7: Timer fail " + t);
        }

        try {
            Class<?> cdt = XposedHelpers.findClass("android.os.CountDownTimer", cl);
            XposedBridge.hookAllConstructors(cdt, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    scaleCdt(param);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("FastTick v7: CountDownTimer fail " + t);
        }

        hookScheduler(cl);
    }

    /** android.os.SystemClock.uptimeMillis 只查一次 */
    private static volatile Method mUptime = null;

    private static long uptime() {
        try {
            Method m = mUptime;
            if (m == null) {
                m = Class.forName("android.os.SystemClock").getMethod("uptimeMillis");
                mUptime = m;
            }
            Object v = m.invoke(null);
            return v instanceof Long ? ((Long) v).longValue() : -1L;
        } catch (Throwable t) {
            return -1L;
        }
    }

    /**
     * 绝对时间投递：最后一个 long 参数就是目标 uptime。
     * 只在这个时间点确实在未来、且落进正常区间时才改，改完保持「距离现在多少毫秒」的比例。
     */
    private static void scaleAtTime(XC_MethodHook.MethodHookParam param) {
        try {
            if (GUARD || !warm() || !speedEnabled()) return;
            Object[] a = param.args;
            if (a == null || a.length < 2) return;
            int idx = -1;
            for (int i = a.length - 1; i >= 1; i--) {
                if (a[i] instanceof Long) {
                    idx = i;
                    break;
                }
            }
            if (idx < 0) return;
            long when = ((Long) a[idx]).longValue();
            long now = uptime();
            if (now <= 0L || when <= now) return;
            long v = when - now;
            if (v < minMs || v > MAX_MS) return;
            float r = rateFor(v);
            if (v <= TICK_MAX_MS && v >= (gameMode ? 1000L : MIN_MS_APP)) {
                float lr = loopRate(keyFor(param.method, v), v);
                if (lr > r) r = lr;
            } else if (r < MIN_EFFECTIVE) {
                r = loopRate(keyFor(param.method, v), v);
            }
            if (r < MIN_EFFECTIVE) return;
            long nv = (long) (v / r);
            if (nv < 50L || nv >= v) return;
            a[idx] = Long.valueOf(now + nv);
            tick();
            N_SCALE.incrementAndGet();
            N_SAVE_MS.addAndGet(v - nv);
            statReport();
        } catch (Throwable t) {
            fault("atTime");
        }
    }

    /**
     * E3：ScheduledExecutorService。
     * 新版广告 SDK 的倒计时组件大量改用 schedule / scheduleAtFixedRate，
     * 这类延时一个都不经过 Handler，v6 完全没覆盖到。
     *
     * 只缩第 2 个参数（延时）。scheduleAtFixedRate 的周期不缩：
     * 缩周期等于把定时任务变成高频轮询，耗电和请求频率都会翻倍。
     */
    private static void hookScheduler(ClassLoader cl) {
        try {
            Class<?> c = XposedHelpers.findClass(
                    "java.util.concurrent.ScheduledThreadPoolExecutor", cl);
            XC_MethodHook cb = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    scaleUnit(param);
                }
            };
            XposedBridge.hookAllMethods(c, "schedule", cb);
            XposedBridge.hookAllMethods(c, "scheduleAtFixedRate", cb);
            XposedBridge.hookAllMethods(c, "scheduleWithFixedDelay", cb);
        } catch (Throwable t) {
            // 关掉核心库 / 替换过 Executors 的 ROM 上找不到，正常
        }
    }

    private static long toMs(long v, String u) {
        try {
            if ("NANOSECONDS".equals(u)) return v / 1000000L;
            if ("MICROSECONDS".equals(u)) return v / 1000L;
            if ("MILLISECONDS".equals(u)) return v;
            if ("SECONDS".equals(u)) return v > 900000L ? -1L : v * 1000L;
            if ("MINUTES".equals(u)) return v > 15000L ? -1L : v * 60000L;
            if ("HOURS".equals(u)) return v > 250L ? -1L : v * 3600000L;
            if ("DAYS".equals(u)) return v > 10L ? -1L : v * 86400000L;
        } catch (Throwable ignored) {
        }
        return -1L;
    }

    private static long fromMs(long ms, String u) {
        if ("NANOSECONDS".equals(u)) return ms * 1000000L;
        if ("MICROSECONDS".equals(u)) return ms * 1000L;
        if ("MILLISECONDS".equals(u)) return ms;
        if ("SECONDS".equals(u)) return ms / 1000L;
        if ("MINUTES".equals(u)) return ms / 60000L;
        if ("HOURS".equals(u)) return ms / 3600000L;
        if ("DAYS".equals(u)) return ms / 86400000L;
        return -1L;
    }

    private static void scaleUnit(XC_MethodHook.MethodHookParam param) {
        try {
            if (GUARD || !warm() || !speedEnabled()) return;
            Object[] a = param.args;
            if (a == null || a.length < 3) return;
            if (!(a[1] instanceof Long) || a[2] == null) return;
            long v = ((Long) a[1]).longValue();
            if (v <= 0L) return;
            String u = String.valueOf(a[2]);
            long ms = toMs(v, u);
            if (ms < minMs || ms > MAX_MS) return;
            float r = rateFor(ms);
            if (ms <= TICK_MAX_MS && ms >= (gameMode ? 1000L : MIN_MS_APP)) {
                float lr = loopRate(keyFor(param.method, ms), ms);
                if (lr > r) r = lr;
            } else if (r < MIN_EFFECTIVE) {
                r = loopRate(keyFor(param.method, ms), ms);
            }
            if (r < MIN_EFFECTIVE) return;
            long nms = (long) (ms / r);
            if (nms < 50L) return;
            long nv = fromMs(nms, u);
            if (nv < 1L || nv >= v) return;
            a[1] = Long.valueOf(nv);
            tick();
            N_SCALE.incrementAndGet();
            N_SAVE_MS.addAndGet(ms - nms);
            statReport();
        } catch (Throwable t) {
            fault("sched");
        }
    }

    private static void scale(XC_MethodHook.MethodHookParam param, long max) {
        try {
            if (GUARD || !warm() || !speedEnabled()) return;
            Object[] a = param.args;
            if (a == null) return;
            boolean hit = false;
            long saved = 0L;
            // 游戏档也认 1 秒循环（游戏内激励视频的倒计时就是这个步长），
            // 只是倍率低一档，走 GAME_TICK
            long tickFloor = gameMode ? 1000L : MIN_MS_APP;
            for (int i = 0; i < a.length; i++) {
                Object o = a[i];
                if (o instanceof Long) {
                    long v = ((Long) o).longValue();
                    if (v <= 0L || v > max) continue;
                    float r = rateFor(v);
                    // 短 tick 不论 rateFor 给没给，都再过一遍循环识别：
                    // 单次 1000ms 拿 1.5×，同参重复第 2 次起升到 2.5×。
                    // 这条是「广告倒计时到底有没有效果」的关键分支。
                    if (v <= TICK_MAX_MS && v >= tickFloor) {
                        float lr = loopRate(keyFor(param.method, v), v);
                        if (lr > r) r = lr;
                    } else if (r < MIN_EFFECTIVE) {
                        r = loopRate(keyFor(param.method, v), v);
                    }
                    if (r < MIN_EFFECTIVE) continue;
                    long nv = (long) (v / r);
                    if (nv >= 50L && nv < v) {
                        a[i] = Long.valueOf(nv);
                        saved += v - nv;
                        hit = true;
                    }
                }
            }
            if (hit) {
                tick();
                N_SCALE.incrementAndGet();
                if (saved > 0L) N_SAVE_MS.addAndGet(saved);
                statReport();
            }
        } catch (Throwable t) {
            fault("scale");
        }
    }

    /** R2：只缩 CountDownTimer 的总时长，interval 保持原样 */
    private static void scaleCdt(XC_MethodHook.MethodHookParam param) {
        try {
            if (GUARD || !warm() || !speedEnabled()) return;
            Object[] a = param.args;
            if (a == null || a.length < 2) return;
            if (!(a[0] instanceof Long)) return;
            long total = ((Long) a[0]).longValue();
            if (total <= 0L || total > 3600000L) return;
            float r = rateFor(total);
            // 总时长 < 1000ms 的极短倒计时不碰；1000ms 整的那种直接按 tick 档
            if (total <= TICK_MAX_MS && total >= (gameMode ? 1000L : MIN_MS_APP)) {
                float lr = loopRate(keyFor(param.method, total), total);
                if (lr > r) r = lr;
            }
            if (r < MIN_EFFECTIVE) return;
            long nv = Math.max(1L, (long) (total / r));
            a[0] = Long.valueOf(nv);
            if (nv < total) {
                N_SCALE.incrementAndGet();
                N_SAVE_MS.addAndGet(total - nv);
            }
            tick();
            statReport();
        } catch (Throwable t) {
            fault("cdt");
        }
    }

    // ---------- 1b. 属性动画时长 ----------

    private static void hookAnimator(ClassLoader cl) {
        // ValueAnimator 是 API 11，minSdk 21 起一定存在；仍包一层 try
        try {
            Class<?> va = XposedHelpers.findClass("android.animation.ValueAnimator", cl);
            XposedBridge.hookAllMethods(va, "setDuration", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    scaleAnim(param);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("FastTick v7: Animator fail " + t);
        }
    }

    private static void scaleAnim(XC_MethodHook.MethodHookParam param) {
        try {
            if (GUARD || gameMode || !speedEnabled() || !warm()) return;
            Object[] a = param.args;
            if (a == null || a.length < 1 || !(a[0] instanceof Long)) return;
            long v = ((Long) a[0]).longValue();
            if (v < ANIM_MIN_MS || v > 3600000L) return;
            float r = rateFor(v);
            if (r < MIN_EFFECTIVE) return;
            a[0] = Long.valueOf((long) (v / r));
        } catch (Throwable t) {
            fault("anim");
        }
    }

    // ---------- 2. 播放器倍速 ----------

    private static void hookPlayers(ClassLoader cl) {
        // PlaybackParams 是 API 23；低版本上方法不存在，
        // hookAllMethods 找不到方法不会抛异常，这里再加一层判断省一次查找
        if (SDK == 0 || SDK >= 23) {
            try {
                Class<?> mp = XposedHelpers.findClass("android.media.MediaPlayer", cl);
                XposedBridge.hookAllMethods(mp, "setPlaybackParams", new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        forceParams(param);
                    }
                });
            } catch (Throwable t) {
                XposedBridge.log("FastTick v7: MediaPlayer params fail " + t);
            }
        }

        try {
            Class<?> mp = XposedHelpers.findClass("android.media.MediaPlayer", cl);
            XposedBridge.hookAllMethods(mp, "setSpeed", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        if (GUARD || !warm() || !speedEnabled()) return;
                        Object[] a = param.args;
                        if (a == null || a.length != 1) return;
                        float sp = playerSpeed();
                        if (a[0] instanceof Float) a[0] = Float.valueOf(sp);
                        else if (a[0] instanceof Double) a[0] = Double.valueOf((double) sp);
                        N_SPEED.incrementAndGet();
                    } catch (Throwable t) {
                        fault("mp-setSpeed");
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private static void forceParams(XC_MethodHook.MethodHookParam param) {
        try {
            if (GUARD || !warm() || !speedEnabled()) return;
            Object[] a = param.args;
            if (a == null || a.length < 1 || a[0] == null) return;
            Object cur = a[0];
            float sp = playerSpeed();
            Object r = null;
            try {
                r = XposedHelpers.callMethod(cur, "setSpeed", Float.valueOf(sp));
            } catch (Throwable ignored) {
            }
            if (r != null) {
                a[0] = r;
                N_SPEED.incrementAndGet();
                return;
            }
            // PlaybackParams 没有 (float) 构造器，只能无参构造再 setSpeed
            try {
                Object np = XposedHelpers.newInstance(cur.getClass());
                Object r2 = XposedHelpers.callMethod(np, "setSpeed", Float.valueOf(sp));
                if (r2 != null) {
                    a[0] = r2;
                    N_SPEED.incrementAndGet();
                }
            } catch (Throwable ignored) {
            }
        } catch (Throwable t) {
            fault("params");
        }
    }

    /**
     * D5：播放器起播时补一次倍速。
     * 有些广告 SDK 从不调 setSpeed，只在 start 之后靠默认 1.0 播完，
     * 光 hook setSpeed 对它们无效。这里在 start|play 返回后补一刀，受总开关控制。
     */
    private static void hookStart(ClassLoader cl) {
        try {
            Class<?> mp = XposedHelpers.findClass("android.media.MediaPlayer", cl);
            XposedBridge.hookAllMethods(mp, "start", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    applyMpSpeed(param.thisObject, cl);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("FastTick v7: MediaPlayer.start fail " + t);
        }

        String[] players = {
                "tv.danmaku.ijk.media.player.IjkMediaPlayer",
                "com.google.android.exoplayer2.ExoPlayerImpl",
                "com.google.android.exoplayer2.SimpleExoPlayer",
                "androidx.media3.exoplayer.ExoPlayerImpl",
                "com.aliyun.player.AliPlayer",
                "com.tencent.rtmp.TXVodPlayer",
                "com.tencent.liteav.TXVodPlayer"
        };
        for (final String cn : players) {
            try {
                Class<?> c = XposedHelpers.findClass(cn, cl);
                XC_MethodHook cb = new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        applyPlayerSpeed(param.thisObject, cl);
                    }
                };
                // 两个都挂：Ijk 用 start，ExoPlayer 用 play，Ali/TXVod 用 start
                XposedBridge.hookAllMethods(c, "start", cb);
                XposedBridge.hookAllMethods(c, "play", cb);
                XposedBridge.hookAllMethods(c, "startPlay", cb);
            } catch (Throwable ignored) {
                // 类不在这个 App 里，正常
            }
        }
    }

    /** PlaybackParams 的 Class 只查一次，start 在广告里是高频调用 */
    private static volatile Class<?> sPpCls = null;

    private static void applyMpSpeed(Object mp, ClassLoader cl) {
        try {
            if (GUARD || mp == null || !speedEnabled() || !warm()) return;
            if (SDK != 0 && SDK < 23) return;
            Class<?> pp = sPpCls;
            if (pp == null) {
                pp = XposedHelpers.findClass("android.media.PlaybackParams", cl);
                sPpCls = pp;
            }
            Object p = XposedHelpers.newInstance(pp);
            Object r = XposedHelpers.callMethod(p, "setSpeed", Float.valueOf(playerSpeed()));
            XposedHelpers.callMethod(mp, "setPlaybackParams", r != null ? r : p);
            N_SPEED.incrementAndGet();
        } catch (Throwable t) {
            fault("mp-speed");
        }
    }

    /** 防重入：ExoPlayer 的 setPlaybackSpeed 会回调监听器，监听器里再 play 就成环了 */
    private static final ThreadLocal<int[]> APPLYING = new ThreadLocal<int[]>() {
        @Override
        protected int[] initialValue() {
            return new int[1];
        }
    };

    private static void applyPlayerSpeed(Object player, ClassLoader cl) {
        int[] re = APPLYING.get();
        if (re[0] == 1) return;
        re[0] = 1;
        try {
            if (GUARD || player == null || !speedEnabled() || !warm()) return;
            float sp = playerSpeed();
            // 逐个试：不同播放器的方法名不一样，谁先成功算谁
            if (callOne(player, "setPlaybackSpeed", sp)
                    || callOne(player, "setSpeed", sp)
                    || callOne(player, "setRate", sp)
                    || setParams(player, cl, sp)) {
                N_SPEED.incrementAndGet();
            }
        } catch (Throwable t) {
            fault("player");
        } finally {
            re[0] = 0;
        }
    }

    private static boolean callOne(Object o, String m, float v) {
        try {
            XposedHelpers.callMethod(o, m, Float.valueOf(v));
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean setParams(Object player, ClassLoader cl, float sp) {
        try {
            Class<?> pp = XposedHelpers.findClass(
                    "androidx.media3.common.PlaybackParameters", cl);
            Object p = XposedHelpers.newInstance(pp, Float.valueOf(sp));
            XposedHelpers.callMethod(player, "setPlaybackParameters", p);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    // ---------- 3. 动态扫描 ----------

    private static void hookScan(ClassLoader cl) {
        try {
            XposedBridge.hookAllMethods(ClassLoader.class, "loadClass", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        Object[] a = param.args;
                        if (a == null || a.length < 1) return;
                        Object n = a[0];
                        if (!(n instanceof String)) return;
                        // D4：先看名字。原来不管什么类都进 scan()，
                        // 一个 App 冷启动几千次 loadClass，全走一遍反射
                        if (!maybe((String) n)) return;
                        Object r = param.getResult();
                        if (r instanceof Class) scan((Class<?>) r);
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("FastTick v7: scanner fail " + t);
        }
    }

    private static boolean maybe(String n) {
        if (n == null || n.length() < 6) return false;
        for (String s : SKIP_PREFIX) {
            if (n.startsWith(s)) return false;
        }
        for (String k : NAME_KEYS) {
            if (containsIC(n, k)) return true;
        }
        return false;
    }

    private static void scan(Class<?> c) {
        if (HOOKED.get() >= HOOK_CAP) return;
        int[] d = DEPTH.get();
        if (d[0] >= MAX_DEPTH) return;
        d[0]++;
        try {
            doScan(c);
        } catch (Throwable ignored) {
        } finally {
            d[0]--;
        }
    }

    private static void doScan(Class<?> c) {
        String n = c.getName();
        if (n == null || !maybe(n)) return;
        if (DONE.size() > 1500) DONE.clear();
        if (!DONE.add(n)) return;

        Method[] ms;
        try {
            ms = c.getMethods();
        } catch (Throwable t) {
            DONE.remove(n);
            return;
        }

        for (Method m : ms) {
            try {
                if (HOOKED.get() >= HOOK_CAP) return;
                Class<?>[] ps = m.getParameterTypes();
                if (ps.length != 1) continue;
                if (Modifier.isAbstract(m.getModifiers())) continue;
                String mn = m.getName();

                boolean isSpeed = (ps[0] == float.class || ps[0] == double.class)
                        && in(SPEED_M, mn);
                boolean isParams = "setplaybackparams".equalsIgnoreCase(mn)
                        || "setplaybackparameters".equalsIgnoreCase(mn);

                if (isSpeed) {
                    hookSpeed(m, ps[0] == double.class, n);
                } else if (isParams) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            forceParams(param);
                        }
                    });
                    HOOKED.incrementAndGet();
                }
            } catch (Throwable ignored) {
            }
        }
    }

    private static void hookSpeed(Method m, final boolean dbl, String cn) {
        try {
            XposedBridge.hookMethod(m, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        if (GUARD || !warm() || !speedEnabled()) return;
                        if (param.args != null && param.args.length == 1) {
                            float sp = playerSpeed();
                            param.args[0] = dbl ? Double.valueOf((double) sp) : Float.valueOf(sp);
                            N_SPEED.incrementAndGet();
                        }
                    } catch (Throwable t) {
                        fault("speed");
                    }
                }
            });
            HOOKED.incrementAndGet();
        } catch (Throwable ignored) {
        }
    }

    private static boolean containsIC(String src, String key) {
        int last = src.length() - key.length();
        for (int i = 0; i <= last; i++) {
            if (src.regionMatches(true, i, key, 0, key.length())) return true;
        }
        return false;
    }

    private static boolean in(String[] arr, String s) {
        for (String a : arr) {
            if (a.equalsIgnoreCase(s)) return true;
        }
        return false;
    }
}
