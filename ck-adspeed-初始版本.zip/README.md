# CKAdSpeed

> 基于 LSPosed 的 Android **延时投递 / 播放器倍速** hook 框架，附带一层广告 SDK 方法观测与改写工具。

> [!WARNING]
> **使用前必读**
>
> - 本项目的 eCPM 改写能力**提高不了服务端结算金额**。把它当收益工具是误解；用于生产环境属于违反广告平台条款的无效流量行为。
> - 仅供学习研究。下载、编译、安装即视为你已阅读并同意 [DISCLAIMER.md](DISCLAIMER.md)。
> - 代码许可见 [LICENSE](LICENSE)（GPL-3.0）；`smali/` 目录的归属另见 [NOTICE.md](NOTICE.md)，不在 GPL 覆盖范围内。
> - 作者不提供任何担保，不对设备损坏、账号封禁、收益损失或法律纠纷承担责任。

---

<p align="center">
  <img src="docs/screenshot.jpg" alt="界面预览" width="460">
  <br>
  <sub>界面预览（<a href="docs/preview.html">可交互 HTML 版</a>）</sub>
</p>

## 这个仓库是什么

一个可编译、可复现的 Xposed 模块工程。它不是"一键加速器"，而是一份**关于 Android 延时投递链路怎么被 hook、怎么不把宿主 App 搞坏**的完整实现。

三个入口，各自独立 try/catch，谁挂都不影响别人：

```
assets/xposed_init
├── com.adspeed.hook.PlayerScan   加速内核（本项目主体，完整 Java 源码）
├── nn.ecpm.EcpmHook              上游基线（smali，见 NOTICE.md）
└── nn.ecpm.EcpmPlus              eCPM 补充层（Java，本项目新增）
```

## 功能

**加速内核（`src-java/PlayerScan.java`）**

| 能力 | 覆盖 |
|---|---|
| 相对延时 | `Handler.postDelayed` / `sendEmptyMessageDelayed` / `sendMessageDelayed` |
| 绝对时间投递 | `Handler.postAtTime` / `sendMessageAtTime`（按 `SystemClock.uptimeMillis` 换算） |
| 定时器 | `java.util.Timer.schedule` / `scheduleAtFixedRate`、`android.os.CountDownTimer` |
| 线程池调度 | `ScheduledThreadPoolExecutor.schedule` / `scheduleAtFixedRate` / `scheduleWithFixedDelay` |
| 播放器倍速 | ExoPlayer / IjkPlayer / TXVodPlayer / AliPlayer / `MediaPlayer` 的 `setSpeed`、`setPlaybackSpeed`、`setPlaybackParameters`、`setRate` |

**智能档位**（按目标时长自动定倍率，短倒计时与界面动画不动）

```
1.2s → 1.5×    2.5s → 2×    6s → 2.5×    15s → 3×
短 tick（≤1.6s 循环）→ 普通 2.5× / 游戏 2.0×
低端机（≤4 核 或 内存 <2G）整体 ×0.8
```

**界面**（`src-ui/`）

- 纯 Java 构建布局，无 XML；edge-to-edge 全透明（状态栏、导航栏、手势条）
- 本机背景图最多 8 张，可点选切换、单张删除
- 加速页顶部「运行状态」：区分 `已注入，未见加速` 与 `加速中`，附 `缩时 N 次 / 省 N 秒 / 补速 N 次 / 当前倍率`
- 悬浮窗实时显示当前档位

## 技术要点

这几条是这个仓库真正值钱的地方，也是写的时候踩过的坑：

**1. 投递链只缩最外层**

`postDelayed` 内部会调 `sendMessageDelayed`，后者再调 `sendMessageAtTime`。三层都 hook 的话，一条 5 秒延时会被缩三次，实际变成 4.5× 以上，远超设计上限。
用**线程内深度计数**（`enterForward` / `leaveForward`）而不是 0/1 标志——旧实现只要有一条路径没走 `after`（ROM 改写实现、异常栈），标志就永久残留，之后所有延时被静默放过，表现为"模块突然不工作了"。

**2. 循环识别按「调用点」分组，不按方法**

`Handler.postDelayed` 在整个 App 里只有一个 `Method` 对象。用它做 key，消息轮询和广告倒计时会混进同一条统计，互相污染。
现在 key 是 `调用方类名#方法名`（从栈帧取），并额外排除 `android.*` / `java.*` / `kotlin.*` 等系统帧。

**3. `CountDownTimer` 只缩总时长，不缩 interval**

`CountDownTimer(total, interval)` 如果两个参数都缩，回调频率会翻倍——UI 每 100ms 刷一次变 40ms，卡顿且耗电。
同理 `scheduleAtFixedRate` 只缩首次延时，`period` 保持原值。

**4. 单位换算必须防溢出**

`TimeUnit` 六种单位换算到毫秒时，`nanos` / `micros` 的大数值会溢出成负数。溢出直接放弃这次改写（返回 `-1`），不要硬转。

**5. 熔断**

任何 hook 回调抛异常都计数，累计 120 次自动停用加速，所有回调直接放行，并写一条 `guard: 异常过多，已自动停用加速以保护目标应用`。
原则：**宁可没效果，也不能把宿主 App 拖崩。**

**6. 保护名单**

银行、券商、支付、密码管理器、输入法、企业 MDM、TalkBack、短信 / 拨号——这些进程一律不注入。在这些 App 里缩延时只有副作用。

## 目录

```
.
├── src-java/PlayerScan.java        加速内核，完整 Java（约 1700 行，含注释）
├── src-ui/nn/ecpm/                 界面 / 悬浮窗 / 日志接收 / eCPM 补充层
│   ├── MainActivity.java           主界面，纯代码构建
│   ├── FloatService.java           悬浮窗前台服务
│   ├── LogReceiver.java            日志与状态回传
│   ├── Diag.java                   统计行解析
│   └── EcpmPlus.java               eCPM 补充层
├── smali/                          上游基线（反编译产物，见 NOTICE.md）
├── assets/xposed_init              三行入口
├── lib/stub.jar                    Xposed API 编译桩（仅签名，不含实现）
├── build.sh                        热修：只换 classes7.dex
├── build_full.sh                   全量：内核 + 界面 + 清单 + 打包签名
├── build-kernel-only.sh            自包含：只编内核，不需要基线 APK
├── publish.sh                      一键建仓并推送（GitHub / Gitee）
├── PUBLISH.md                      从本地仓库到公开的完整步骤
├── docs/
│   ├── BUILD.md                    构建细节与产物结构
│   ├── ARCHITECTURE.md             模块分层与调用链
│   ├── REQUIREMENTS.md             设计约束（每次改动前对照）
│   ├── HISTORY.md                  v1 ~ v36 逐版开发记录（含踩坑）
│   ├── preview.html                界面可交互预览
│   └── screenshot.jpg              README 首图
├── .github/
│   ├── workflows/build.yml         CI：编译内核 + 界面 + 出 dex
│   ├── ISSUE_TEMPLATE/bug_report.yml
│   └── PULL_REQUEST_TEMPLATE.md
├── NOTICE.md                       第三方代码与授权状态
└── DISCLAIMER.md                   用途限制
```

## 构建

### 依赖

| 组件 | 版本 | 说明 |
|---|---|---|
| JDK | 8 ~ 17 | `javac` 用 `-source 8 -target 8` |
| Android Build-Tools | 34.0.0 | `d8` / `zipalign` / `apksigner` |
| Platform | android-34 | 编译界面层需要 `android.jar` |
| apktool | 2.9+ | 仅 `build_full.sh` 需要 |

```bash
export ANDROID_HOME=$HOME/Android/Sdk
export BT=$ANDROID_HOME/build-tools/34.0.0
export ANDROID_JAR=$ANDROID_HOME/platforms/android-34/android.jar
export APKTOOL=$HOME/apktool_2.9.3.jar
```

### 只编内核（自包含，clone 就能跑）

```bash
./build-kernel-only.sh
# 产物：build/kernel.jar、build/dex/classes.dex
```

这条路径不需要基线 APK，CI 跑的就是它。

### 完整打包（需要自备基线 APK）

```bash
KS_PASS='你的口令' ./build_full.sh baseline.apk out.apk ./release.keystore release
```

> `baseline.apk` 是上游发布的原始安装包，**本仓库不提供**（版权原因，见 `NOTICE.md`）。
> 没有它就只能编内核，打不出完整 APK——这是本仓库最大的构建限制，如实写在这里。

口令必须走环境变量，脚本里没有任何默认值。**不要把自己的 keystore 提交进仓库**

## 已知限制

- 服务端按真实播放时长结算的激励视频，客户端改不了到账金额
- Unity / UE / Cocos 用引擎自身计时器（`Time.deltaTime`、native scheduler）实现的倒计时
- WebView 内 JS 的 `setTimeout` / `countDown`（Chromium 定时器，不在 Java 层）
- 加固后把倒计时封进 native 的（`sleep` / `nanosleep` 在 so 里）
- 用「开始时间戳 + 当前时间」自己算剩余秒数的 SDK——只能靠播放器倍速那一路
- Android 5~7.1 三键导航栏无法做到纯透明

## 关于 eCPM 层

`EcpmPlus` 是对上游基线 `EcpmHook` 的补充：hook `ClassLoader.loadClass` 截获广告 SDK 类，按签名筛选 eCPM getter，并把配置热更新反射推回上游实例。

它的技术价值在于**观察各家 SDK 把 eCPM 暴露在哪一层**（getter / 字段 / BigDecimal / 带参方法）。它改变不了服务端结算，也不应该被用于制造无效流量——见 `DISCLAIMER.md`。

## 授权状态

- 本项目自研部分（`src-java/`、`src-ui/`、构建脚本、文档）：**GPL-3.0**
- `smali/`：上游 APK 反编译产物，**版权归原作者**，本仓库仅作研究基线收录，不适用上面的 GPL 授权。权利人如有异议，请开 issue，会立即移除该目录
- `lib/stub.jar`：自行生成的 API 桩，只有方法签名

细节见 `NOTICE.md`。

## 免责声明

见 `DISCLAIMER.md`。简单说：**仅供学习研究，使用后果自负**。

## 致谢

- [LSPosed](https://github.com/LSPosed/LSPosed) / [XposedBridge](https://github.com/rovo89/XposedBridge) —— hook 框架与 API 设计
- 上游模块作者 —— 提供了这个工程最初的起点
- 所有在 issue 里反馈过"加速没效果"的人 —— v36 的四个根因都是被这些反馈逼出来的
