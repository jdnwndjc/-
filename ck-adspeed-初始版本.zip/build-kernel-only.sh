#!/usr/bin/env bash
# 只编加速内核：不依赖基线 APK，clone 下来直接能跑。
#
#   ./build-kernel-only.sh
#
# 产物：
#   build/kernel.jar       可直接被其他工程引用
#   build/dex/classes.dex  可用 unzip 替换进 APK 的 classes7.dex（需设置 BT / ANDROID_JAR）
#
# 设了 BT 与 ANDROID_JAR 才出 dex，否则只出 jar —— 方便没有 Android SDK 的环境做语法/类型检查。
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="$ROOT/build"

rm -rf "$OUT"
mkdir -p "$OUT/classes" "$OUT/dex"

echo "[1/2] javac  src-java/PlayerScan.java"
javac -nowarn -source 8 -target 8 -encoding UTF-8 \
  -cp "$ROOT/lib/stub.jar" \
  -d "$OUT/classes" "$ROOT/src-java/PlayerScan.java"

jar cf "$OUT/kernel.jar" -C "$OUT/classes" .
echo "      -> $OUT/kernel.jar"

if [ -n "${BT:-}" ] && [ -n "${ANDROID_JAR:-}" ]; then
  echo "[2/2] d8  -> classes.dex"
  "$BT/d8" --min-api 21 \
    --lib "$ANDROID_JAR" \
    --classpath "$ROOT/lib/stub.jar" \
    --output "$OUT/dex" \
    $(find "$OUT/classes" -name '*.class')
  echo "      -> $OUT/dex/classes.dex"
else
  echo "[2/2] 跳过 d8（未设置 BT / ANDROID_JAR）"
fi

echo "done."
