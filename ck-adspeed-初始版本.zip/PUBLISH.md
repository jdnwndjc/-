# 发布手册

从零到公开，一共两条命令（前提：账号已注册、Gitee 已实名）。

---

## 一、GitHub

```bash
gh auth login          # 选 GitHub.com → HTTPS → Login with a web browser
cd ck-adspeed
./publish.sh github <你的用户名>
```

`publish.sh github` 做三件事：`gh repo create --public` 建仓、把 `origin` 指过去、推送 `main`。

不想用脚本也可以手打：

```bash
gh repo create ck-adspeed --public --source=. --remote=origin --push \
  --description "Android delay / playback-speed hook framework for LSPosed"
```

## 二、Gitee

Gitee 没有官方 CLI，**必须先网页建空仓**：

1. 打开 https://gitee.com/projects/new
2. 仓库名 `ck-adspeed`，选「开源」，**不要**勾「使用 Readme 初始化」（勾了会冲突）
3. 复制仓库地址，回来执行：

```bash
./publish.sh gitee <你的用户名>
```

脚本会加 `gitee` remote 并推送 `main`。

## 三、两边同步

```bash
git push origin main && git push gitee main
```

或者加个别名（`~/.gitconfig`）：

```ini
[alias]
    pushall = !git push origin main && git push gitee main
```

以后 `git pushall` 一条搞定。

## 四、发布 Release（可选，APK 不要进 git）

APK 已在 `.gitignore` 里。要挂下载就发 Release：

```bash
gh release create v3.6 /path/to/CK广告助手_v36.apk \
  --title "v3.6" \
  --notes "加速内核修正 + 运行状态回执。详见 docs/HISTORY.md"
```

> **想清楚再发**：源码公开已经足够说明技术。把带 eCPM 改写能力的 APK 挂到 Release，
> 等于把「工具」直接发给所有人，性质和开源代码不同。默认建议不挂。

## 五、完善仓库信息（网页操作，5 分钟）

- **About**：填 `Android · LSPosed · Xposed` 三个 topic，加上那句 description
- **Social preview**：上传 `docs/screenshot.jpg`
- **Issues**：已带 `bug_report.yml` 模板，不用额外配
- **Discussions**：可选
- **License**：GitHub 会自动识别 GPL-3.0，不用手动选

## 六、CI 徽章

推到 GitHub 后，把 README 顶部那行换成：

```markdown
[![build](https://github.com/<用户名>/ck-adspeed/actions/workflows/build.yml/badge.svg)](https://github.com/<用户名>/ck-adspeed/actions/workflows/build.yml)
```

第一次跑会拉 Android SDK，约 2~4 分钟。失败大概率是 `sdkmanager` 没装到 `platforms;android-34`，看日志里 `setup-android` 那步。

Gitee 的 GoGo 测试对 Android SDK 支持一般，不配也行。

## 七、常见错误

| 报错 | 原因 | 处理 |
|---|---|---|
| `gh: command not found` | 没装 gh | `sudo apt install gh` 或去 cli.github.com |
| `HTTP 403` | 账号没权限 / 组织限制 | 确认仓库名没被占用；组织仓要 `--public` 且有权限 |
| `remote origin already exists` | 之前加过 | `git remote set-url origin <新地址>` |
| `failed to push some refs` | 远端有初始 commit | `git pull --rebase origin main` 再推 |
| Gitee `Permission denied` | 用了 HTTPS 但没配凭据 | 用「私人令牌」当密码，或换 SSH |
| `Support for password authentication was removed` | GitHub 不再接受账号密码 | 用 `gh auth login` 或 PAT |

## 八、发出去之后

1. **别删 `.git`**，历史是项目信誉的一部分
2. 有人提 `smali/` 授权问题，按 `NOTICE.md` 的承诺处理——先删目录，再解释，不辩论
3. 收到「加速没效果」的 issue，先要状态行，别急着改代码
