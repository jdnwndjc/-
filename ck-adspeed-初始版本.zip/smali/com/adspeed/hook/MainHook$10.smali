.class Lcom/adspeed/hook/MainHook$10;
.super Lde/robv/android/xposed/XC_MethodHook;
.source "MainHook.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adspeed/hook/MainHook;->hookCountDownTimer(Ljava/lang/ClassLoader;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/adspeed/hook/MainHook;


# direct methods
.method constructor <init>(Lcom/adspeed/hook/MainHook;)V
    .locals 0
    .param p1, "this$0"    # Lcom/adspeed/hook/MainHook;

    .line 318
    iput-object p1, p0, Lcom/adspeed/hook/MainHook$10;->this$0:Lcom/adspeed/hook/MainHook;

    invoke-direct {p0}, Lde/robv/android/xposed/XC_MethodHook;-><init>()V

    return-void
.end method


# virtual methods
.method protected beforeHookedMethod(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V
    .locals 12
    .param p1, "param"    # Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;

    .line 322
    const-string v0, "mCountdownInterval"

    const-string v1, "mMillisInFuture"

    :try_start_0
    iget-object v2, p1, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->thisObject:Ljava/lang/Object;

    invoke-static {v2, v1}, Lde/robv/android/xposed/XposedHelpers;->getLongField(Ljava/lang/Object;Ljava/lang/String;)J

    move-result-wide v2

    .line 324
    .local v2, "total":J
    const-wide/16 v4, 0x1f40

    cmp-long v6, v2, v4

    if-ltz v6, :cond_3

    const-wide/32 v4, 0x2bf20

    cmp-long v6, v2, v4

    if-lez v6, :cond_0

    goto :goto_0

    .line 327
    :cond_0
    iget-object v4, p1, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->thisObject:Ljava/lang/Object;

    invoke-static {v4, v0}, Lde/robv/android/xposed/XposedHelpers;->getLongField(Ljava/lang/Object;Ljava/lang/String;)J

    move-result-wide v4

    .line 329
    .local v4, "interval":J
    const-wide/16 v6, 0x0

    cmp-long v8, v4, v6

    if-gtz v8, :cond_1

    .line 330
    const-wide/16 v4, 0x3e8

    .line 333
    :cond_1
    long-to-float v6, v4

    const/high16 v7, 0x40400000    # 3.0f

    div-float/2addr v6, v7

    float-to-long v8, v6

    .line 334
    .local v8, "newInterval":J
    const-wide/16 v10, 0x1

    cmp-long v6, v8, v10

    if-gez v6, :cond_2

    .line 335
    const-wide/16 v8, 0x1

    .line 338
    :cond_2
    iget-object v6, p1, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->thisObject:Ljava/lang/Object;

    long-to-float v10, v2

    div-float/2addr v10, v7

    float-to-long v10, v10

    invoke-static {v6, v1, v10, v11}, Lde/robv/android/xposed/XposedHelpers;->setLongField(Ljava/lang/Object;Ljava/lang/String;J)V

    .line 340
    iget-object v1, p1, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->thisObject:Ljava/lang/Object;

    invoke-static {v1, v0, v8, v9}, Lde/robv/android/xposed/XposedHelpers;->setLongField(Ljava/lang/Object;Ljava/lang/String;J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 344
    .end local v2    # "total":J
    .end local v4    # "interval":J
    .end local v8    # "newInterval":J
    goto :goto_1

    .line 325
    .restart local v2    # "total":J
    :cond_3
    :goto_0
    return-void

    .line 342
    .end local v2    # "total":J
    :catchall_0
    move-exception v0

    .line 345
    :goto_1
    return-void
.end method
