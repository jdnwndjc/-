.class Lcom/adspeed/hook/MainHook$2;
.super Lde/robv/android/xposed/XC_MethodHook;
.source "MainHook.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adspeed/hook/MainHook;->hookSystemPlayer(Ljava/lang/ClassLoader;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/adspeed/hook/MainHook;

.field final synthetic val$ppClass:Ljava/lang/Class;


# direct methods
.method constructor <init>(Lcom/adspeed/hook/MainHook;Ljava/lang/Class;)V
    .locals 0
    .param p1, "this$0"    # Lcom/adspeed/hook/MainHook;

    .line 130
    iput-object p1, p0, Lcom/adspeed/hook/MainHook$2;->this$0:Lcom/adspeed/hook/MainHook;

    iput-object p2, p0, Lcom/adspeed/hook/MainHook$2;->val$ppClass:Ljava/lang/Class;

    invoke-direct {p0}, Lde/robv/android/xposed/XC_MethodHook;-><init>()V

    return-void
.end method


# virtual methods
.method protected afterHookedMethod(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V
    .locals 6
    .param p1, "param"    # Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;

    .line 134
    :try_start_0
    iget-object v0, p0, Lcom/adspeed/hook/MainHook$2;->val$ppClass:Ljava/lang/Class;

    const/4 v1, 0x0

    new-array v2, v1, [Ljava/lang/Object;

    invoke-static {v0, v2}, Lde/robv/android/xposed/XposedHelpers;->newInstance(Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 135
    .local v0, "pp":Ljava/lang/Object;
    const-string v2, "setSpeed"

    const/4 v3, 0x1

    new-array v4, v3, [Ljava/lang/Object;

    const/high16 v5, 0x40400000    # 3.0f

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-static {v0, v2, v4}, Lde/robv/android/xposed/XposedHelpers;->callMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 136
    iget-object v2, p1, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->thisObject:Ljava/lang/Object;

    const-string v4, "setPlaybackParams"

    new-array v3, v3, [Ljava/lang/Object;

    aput-object v0, v3, v1

    invoke-static {v2, v4, v3}, Lde/robv/android/xposed/XposedHelpers;->callMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 139
    nop

    .end local v0    # "pp":Ljava/lang/Object;
    goto :goto_0

    .line 137
    :catchall_0
    move-exception v0

    .line 140
    :goto_0
    return-void
.end method
