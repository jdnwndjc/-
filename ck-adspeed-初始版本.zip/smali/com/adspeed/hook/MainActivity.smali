.class public Lcom/adspeed/hook/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 8
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 12
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 13
    sget v0, Lcom/adspeed/hook/R$layout;->activity_main:I

    invoke-virtual {p0, v0}, Lcom/adspeed/hook/MainActivity;->setContentView(I)V

    .line 15
    const-string v0, "\u5df2\u5f00\u542f\uff08\u65f6\u957f\u6821\u9a8c\u514d\u75ab\uff09"

    .line 18
    .local v0, "clock":Ljava/lang/String;
    const-string v1, "\u8ddf\u968f\u65f6\u949f\u81ea\u52a8\u52a0\u901f\uff08\u5fc3\u8df3\u6b21\u6570\u4e0d\u53d8\uff09"

    .line 25
    .local v1, "timer":Ljava/lang/String;
    sget v2, Lcom/adspeed/hook/R$id;->tv_status:I

    invoke-virtual {p0, v2}, Lcom/adspeed/hook/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    .line 26
    .local v2, "tv":Landroid/widget/TextView;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "AdSpeed \u5e7f\u544a\u500d\u901f\uff08\u6297\u68c0\u6d4b\u7248\uff09\n\n\u89c6\u9891\u500d\u901f\uff1a3.0x\n\u865a\u62df\u65f6\u949f\u8865\u507f\uff1a"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "\n\u5012\u8ba1\u65f6\uff1a"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "\n\n\u4f7f\u7528\u6b65\u9aa4\uff1a\n1. \u5728 Xposed / LSPosed \u91cc\u542f\u7528\u672c\u6a21\u5757\n2. \u4f5c\u7528\u57df\u52fe\u9009\u76ee\u6807 App\uff08\u6e38\u620f / \u77ed\u5267 / \u7f51\u8d5a\u7c7b\uff09\n3. \u5f3a\u5236\u505c\u6b62\u5e76\u91cd\u542f\u76ee\u6807 App\n\n\u8981\u6539\u53c2\u6570\uff1a\u4fee\u6539 MainHook.java \u9876\u90e8\u7684\nVIDEO_SPEED / CLOCK_SHIFT \u540e\u91cd\u65b0\u7f16\u8bd1\u5b89\u88c5\u3002"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 36
    return-void
.end method
