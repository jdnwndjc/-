.class Lcom/adspeed/hook/MainHook$3;
.super Lde/robv/android/xposed/XC_MethodHook;
.source "MainHook.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adspeed/hook/MainHook;->hookPlaybackParamsSetter(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/Class;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/adspeed/hook/MainHook;


# direct methods
.method constructor <init>(Lcom/adspeed/hook/MainHook;)V
    .locals 0
    .param p1, "this$0"    # Lcom/adspeed/hook/MainHook;

    .line 150
    iput-object p1, p0, Lcom/adspeed/hook/MainHook$3;->this$0:Lcom/adspeed/hook/MainHook;

    invoke-direct {p0}, Lde/robv/android/xposed/XC_MethodHook;-><init>()V

    return-void
.end method


# virtual methods
.method protected beforeHookedMethod(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V
    .locals 6
    .param p1, "param"    # Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;

    .line 154
    :try_start_0
    iget-object v0, p1, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->args:[Ljava/lang/Object;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    .line 155
    .local v0, "pp":Ljava/lang/Object;
    if-nez v0, :cond_0

    .line 156
    return-void

    .line 158
    :cond_0
    iget-object v2, p1, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->args:[Ljava/lang/Object;

    const-string v3, "setSpeed"

    const/4 v4, 0x1

    new-array v4, v4, [Ljava/lang/Object;

    const/high16 v5, 0x40400000    # 3.0f

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-static {v0, v3, v4}, Lde/robv/android/xposed/XposedHelpers;->callMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    aput-object v3, v2, v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 161
    .end local v0    # "pp":Ljava/lang/Object;
    goto :goto_0

    .line 159
    :catchall_0
    move-exception v0

    .line 162
    :goto_0
    return-void
.end method
