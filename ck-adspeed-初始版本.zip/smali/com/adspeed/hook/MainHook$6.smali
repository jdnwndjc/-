.class Lcom/adspeed/hook/MainHook$6;
.super Lde/robv/android/xposed/XC_MethodHook;
.source "MainHook.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adspeed/hook/MainHook;->hookSessionMethods(Ljava/lang/String;Ljava/lang/ClassLoader;[Ljava/lang/String;[Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/adspeed/hook/MainHook;


# direct methods
.method constructor <init>(Lcom/adspeed/hook/MainHook;)V
    .locals 0
    .param p1, "this$0"    # Lcom/adspeed/hook/MainHook;

    .line 244
    iput-object p1, p0, Lcom/adspeed/hook/MainHook$6;->this$0:Lcom/adspeed/hook/MainHook;

    invoke-direct {p0}, Lde/robv/android/xposed/XC_MethodHook;-><init>()V

    return-void
.end method


# virtual methods
.method protected beforeHookedMethod(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V
    .locals 0
    .param p1, "param"    # Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;

    .line 247
    invoke-static {}, Lcom/adspeed/hook/ClockShift;->onPlaybackStart()V

    .line 248
    return-void
.end method
