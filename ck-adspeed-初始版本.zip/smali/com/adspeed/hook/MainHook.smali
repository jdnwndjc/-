.class public Lcom/adspeed/hook/MainHook;
.super Ljava/lang/Object;
.source "MainHook.java"

# interfaces
.implements Lde/robv/android/xposed/IXposedHookLoadPackage;


# static fields
.field public static final CLOCK_SHIFT:Z = true

.field public static final SPEED_UP_TIMER:Z = true

.field private static final TAG:Ljava/lang/String; = "AdSpeed"

.field private static final TIMER_MAX_MS:J = 0x2bf20L

.field private static final TIMER_MIN_MS:J = 0x1f40L

.field public static final TIMER_SPEED:F = 3.0f

.field public static final VIDEO_SPEED:F = 3.0f


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private hookClockShift(Ljava/lang/ClassLoader;)V
    .locals 6
    .param p1, "cl"    # Ljava/lang/ClassLoader;

    .line 276
    const-string v0, "android.os.SystemClock"

    const/4 v1, 0x0

    const/4 v2, 0x1

    :try_start_0
    const-string v3, "elapsedRealtime"

    new-array v4, v2, [Ljava/lang/Object;

    new-instance v5, Lcom/adspeed/hook/MainHook$8;

    invoke-direct {v5, p0}, Lcom/adspeed/hook/MainHook$8;-><init>(Lcom/adspeed/hook/MainHook;)V

    aput-object v5, v4, v1

    invoke-static {v0, p1, v3, v4}, Lde/robv/android/xposed/XposedHelpers;->findAndHookMethod(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/String;[Ljava/lang/Object;)Lde/robv/android/xposed/XC_MethodHook$Unhook;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 288
    goto :goto_0

    .line 286
    :catchall_0
    move-exception v3

    .line 287
    .local v3, "t":Ljava/lang/Throwable;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "AdSpeed: hook elapsedRealtime failed: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lde/robv/android/xposed/XposedBridge;->log(Ljava/lang/String;)V

    .line 291
    .end local v3    # "t":Ljava/lang/Throwable;
    :goto_0
    :try_start_1
    const-string v3, "elapsedRealtimeNanos"

    new-array v2, v2, [Ljava/lang/Object;

    new-instance v4, Lcom/adspeed/hook/MainHook$9;

    invoke-direct {v4, p0}, Lcom/adspeed/hook/MainHook$9;-><init>(Lcom/adspeed/hook/MainHook;)V

    aput-object v4, v2, v1

    invoke-static {v0, p1, v3, v2}, Lde/robv/android/xposed/XposedHelpers;->findAndHookMethod(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/String;[Ljava/lang/Object;)Lde/robv/android/xposed/XC_MethodHook$Unhook;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 303
    goto :goto_1

    .line 301
    :catchall_1
    move-exception v0

    .line 304
    :goto_1
    return-void
.end method

.method private hookCountDownTimer(Ljava/lang/ClassLoader;)V
    .locals 5
    .param p1, "cl"    # Ljava/lang/ClassLoader;

    .line 317
    :try_start_0
    const-string v0, "android.os.CountDownTimer"

    const-string v1, "start"

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    new-instance v3, Lcom/adspeed/hook/MainHook$10;

    invoke-direct {v3, p0}, Lcom/adspeed/hook/MainHook$10;-><init>(Lcom/adspeed/hook/MainHook;)V

    const/4 v4, 0x0

    aput-object v3, v2, v4

    invoke-static {v0, p1, v1, v2}, Lde/robv/android/xposed/XposedHelpers;->findAndHookMethod(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/String;[Ljava/lang/Object;)Lde/robv/android/xposed/XC_MethodHook$Unhook;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 349
    goto :goto_0

    .line 347
    :catchall_0
    move-exception v0

    .line 348
    .local v0, "t":Ljava/lang/Throwable;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "AdSpeed: hook CountDownTimer failed: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lde/robv/android/xposed/XposedBridge;->log(Ljava/lang/String;)V

    .line 350
    .end local v0    # "t":Ljava/lang/Throwable;
    :goto_0
    return-void
.end method

.method private hookFloatSetter(Ljava/lang/ClassLoader;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2
    .param p1, "cl"    # Ljava/lang/ClassLoader;
    .param p2, "className"    # Ljava/lang/String;
    .param p3, "method"    # Ljava/lang/String;

    .line 194
    invoke-static {p2, p1}, Lde/robv/android/xposed/XposedHelpers;->findClassIfExists(Ljava/lang/String;Ljava/lang/ClassLoader;)Ljava/lang/Class;

    move-result-object v0

    .line 195
    .local v0, "c":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    if-nez v0, :cond_0

    .line 196
    return-void

    .line 199
    :cond_0
    :try_start_0
    new-instance v1, Lcom/adspeed/hook/MainHook$5;

    invoke-direct {v1, p0}, Lcom/adspeed/hook/MainHook$5;-><init>(Lcom/adspeed/hook/MainHook;)V

    invoke-static {v0, p3, v1}, Lde/robv/android/xposed/XposedBridge;->hookAllMethods(Ljava/lang/Class;Ljava/lang/String;Lde/robv/android/xposed/XC_MethodHook;)Ljava/util/Set;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 209
    goto :goto_0

    .line 207
    :catchall_0
    move-exception v1

    .line 210
    :goto_0
    return-void
.end method

.method private hookPlaybackParameters(Ljava/lang/ClassLoader;Ljava/lang/String;)V
    .locals 4
    .param p1, "cl"    # Ljava/lang/ClassLoader;
    .param p2, "className"    # Ljava/lang/String;

    .line 174
    invoke-static {p2, p1}, Lde/robv/android/xposed/XposedHelpers;->findClassIfExists(Ljava/lang/String;Ljava/lang/ClassLoader;)Ljava/lang/Class;

    move-result-object v0

    .line 175
    .local v0, "c":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    if-nez v0, :cond_0

    .line 176
    return-void

    .line 179
    :cond_0
    :try_start_0
    new-instance v1, Lcom/adspeed/hook/MainHook$4;

    invoke-direct {v1, p0}, Lcom/adspeed/hook/MainHook$4;-><init>(Lcom/adspeed/hook/MainHook;)V

    invoke-static {v0, v1}, Lde/robv/android/xposed/XposedBridge;->hookAllConstructors(Ljava/lang/Class;Lde/robv/android/xposed/XC_MethodHook;)Ljava/util/Set;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 189
    goto :goto_0

    .line 187
    :catchall_0
    move-exception v1

    .line 188
    .local v1, "t":Ljava/lang/Throwable;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "AdSpeed: hook "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " failed: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lde/robv/android/xposed/XposedBridge;->log(Ljava/lang/String;)V

    .line 190
    .end local v1    # "t":Ljava/lang/Throwable;
    :goto_0
    return-void
.end method

.method private hookPlaybackParamsSetter(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/Class;)V
    .locals 4
    .param p1, "className"    # Ljava/lang/String;
    .param p2, "cl"    # Ljava/lang/ClassLoader;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/ClassLoader;",
            "Ljava/lang/Class<",
            "*>;)V"
        }
    .end annotation

    .line 149
    .local p3, "argType":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    :try_start_0
    const-string v0, "setPlaybackParams"

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v2, 0x0

    aput-object p3, v1, v2

    new-instance v2, Lcom/adspeed/hook/MainHook$3;

    invoke-direct {v2, p0}, Lcom/adspeed/hook/MainHook$3;-><init>(Lcom/adspeed/hook/MainHook;)V

    const/4 v3, 0x1

    aput-object v2, v1, v3

    invoke-static {p1, p2, v0, v1}, Lde/robv/android/xposed/XposedHelpers;->findAndHookMethod(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/String;[Ljava/lang/Object;)Lde/robv/android/xposed/XC_MethodHook$Unhook;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 166
    goto :goto_0

    .line 164
    :catchall_0
    move-exception v0

    .line 167
    :goto_0
    return-void
.end method

.method private hookPlayerSessions(Ljava/lang/ClassLoader;)V
    .locals 6
    .param p1, "cl"    # Ljava/lang/ClassLoader;

    .line 219
    const-string v0, "start"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    .line 220
    .local v0, "starts":[Ljava/lang/String;
    const-string v1, "reset"

    const-string v2, "pause"

    const-string v3, "stop"

    const-string v4, "release"

    filled-new-array {v2, v3, v4, v1}, [Ljava/lang/String;

    move-result-object v1

    .line 223
    .local v1, "stops":[Ljava/lang/String;
    const-string v5, "android.media.MediaPlayer"

    invoke-direct {p0, v5, p1, v0, v1}, Lcom/adspeed/hook/MainHook;->hookSessionMethods(Ljava/lang/String;Ljava/lang/ClassLoader;[Ljava/lang/String;[Ljava/lang/String;)V

    .line 226
    const-string v5, "tv.danmaku.ijk.media.player.IjkMediaPlayer"

    invoke-direct {p0, v5, p1, v0, v1}, Lcom/adspeed/hook/MainHook;->hookSessionMethods(Ljava/lang/String;Ljava/lang/ClassLoader;[Ljava/lang/String;[Ljava/lang/String;)V

    .line 229
    const-string v5, "play"

    filled-new-array {v5}, [Ljava/lang/String;

    move-result-object v5

    .line 230
    .local v5, "exoStarts":[Ljava/lang/String;
    filled-new-array {v2, v3, v4}, [Ljava/lang/String;

    move-result-object v2

    .line 231
    .local v2, "exoStops":[Ljava/lang/String;
    const-string v3, "com.google.android.exoplayer2.ExoPlayerImpl"

    invoke-direct {p0, v3, p1, v5, v2}, Lcom/adspeed/hook/MainHook;->hookSessionMethods(Ljava/lang/String;Ljava/lang/ClassLoader;[Ljava/lang/String;[Ljava/lang/String;)V

    .line 232
    const-string v3, "com.google.android.exoplayer2.SimpleExoPlayer"

    invoke-direct {p0, v3, p1, v5, v2}, Lcom/adspeed/hook/MainHook;->hookSessionMethods(Ljava/lang/String;Ljava/lang/ClassLoader;[Ljava/lang/String;[Ljava/lang/String;)V

    .line 233
    const-string v3, "androidx.media3.exoplayer.ExoPlayerImpl"

    invoke-direct {p0, v3, p1, v5, v2}, Lcom/adspeed/hook/MainHook;->hookSessionMethods(Ljava/lang/String;Ljava/lang/ClassLoader;[Ljava/lang/String;[Ljava/lang/String;)V

    .line 234
    return-void
.end method

.method private hookSessionMethods(Ljava/lang/String;Ljava/lang/ClassLoader;[Ljava/lang/String;[Ljava/lang/String;)V
    .locals 6
    .param p1, "className"    # Ljava/lang/String;
    .param p2, "cl"    # Ljava/lang/ClassLoader;
    .param p3, "starts"    # [Ljava/lang/String;
    .param p4, "stops"    # [Ljava/lang/String;

    .line 238
    invoke-static {p1, p2}, Lde/robv/android/xposed/XposedHelpers;->findClassIfExists(Ljava/lang/String;Ljava/lang/ClassLoader;)Ljava/lang/Class;

    move-result-object v0

    .line 239
    .local v0, "c":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    if-nez v0, :cond_0

    .line 240
    return-void

    .line 242
    :cond_0
    array-length v1, p3

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v1, :cond_1

    aget-object v4, p3, v3

    .line 244
    .local v4, "m":Ljava/lang/String;
    :try_start_0
    new-instance v5, Lcom/adspeed/hook/MainHook$6;

    invoke-direct {v5, p0}, Lcom/adspeed/hook/MainHook$6;-><init>(Lcom/adspeed/hook/MainHook;)V

    invoke-static {v0, v4, v5}, Lde/robv/android/xposed/XposedBridge;->hookAllMethods(Ljava/lang/Class;Ljava/lang/String;Lde/robv/android/xposed/XC_MethodHook;)Ljava/util/Set;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 252
    goto :goto_1

    .line 250
    :catchall_0
    move-exception v5

    .line 242
    .end local v4    # "m":Ljava/lang/String;
    :goto_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 254
    :cond_1
    array-length v1, p4

    :goto_2
    if-ge v2, v1, :cond_2

    aget-object v3, p4, v2

    .line 256
    .local v3, "m":Ljava/lang/String;
    :try_start_1
    new-instance v4, Lcom/adspeed/hook/MainHook$7;

    invoke-direct {v4, p0}, Lcom/adspeed/hook/MainHook$7;-><init>(Lcom/adspeed/hook/MainHook;)V

    invoke-static {v0, v3, v4}, Lde/robv/android/xposed/XposedBridge;->hookAllMethods(Ljava/lang/Class;Ljava/lang/String;Lde/robv/android/xposed/XC_MethodHook;)Ljava/util/Set;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 264
    goto :goto_3

    .line 262
    :catchall_1
    move-exception v4

    .line 254
    .end local v3    # "m":Ljava/lang/String;
    :goto_3
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    .line 266
    :cond_2
    return-void
.end method

.method private hookSystemPlayer(Ljava/lang/ClassLoader;)V
    .locals 6
    .param p1, "cl"    # Ljava/lang/ClassLoader;

    .line 107
    const-string v0, "android.media.PlaybackParams"

    invoke-static {v0, p1}, Lde/robv/android/xposed/XposedHelpers;->findClassIfExists(Ljava/lang/String;Ljava/lang/ClassLoader;)Ljava/lang/Class;

    move-result-object v0

    .line 108
    .local v0, "ppClass":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    if-nez v0, :cond_0

    .line 109
    return-void

    .line 113
    :cond_0
    :try_start_0
    const-string v1, "setSpeed"

    new-instance v2, Lcom/adspeed/hook/MainHook$1;

    invoke-direct {v2, p0}, Lcom/adspeed/hook/MainHook$1;-><init>(Lcom/adspeed/hook/MainHook;)V

    invoke-static {v0, v1, v2}, Lde/robv/android/xposed/XposedBridge;->hookAllMethods(Ljava/lang/Class;Ljava/lang/String;Lde/robv/android/xposed/XC_MethodHook;)Ljava/util/Set;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 123
    goto :goto_0

    .line 121
    :catchall_0
    move-exception v1

    .line 122
    .local v1, "t":Ljava/lang/Throwable;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "AdSpeed: hook PlaybackParams#setSpeed failed: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lde/robv/android/xposed/XposedBridge;->log(Ljava/lang/String;)V

    .line 125
    .end local v1    # "t":Ljava/lang/Throwable;
    :goto_0
    const-string v1, "android.media.MediaPlayer"

    invoke-direct {p0, v1, p1, v0}, Lcom/adspeed/hook/MainHook;->hookPlaybackParamsSetter(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/Class;)V

    .line 126
    const-string v2, "android.widget.VideoView"

    invoke-direct {p0, v2, p1, v0}, Lcom/adspeed/hook/MainHook;->hookPlaybackParamsSetter(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/Class;)V

    .line 129
    :try_start_1
    const-string v2, "start"

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    new-instance v4, Lcom/adspeed/hook/MainHook$2;

    invoke-direct {v4, p0, v0}, Lcom/adspeed/hook/MainHook$2;-><init>(Lcom/adspeed/hook/MainHook;Ljava/lang/Class;)V

    const/4 v5, 0x0

    aput-object v4, v3, v5

    invoke-static {v1, p1, v2, v3}, Lde/robv/android/xposed/XposedHelpers;->findAndHookMethod(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/String;[Ljava/lang/Object;)Lde/robv/android/xposed/XC_MethodHook$Unhook;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 144
    goto :goto_1

    .line 142
    :catchall_1
    move-exception v1

    .line 143
    .restart local v1    # "t":Ljava/lang/Throwable;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "AdSpeed: hook MediaPlayer#start failed: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lde/robv/android/xposed/XposedBridge;->log(Ljava/lang/String;)V

    .line 145
    .end local v1    # "t":Ljava/lang/Throwable;
    :goto_1
    return-void
.end method


# virtual methods
.method public handleLoadPackage(Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;)V
    .locals 3
    .param p1, "lpparam"    # Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;

    .line 65
    if-eqz p1, :cond_3

    iget-object v0, p1, Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;->classLoader:Ljava/lang/ClassLoader;

    if-nez v0, :cond_0

    goto :goto_1

    .line 68
    :cond_0
    const-string v0, "com.adspeed.hook"

    iget-object v1, p1, Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;->packageName:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p1, Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;->packageName:Ljava/lang/String;

    .line 69
    const-string v1, "android"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    .line 73
    :cond_1
    iget-object v0, p1, Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;->classLoader:Ljava/lang/ClassLoader;

    .line 76
    .local v0, "cl":Ljava/lang/ClassLoader;
    invoke-direct {p0, v0}, Lcom/adspeed/hook/MainHook;->hookSystemPlayer(Ljava/lang/ClassLoader;)V

    .line 79
    const-string v1, "com.google.android.exoplayer2.PlaybackParameters"

    invoke-direct {p0, v0, v1}, Lcom/adspeed/hook/MainHook;->hookPlaybackParameters(Ljava/lang/ClassLoader;Ljava/lang/String;)V

    .line 80
    const-string v1, "androidx.media3.common.PlaybackParameters"

    invoke-direct {p0, v0, v1}, Lcom/adspeed/hook/MainHook;->hookPlaybackParameters(Ljava/lang/ClassLoader;Ljava/lang/String;)V

    .line 83
    const-string v1, "tv.danmaku.ijk.media.player.IjkMediaPlayer"

    const-string v2, "setSpeed"

    invoke-direct {p0, v0, v1, v2}, Lcom/adspeed/hook/MainHook;->hookFloatSetter(Ljava/lang/ClassLoader;Ljava/lang/String;Ljava/lang/String;)V

    .line 84
    const-string v1, "com.tencent.rtmp.TXVodPlayer"

    const-string v2, "setRate"

    invoke-direct {p0, v0, v1, v2}, Lcom/adspeed/hook/MainHook;->hookFloatSetter(Ljava/lang/ClassLoader;Ljava/lang/String;Ljava/lang/String;)V

    .line 85
    const-string v1, "com.tencent.liteav.TXVodPlayer"

    invoke-direct {p0, v0, v1, v2}, Lcom/adspeed/hook/MainHook;->hookFloatSetter(Ljava/lang/ClassLoader;Ljava/lang/String;Ljava/lang/String;)V

    .line 86
    const-string v1, "com.aliyun.player.AliPlayer"

    invoke-direct {p0, v0, v1, v2}, Lcom/adspeed/hook/MainHook;->hookFloatSetter(Ljava/lang/ClassLoader;Ljava/lang/String;Ljava/lang/String;)V

    .line 90
    invoke-direct {p0, v0}, Lcom/adspeed/hook/MainHook;->hookPlayerSessions(Ljava/lang/ClassLoader;)V

    .line 91
    invoke-direct {p0, v0}, Lcom/adspeed/hook/MainHook;->hookClockShift(Ljava/lang/ClassLoader;)V

    .line 98
    return-void

    .line 70
    .end local v0    # "cl":Ljava/lang/ClassLoader;
    :cond_2
    :goto_0
    return-void

    .line 66
    :cond_3
    :goto_1
    return-void
.end method
