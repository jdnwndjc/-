.class final Lcom/adspeed/hook/ClockShift;
.super Ljava/lang/Object;
.source "ClockShift.java"


# static fields
.field private static final EXTRA_CAP_MS:J = 0x927c0L

.field private static final LOCK:Ljava/lang/Object;

.field private static final SESSION_CAP_MS:J = 0x2bf20L

.field private static sActive:I

.field private static volatile sExtraMs:J

.field private static volatile sStartInternal:J


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 22
    const-wide/16 v0, 0x0

    sput-wide v0, Lcom/adspeed/hook/ClockShift;->sExtraMs:J

    .line 25
    sput-wide v0, Lcom/adspeed/hook/ClockShift;->sStartInternal:J

    .line 28
    const/4 v0, 0x0

    sput v0, Lcom/adspeed/hook/ClockShift;->sActive:I

    .line 36
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/adspeed/hook/ClockShift;->LOCK:Ljava/lang/Object;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 38
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 39
    return-void
.end method

.method static extraMs()J
    .locals 11

    .line 99
    sget-wide v0, Lcom/adspeed/hook/ClockShift;->sStartInternal:J

    .line 100
    .local v0, "start":J
    sget-wide v2, Lcom/adspeed/hook/ClockShift;->sExtraMs:J

    .line 101
    .local v2, "base":J
    const-wide/16 v4, 0x0

    cmp-long v6, v0, v4

    if-nez v6, :cond_0

    .line 102
    return-wide v2

    .line 104
    :cond_0
    invoke-static {}, Lcom/adspeed/hook/ClockShift;->internalNow()J

    move-result-wide v6

    sub-long/2addr v6, v0

    .line 105
    .local v6, "delta":J
    cmp-long v8, v6, v4

    if-gtz v8, :cond_1

    .line 106
    return-wide v2

    .line 108
    :cond_1
    const-wide/32 v4, 0x2bf20

    cmp-long v8, v6, v4

    if-lez v8, :cond_2

    .line 109
    const-wide/32 v6, 0x2bf20

    .line 111
    :cond_2
    const/high16 v4, 0x40000000    # 2.0f

    long-to-float v5, v6

    mul-float v5, v5, v4

    float-to-long v4, v5

    add-long/2addr v4, v2

    .line 112
    .local v4, "extra":J
    const-wide/32 v8, 0x927c0

    cmp-long v10, v4, v8

    if-lez v10, :cond_3

    goto :goto_0

    :cond_3
    move-wide v8, v4

    :goto_0
    return-wide v8
.end method

.method private static internalNow()J
    .locals 4

    .line 42
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    const-wide/32 v2, 0xf4240

    div-long/2addr v0, v2

    return-wide v0
.end method

.method static onPlaybackStart()V
    .locals 9

    .line 47
    sget-object v0, Lcom/adspeed/hook/ClockShift;->LOCK:Ljava/lang/Object;

    monitor-enter v0

    .line 48
    :try_start_0
    invoke-static {}, Lcom/adspeed/hook/ClockShift;->internalNow()J

    move-result-wide v1

    .line 49
    .local v1, "now":J
    sget v3, Lcom/adspeed/hook/ClockShift;->sActive:I

    const/4 v4, 0x1

    if-gtz v3, :cond_0

    .line 50
    sput v4, Lcom/adspeed/hook/ClockShift;->sActive:I

    .line 51
    sput-wide v1, Lcom/adspeed/hook/ClockShift;->sStartInternal:J

    .line 52
    monitor-exit v0

    return-void

    .line 55
    :cond_0
    sget-wide v5, Lcom/adspeed/hook/ClockShift;->sStartInternal:J

    sub-long v5, v1, v5

    const-wide/32 v7, 0x2bf20

    cmp-long v3, v5, v7

    if-lez v3, :cond_1

    .line 56
    invoke-static {v1, v2}, Lcom/adspeed/hook/ClockShift;->settleLocked(J)V

    .line 57
    sput-wide v1, Lcom/adspeed/hook/ClockShift;->sStartInternal:J

    .line 59
    :cond_1
    sget v3, Lcom/adspeed/hook/ClockShift;->sActive:I

    add-int/2addr v3, v4

    sput v3, Lcom/adspeed/hook/ClockShift;->sActive:I

    .line 60
    .end local v1    # "now":J
    monitor-exit v0

    .line 61
    return-void

    .line 60
    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.method static onPlaybackStop()V
    .locals 3

    .line 65
    sget-object v0, Lcom/adspeed/hook/ClockShift;->LOCK:Ljava/lang/Object;

    monitor-enter v0

    .line 66
    :try_start_0
    sget v1, Lcom/adspeed/hook/ClockShift;->sActive:I

    if-gtz v1, :cond_0

    .line 67
    monitor-exit v0

    return-void

    .line 69
    :cond_0
    add-int/lit8 v1, v1, -0x1

    sput v1, Lcom/adspeed/hook/ClockShift;->sActive:I

    .line 70
    if-nez v1, :cond_1

    .line 71
    invoke-static {}, Lcom/adspeed/hook/ClockShift;->internalNow()J

    move-result-wide v1

    invoke-static {v1, v2}, Lcom/adspeed/hook/ClockShift;->settleLocked(J)V

    .line 73
    :cond_1
    monitor-exit v0

    .line 74
    return-void

    .line 73
    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.method private static settleLocked(J)V
    .locals 9
    .param p0, "now"    # J

    .line 78
    sget-wide v0, Lcom/adspeed/hook/ClockShift;->sStartInternal:J

    .line 79
    .local v0, "start":J
    const-wide/16 v2, 0x0

    sput-wide v2, Lcom/adspeed/hook/ClockShift;->sStartInternal:J

    .line 80
    cmp-long v4, v0, v2

    if-nez v4, :cond_0

    .line 81
    return-void

    .line 83
    :cond_0
    sub-long v4, p0, v0

    .line 84
    .local v4, "delta":J
    cmp-long v6, v4, v2

    if-gtz v6, :cond_1

    .line 85
    return-void

    .line 87
    :cond_1
    const-wide/32 v2, 0x2bf20

    cmp-long v6, v4, v2

    if-lez v6, :cond_2

    .line 88
    const-wide/32 v4, 0x2bf20

    .line 90
    :cond_2
    sget-wide v2, Lcom/adspeed/hook/ClockShift;->sExtraMs:J

    const/high16 v6, 0x40000000    # 2.0f

    long-to-float v7, v4

    mul-float v7, v7, v6

    float-to-long v6, v7

    add-long/2addr v2, v6

    .line 91
    .local v2, "extra":J
    const-wide/32 v6, 0x927c0

    cmp-long v8, v2, v6

    if-lez v8, :cond_3

    goto :goto_0

    :cond_3
    move-wide v6, v2

    :goto_0
    sput-wide v6, Lcom/adspeed/hook/ClockShift;->sExtraMs:J

    .line 92
    return-void
.end method
