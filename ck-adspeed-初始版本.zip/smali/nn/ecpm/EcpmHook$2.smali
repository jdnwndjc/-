.class Lnn/ecpm/EcpmHook$2;
.super Lde/robv/android/xposed/XC_MethodHook;
.source "EcpmHook.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnn/ecpm/EcpmHook;->installScanner(Ljava/lang/ClassLoader;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnn/ecpm/EcpmHook;


# direct methods
.method constructor <init>(Lnn/ecpm/EcpmHook;)V
    .locals 0
    .param p1, "this$0"    # Lnn/ecpm/EcpmHook;

    .line 307
    iput-object p1, p0, Lnn/ecpm/EcpmHook$2;->this$0:Lnn/ecpm/EcpmHook;

    invoke-direct {p0}, Lde/robv/android/xposed/XC_MethodHook;-><init>()V

    return-void
.end method


# virtual methods
.method protected afterHookedMethod(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V
    .locals 3
    .param p1, "param"    # Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;

    .line 310
    invoke-virtual {p1}, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->getResult()Ljava/lang/Object;

    move-result-object v0

    .line 311
    .local v0, "r":Ljava/lang/Object;
    instance-of v1, v0, Ljava/lang/Class;

    if-nez v1, :cond_0

    return-void

    .line 313
    :cond_0
    :try_start_0
    iget-object v1, p0, Lnn/ecpm/EcpmHook$2;->this$0:Lnn/ecpm/EcpmHook;

    move-object v2, v0

    check-cast v2, Ljava/lang/Class;

    invoke-static {v1, v2}, Lnn/ecpm/EcpmHook;->access$800(Lnn/ecpm/EcpmHook;Ljava/lang/Class;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 316
    goto :goto_0

    .line 314
    :catchall_0
    move-exception v1

    .line 317
    :goto_0
    return-void
.end method
