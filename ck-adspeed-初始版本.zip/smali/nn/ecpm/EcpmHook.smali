.class public Lnn/ecpm/EcpmHook;
.super Ljava/lang/Object;
.source "EcpmHook.java"

# interfaces
.implements Lde/robv/android/xposed/IXposedHookLoadPackage;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnn/ecpm/EcpmHook$Target;
    }
.end annotation


# static fields
.field private static final MAX_ROUNDS:I = 0x12c

.field private static final RAW:[[Ljava/lang/String;

.field private static final RETRY_MS:J = 0x7d0L

.field private static final SDK_PREFIXES:[Ljava/lang/String;

.field private static final TAG:Ljava/lang/String; = "EcpmRange"

.field private static final TARGETS:[Lnn/ecpm/EcpmHook$Target;

.field private static volatile started:Z


# instance fields
.field private configAttempts:I

.field private final counters:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private ecpmMax:J

.field private ecpmMin:J

.field private final firstCalls:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private volatile hookedCount:I

.field private final hookedKeys:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private pkgName:Ljava/lang/String;

.field private final random:Ljava/util/Random;

.field private final scannedClasses:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private skipNonPositive:Z


# direct methods
.method static constructor <clinit>()V
    .locals 23

    .line 32
    const/4 v0, 0x0

    sput-boolean v0, Lnn/ecpm/EcpmHook;->started:Z

    .line 54
    const/16 v1, 0x49

    new-array v1, v1, [Ljava/lang/String;

    const-string v2, "com.baidu.mobads."

    aput-object v2, v1, v0

    const-string v2, "com.qq.e."

    const/4 v3, 0x1

    aput-object v2, v1, v3

    const-string v2, "com.kwad."

    const/4 v4, 0x2

    aput-object v2, v1, v4

    const-string v2, "com.sigmob."

    const/4 v5, 0x3

    aput-object v2, v1, v5

    const-string v2, "com.bytedance."

    const/4 v6, 0x4

    aput-object v2, v1, v6

    const-string v2, "com.pangle."

    const/4 v7, 0x5

    aput-object v2, v1, v7

    const-string v2, "com.pgl."

    const/4 v8, 0x6

    aput-object v2, v1, v8

    const-string v2, "com.ss.android."

    const/4 v9, 0x7

    aput-object v2, v1, v9

    const-string v2, "com.bykv."

    const/16 v10, 0x8

    aput-object v2, v1, v10

    const-string v2, "com.anythink."

    const/16 v11, 0x9

    aput-object v2, v1, v11

    const-string v2, "com.adsuyi."

    const/16 v12, 0xa

    aput-object v2, v1, v12

    const-string v2, "com.mintegral."

    const/16 v13, 0xb

    aput-object v2, v1, v13

    const-string v2, "com.mbridge."

    const/16 v14, 0xc

    aput-object v2, v1, v14

    const-string v2, "com.tanx."

    const/16 v15, 0xd

    aput-object v2, v1, v15

    const-string v2, "com.alimama."

    const/16 v16, 0xe

    aput-object v2, v1, v16

    const-string v2, "com.alibaba.sdk.android."

    const/16 v17, 0xf

    aput-object v2, v1, v17

    const-string v2, "com.gdt."

    const/16 v18, 0x10

    aput-object v2, v1, v18

    const-string v2, "com.adview."

    const/16 v19, 0x11

    aput-object v2, v1, v19

    const/16 v2, 0x12

    const-string v20, "com.upltv."

    aput-object v20, v1, v2

    const/16 v2, 0x13

    const-string v20, "com.apusapps."

    aput-object v20, v1, v2

    const/16 v2, 0x14

    const-string v20, "com.huawei.hms.ads."

    aput-object v20, v1, v2

    const/16 v2, 0x15

    const-string v20, "com.huawei.hms.adsengine."

    aput-object v20, v1, v2

    const/16 v2, 0x16

    const-string v20, "com.xiaomi.ad."

    aput-object v20, v1, v2

    const/16 v2, 0x17

    const-string v20, "com.xiaomi.miplay."

    aput-object v20, v1, v2

    const/16 v2, 0x18

    const-string v20, "com.miui.zeus."

    aput-object v20, v1, v2

    const/16 v2, 0x19

    const-string v20, "com.oppo."

    aput-object v20, v1, v2

    const/16 v2, 0x1a

    const-string v20, "com.oplus."

    aput-object v20, v1, v2

    const/16 v2, 0x1b

    const-string v20, "com.heytap."

    aput-object v20, v1, v2

    const/16 v2, 0x1c

    const-string v20, "com.coloros."

    aput-object v20, v1, v2

    const/16 v2, 0x1d

    const-string v20, "com.vivo."

    aput-object v20, v1, v2

    const/16 v2, 0x1e

    const-string v20, "com.vivo.ad."

    aput-object v20, v1, v2

    const/16 v2, 0x1f

    const-string v20, "com.google.android.gms.ads."

    aput-object v20, v1, v2

    const/16 v2, 0x20

    const-string v20, "com.unity3d.ads."

    aput-object v20, v1, v2

    const/16 v2, 0x21

    const-string v20, "com.ironsource."

    aput-object v20, v1, v2

    const/16 v2, 0x22

    const-string v20, "com.applovin."

    aput-object v20, v1, v2

    const/16 v2, 0x23

    const-string v20, "com.vungle."

    aput-object v20, v1, v2

    const/16 v2, 0x24

    const-string v20, "com.inmobi."

    aput-object v20, v1, v2

    const/16 v2, 0x25

    const-string v20, "com.mopub."

    aput-object v20, v1, v2

    const/16 v2, 0x26

    const-string v20, "com.startapp."

    aput-object v20, v1, v2

    const/16 v2, 0x27

    const-string v20, "com.amazon.device.ads."

    aput-object v20, v1, v2

    const/16 v2, 0x28

    const-string v20, "com.tapjoy."

    aput-object v20, v1, v2

    const/16 v2, 0x29

    const-string v20, "com.fyber."

    aput-object v20, v1, v2

    const/16 v2, 0x2a

    const-string v20, "com.fairbid."

    aput-object v20, v1, v2

    const/16 v2, 0x2b

    const-string v20, "com.smaato."

    aput-object v20, v1, v2

    const/16 v2, 0x2c

    const-string v20, "com.chartboost."

    aput-object v20, v1, v2

    const/16 v2, 0x2d

    const-string v20, "com.supersonic."

    aput-object v20, v1, v2

    const/16 v2, 0x2e

    const-string v20, "com.adcolony."

    aput-object v20, v1, v2

    const/16 v2, 0x2f

    const-string v20, "com.my.target."

    aput-object v20, v1, v2

    const/16 v2, 0x30

    const-string v20, "com.tradplus."

    aput-object v20, v1, v2

    const/16 v2, 0x31

    const-string v20, "com.aiming.mdt."

    aput-object v20, v1, v2

    const/16 v2, 0x32

    const-string v20, "com.corpuse."

    aput-object v20, v1, v2

    const/16 v2, 0x33

    const-string v20, "com.supertool."

    aput-object v20, v1, v2

    const/16 v2, 0x34

    const-string v20, "com.appnext."

    aput-object v20, v1, v2

    const/16 v2, 0x35

    const-string v20, "com.bigo."

    aput-object v20, v1, v2

    const/16 v2, 0x36

    const-string v20, "com.opera."

    aput-object v20, v1, v2

    const/16 v2, 0x37

    const-string v20, "com.yandex."

    aput-object v20, v1, v2

    const/16 v2, 0x38

    const-string v20, "com.ogury."

    aput-object v20, v1, v2

    const/16 v2, 0x39

    const-string v20, "com.pubnative."

    aput-object v20, v1, v2

    const/16 v2, 0x3a

    const-string v20, "com.verizon."

    aput-object v20, v1, v2

    const/16 v2, 0x3b

    const-string v20, "com.admob."

    aput-object v20, v1, v2

    const/16 v2, 0x3c

    const-string v20, "com.google.ads."

    aput-object v20, v1, v2

    const/16 v2, 0x3d

    const-string v20, "com.mobfox."

    aput-object v20, v1, v2

    const/16 v2, 0x3e

    const-string v20, "com.mobileads."

    aput-object v20, v1, v2

    const/16 v2, 0x3f

    const-string v20, "com.vmax."

    aput-object v20, v1, v2

    const/16 v2, 0x40

    const-string v20, "com.yamobile."

    aput-object v20, v1, v2

    const/16 v2, 0x41

    const-string v20, "com.wanpu."

    aput-object v20, v1, v2

    const/16 v2, 0x42

    const-string v20, "com.domob."

    aput-object v20, v1, v2

    const/16 v2, 0x43

    const-string v20, "com.adsmogo."

    aput-object v20, v1, v2

    const/16 v2, 0x44

    const-string v20, "com.netease.ad."

    aput-object v20, v1, v2

    const/16 v2, 0x45

    const-string v20, "com.tanv."

    aput-object v20, v1, v2

    const/16 v2, 0x46

    const-string v20, "com.appic."

    aput-object v20, v1, v2

    const/16 v2, 0x47

    const-string v20, "com.oneway."

    aput-object v20, v1, v2

    const/16 v2, 0x48

    const-string v20, "com.adop."

    aput-object v20, v1, v2

    sput-object v1, Lnn/ecpm/EcpmHook;->SDK_PREFIXES:[Ljava/lang/String;

    .line 76
    const/16 v1, 0x23

    new-array v1, v1, [[Ljava/lang/String;

    new-array v2, v4, [Ljava/lang/String;

    const-string v20, "com.baidu.mobads.sdk.api.RewardVideoAd"

    aput-object v20, v2, v0

    const-string v20, "getECPMLevel"

    aput-object v20, v2, v3

    aput-object v2, v1, v0

    new-array v2, v4, [Ljava/lang/String;

    const-string v21, "com.baidu.mobads.sdk.api.RewardVideoAd"

    aput-object v21, v2, v0

    const-string v21, "getPECPM"

    aput-object v21, v2, v3

    aput-object v2, v1, v3

    new-array v2, v4, [Ljava/lang/String;

    const-string v22, "com.baidu.mobads.sdk.api.FullScreenVideoAd"

    aput-object v22, v2, v0

    aput-object v20, v2, v3

    aput-object v2, v1, v4

    new-array v2, v4, [Ljava/lang/String;

    const-string v22, "com.baidu.mobads.sdk.api.FullScreenVideoAd"

    aput-object v22, v2, v0

    aput-object v21, v2, v3

    aput-object v2, v1, v5

    new-array v2, v4, [Ljava/lang/String;

    const-string v5, "com.baidu.mobads.sdk.api.ExpressInterstitialAd"

    aput-object v5, v2, v0

    aput-object v20, v2, v3

    aput-object v2, v1, v6

    new-array v2, v4, [Ljava/lang/String;

    const-string v5, "com.baidu.mobads.sdk.api.ExpressInterstitialAd"

    aput-object v5, v2, v0

    aput-object v21, v2, v3

    aput-object v2, v1, v7

    new-array v2, v4, [Ljava/lang/String;

    const-string v5, "com.baidu.mobads.sdk.api.SplashAd"

    aput-object v5, v2, v0

    aput-object v20, v2, v3

    aput-object v2, v1, v8

    new-array v2, v4, [Ljava/lang/String;

    const-string v5, "com.baidu.mobads.sdk.api.SplashAd"

    aput-object v5, v2, v0

    aput-object v21, v2, v3

    aput-object v2, v1, v9

    new-array v2, v4, [Ljava/lang/String;

    const-string v5, "com.baidu.mobads.sdk.internal.ap"

    aput-object v5, v2, v0

    aput-object v20, v2, v3

    aput-object v2, v1, v10

    new-array v2, v4, [Ljava/lang/String;

    const-string v5, "com.baidu.mobads.sdk.internal.ap"

    aput-object v5, v2, v0

    aput-object v21, v2, v3

    aput-object v2, v1, v11

    new-array v2, v4, [Ljava/lang/String;

    const-string v5, "com.baidu.mobads.sdk.api.XAdNativeResponse"

    aput-object v5, v2, v0

    aput-object v20, v2, v3

    aput-object v2, v1, v12

    new-array v2, v4, [Ljava/lang/String;

    const-string v5, "com.baidu.mobads.sdk.api.XAdNativeResponse"

    aput-object v5, v2, v0

    aput-object v21, v2, v3

    aput-object v2, v1, v13

    new-array v2, v4, [Ljava/lang/String;

    const-string v5, "com.baidu.mobads.sdk.internal.br"

    aput-object v5, v2, v0

    aput-object v20, v2, v3

    aput-object v2, v1, v14

    new-array v2, v4, [Ljava/lang/String;

    const-string v5, "com.baidu.mobads.sdk.internal.br"

    aput-object v5, v2, v0

    aput-object v21, v2, v3

    aput-object v2, v1, v15

    new-array v2, v4, [Ljava/lang/String;

    const-string v5, "com.qq.e.ads.LiteAbstractAD"

    aput-object v5, v2, v0

    const-string v5, "getECPM"

    aput-object v5, v2, v3

    aput-object v2, v1, v16

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.qq.e.ads.LiteAbstractAD"

    aput-object v6, v2, v0

    aput-object v20, v2, v3

    aput-object v2, v1, v17

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.qq.e.ads.nativ.NativeUnifiedADDataAdapter"

    aput-object v6, v2, v0

    aput-object v5, v2, v3

    aput-object v2, v1, v18

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.qq.e.ads.nativ.NativeUnifiedADDataAdapter"

    aput-object v6, v2, v0

    aput-object v20, v2, v3

    aput-object v2, v1, v19

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.qq.e.ads.banner2.UnifiedBannerView"

    aput-object v6, v2, v0

    aput-object v5, v2, v3

    const/16 v6, 0x12

    aput-object v2, v1, v6

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.qq.e.ads.banner2.UnifiedBannerView"

    aput-object v6, v2, v0

    aput-object v20, v2, v3

    const/16 v6, 0x13

    aput-object v2, v1, v6

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.qq.e.ads.nativ.NativeExpressADView"

    aput-object v6, v2, v0

    aput-object v5, v2, v3

    const/16 v6, 0x14

    aput-object v2, v1, v6

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.kwad.components.ad.reward.KsRewardVideoAdControl"

    aput-object v6, v2, v0

    aput-object v5, v2, v3

    const/16 v6, 0x15

    aput-object v2, v1, v6

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.kwad.components.ad.splashscreen.KsSplashScreenAdControl"

    aput-object v6, v2, v0

    aput-object v5, v2, v3

    const/16 v6, 0x16

    aput-object v2, v1, v6

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.kwad.components.ad.b"

    aput-object v6, v2, v0

    aput-object v5, v2, v3

    const/16 v6, 0x17

    aput-object v2, v1, v6

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.kwad.components.ad.c.h"

    aput-object v6, v2, v0

    aput-object v5, v2, v3

    const/16 v6, 0x18

    aput-object v2, v1, v6

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.kwad.components.ad.draw.c"

    aput-object v6, v2, v0

    aput-object v5, v2, v3

    const/16 v6, 0x19

    aput-object v2, v1, v6

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.kwad.components.ad.feed.c"

    aput-object v6, v2, v0

    aput-object v5, v2, v3

    const/16 v6, 0x1a

    aput-object v2, v1, v6

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.kwad.components.ad.nativead.d"

    aput-object v6, v2, v0

    aput-object v5, v2, v3

    const/16 v5, 0x1b

    aput-object v2, v1, v5

    new-array v2, v4, [Ljava/lang/String;

    const-string v5, "com.sigmob.windad.Splash.WindSplashAD"

    aput-object v5, v2, v0

    const-string v5, "getEcpm"

    aput-object v5, v2, v3

    const/16 v6, 0x1c

    aput-object v2, v1, v6

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.sigmob.windad.natives.WindNativeUnifiedAd"

    aput-object v6, v2, v0

    aput-object v5, v2, v3

    const/16 v6, 0x1d

    aput-object v2, v1, v6

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.sigmob.windad.natives.WindNativeAdData"

    aput-object v6, v2, v0

    aput-object v5, v2, v3

    const/16 v6, 0x1e

    aput-object v2, v1, v6

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.sigmob.sdk.base.m"

    aput-object v6, v2, v0

    aput-object v5, v2, v3

    const/16 v6, 0x1f

    aput-object v2, v1, v6

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.sigmob.sdk.c"

    aput-object v6, v2, v0

    aput-object v5, v2, v3

    const/16 v6, 0x20

    aput-object v2, v1, v6

    new-array v2, v4, [Ljava/lang/String;

    const-string v6, "com.sigmob.sdk.nativead.ag"

    aput-object v6, v2, v0

    aput-object v5, v2, v3

    const/16 v6, 0x21

    aput-object v2, v1, v6

    new-array v2, v4, [Ljava/lang/String;

    const-string v4, "com.bytedance.sdk.openadsdk.mediation.manager.MediationAdEcpmInfo"

    aput-object v4, v2, v0

    aput-object v5, v2, v3

    const/16 v0, 0x22

    aput-object v2, v1, v0

    sput-object v1, Lnn/ecpm/EcpmHook;->RAW:[[Ljava/lang/String;

    .line 132
    invoke-static {}, Lnn/ecpm/EcpmHook;->buildTargets()[Lnn/ecpm/EcpmHook$Target;

    move-result-object v0

    sput-object v0, Lnn/ecpm/EcpmHook;->TARGETS:[Lnn/ecpm/EcpmHook$Target;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 35
    const-wide/32 v0, 0x186a0

    iput-wide v0, p0, Lnn/ecpm/EcpmHook;->ecpmMin:J

    .line 36
    const-wide/32 v0, 0x1fbd0

    iput-wide v0, p0, Lnn/ecpm/EcpmHook;->ecpmMax:J

    .line 37
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnn/ecpm/EcpmHook;->skipNonPositive:Z

    .line 38
    const/4 v0, 0x0

    iput v0, p0, Lnn/ecpm/EcpmHook;->configAttempts:I

    .line 39
    const-string v1, ""

    iput-object v1, p0, Lnn/ecpm/EcpmHook;->pkgName:Ljava/lang/String;

    .line 40
    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    iput-object v1, p0, Lnn/ecpm/EcpmHook;->random:Ljava/util/Random;

    .line 41
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    iput-object v1, p0, Lnn/ecpm/EcpmHook;->counters:Ljava/util/Map;

    .line 44
    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    invoke-static {v1}, Ljava/util/Collections;->synchronizedSet(Ljava/util/Set;)Ljava/util/Set;

    move-result-object v1

    iput-object v1, p0, Lnn/ecpm/EcpmHook;->hookedKeys:Ljava/util/Set;

    .line 46
    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    invoke-static {v1}, Ljava/util/Collections;->synchronizedSet(Ljava/util/Set;)Ljava/util/Set;

    move-result-object v1

    iput-object v1, p0, Lnn/ecpm/EcpmHook;->scannedClasses:Ljava/util/Set;

    .line 48
    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    invoke-static {v1}, Ljava/util/Collections;->synchronizedSet(Ljava/util/Set;)Ljava/util/Set;

    move-result-object v1

    iput-object v1, p0, Lnn/ecpm/EcpmHook;->firstCalls:Ljava/util/Set;

    .line 49
    iput v0, p0, Lnn/ecpm/EcpmHook;->hookedCount:I

    return-void
.end method

.method static synthetic access$000(Lnn/ecpm/EcpmHook;)Z
    .locals 1
    .param p0, "x0"    # Lnn/ecpm/EcpmHook;

    .line 24
    invoke-direct {p0}, Lnn/ecpm/EcpmHook;->loadConfig()Z

    move-result v0

    return v0
.end method

.method static synthetic access$100()[Lnn/ecpm/EcpmHook$Target;
    .locals 1

    .line 24
    sget-object v0, Lnn/ecpm/EcpmHook;->TARGETS:[Lnn/ecpm/EcpmHook$Target;

    return-object v0
.end method

.method static synthetic access$200(Lnn/ecpm/EcpmHook;Lnn/ecpm/EcpmHook$Target;Ljava/lang/ClassLoader;)Z
    .locals 1
    .param p0, "x0"    # Lnn/ecpm/EcpmHook;
    .param p1, "x1"    # Lnn/ecpm/EcpmHook$Target;
    .param p2, "x2"    # Ljava/lang/ClassLoader;

    .line 24
    invoke-direct {p0, p1, p2}, Lnn/ecpm/EcpmHook;->hookGetter(Lnn/ecpm/EcpmHook$Target;Ljava/lang/ClassLoader;)Z

    move-result v0

    return v0
.end method

.method static synthetic access$300(Lnn/ecpm/EcpmHook;Ljava/lang/ClassLoader;)Z
    .locals 1
    .param p0, "x0"    # Lnn/ecpm/EcpmHook;
    .param p1, "x1"    # Ljava/lang/ClassLoader;

    .line 24
    invoke-direct {p0, p1}, Lnn/ecpm/EcpmHook;->hookBaiduUtil(Ljava/lang/ClassLoader;)Z

    move-result v0

    return v0
.end method

.method static synthetic access$400(Lnn/ecpm/EcpmHook;)I
    .locals 1
    .param p0, "x0"    # Lnn/ecpm/EcpmHook;

    .line 24
    iget v0, p0, Lnn/ecpm/EcpmHook;->hookedCount:I

    return v0
.end method

.method static synthetic access$500(Lnn/ecpm/EcpmHook;)J
    .locals 2
    .param p0, "x0"    # Lnn/ecpm/EcpmHook;

    .line 24
    iget-wide v0, p0, Lnn/ecpm/EcpmHook;->ecpmMin:J

    return-wide v0
.end method

.method static synthetic access$600(Lnn/ecpm/EcpmHook;)J
    .locals 2
    .param p0, "x0"    # Lnn/ecpm/EcpmHook;

    .line 24
    iget-wide v0, p0, Lnn/ecpm/EcpmHook;->ecpmMax:J

    return-wide v0
.end method

.method static synthetic access$700(Lnn/ecpm/EcpmHook;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lnn/ecpm/EcpmHook;
    .param p1, "x1"    # Ljava/lang/String;

    .line 24
    invoke-direct {p0, p1}, Lnn/ecpm/EcpmHook;->emit(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$800(Lnn/ecpm/EcpmHook;Ljava/lang/Class;)V
    .locals 0
    .param p0, "x0"    # Lnn/ecpm/EcpmHook;
    .param p1, "x1"    # Ljava/lang/Class;

    .line 24
    invoke-direct {p0, p1}, Lnn/ecpm/EcpmHook;->scanClass(Ljava/lang/Class;)V

    return-void
.end method

.method static synthetic access$900(Lnn/ecpm/EcpmHook;Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lnn/ecpm/EcpmHook;
    .param p1, "x1"    # Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;
    .param p2, "x2"    # Ljava/lang/String;

    .line 24
    invoke-direct {p0, p1, p2}, Lnn/ecpm/EcpmHook;->apply(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;Ljava/lang/String;)V

    return-void
.end method

.method private apply(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;Ljava/lang/String;)V
    .locals 10
    .param p1, "param"    # Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;
    .param p2, "tag"    # Ljava/lang/String;

    .line 448
    iget-object v0, p1, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->method:Ljava/lang/reflect/Member;

    instance-of v0, v0, Ljava/lang/reflect/Method;

    if-eqz v0, :cond_0

    .line 449
    iget-object v0, p1, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->method:Ljava/lang/reflect/Member;

    check-cast v0, Ljava/lang/reflect/Method;

    invoke-virtual {v0}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    move-result-object v0

    goto :goto_0

    :cond_0
    sget-object v0, Ljava/lang/Void;->TYPE:Ljava/lang/Class;

    .line 450
    .local v0, "rt":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    :goto_0
    invoke-virtual {p1}, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->getResult()Ljava/lang/Object;

    move-result-object v1

    .line 454
    .local v1, "res":Ljava/lang/Object;
    iget-object v2, p1, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->method:Ljava/lang/reflect/Member;

    instance-of v2, v2, Ljava/lang/reflect/Method;

    if-eqz v2, :cond_1

    .line 456
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p1, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->method:Ljava/lang/reflect/Member;

    check-cast v3, Ljava/lang/reflect/Method;

    .line 455
    invoke-virtual {v3}, Ljava/lang/reflect/Method;->getDeclaringClass()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p1, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->method:Ljava/lang/reflect/Member;

    check-cast v3, Ljava/lang/reflect/Method;

    .line 456
    invoke-virtual {v3}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_1

    .line 457
    :cond_1
    move-object v2, p2

    :goto_1
    nop

    .line 458
    .local v2, "realKey":Ljava/lang/String;
    iget-object v3, p0, Lnn/ecpm/EcpmHook;->firstCalls:Ljava/util/Set;

    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    .line 459
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u89e6\u53d1 "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " | \u539f\u59cb\u503c="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " | \u8fd4\u56de\u7c7b\u578b="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    .line 460
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 459
    invoke-direct {p0, v3}, Lnn/ecpm/EcpmHook;->emit(Ljava/lang/String;)V

    .line 463
    :cond_2
    const-class v3, Ljava/lang/String;

    const-wide/16 v4, 0x0

    if-ne v0, v3, :cond_6

    .line 464
    if-nez v1, :cond_3

    const-string v3, ""

    goto :goto_2

    :cond_3
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    .line 465
    .local v3, "s":Ljava/lang/String;
    :goto_2
    invoke-static {v3}, Lnn/ecpm/EcpmHook;->isNumStr(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_4

    return-void

    .line 466
    :cond_4
    iget-boolean v6, p0, Lnn/ecpm/EcpmHook;->skipNonPositive:Z

    if-eqz v6, :cond_5

    invoke-static {v3}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v6

    cmpl-double v4, v6, v4

    if-lez v4, :skipret_1

    goto :cond_5

    :skipret_1
    return-void

    .line 467
    :cond_5
    invoke-direct {p0}, Lnn/ecpm/EcpmHook;->next()J

    move-result-wide v4

    .line 468
    .local v4, "v":J
    invoke-static {v4, v5}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v6

    invoke-direct {p0, p2, v3, v6}, Lnn/ecpm/EcpmHook;->logMod(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 469
    invoke-static {v4, v5}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->setResult(Ljava/lang/Object;)V

    .line 470
    .end local v3    # "s":Ljava/lang/String;
    .end local v4    # "v":J
    goto/16 :goto_6

    :cond_6
    sget-object v3, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    if-eq v0, v3, :cond_14

    const-class v3, Ljava/lang/Integer;

    if-ne v0, v3, :cond_7

    goto/16 :goto_5

    .line 477
    :cond_7
    sget-object v3, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    if-eq v0, v3, :cond_11

    const-class v3, Ljava/lang/Long;

    if-ne v0, v3, :cond_8

    goto :goto_4

    .line 484
    :cond_8
    sget-object v3, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    if-eq v0, v3, :cond_d

    const-class v3, Ljava/lang/Double;

    if-ne v0, v3, :cond_9

    goto :goto_3

    .line 491
    :cond_9
    sget-object v3, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    if-eq v0, v3, :cond_a

    const-class v3, Ljava/lang/Float;

    if-ne v0, v3, :cond_10

    .line 492
    :cond_a
    if-nez v1, :cond_b

    return-void

    .line 493
    :cond_b
    invoke-static {v1}, Lnn/ecpm/EcpmHook;->toDouble(Ljava/lang/Object;)D

    move-result-wide v6

    .line 494
    .local v6, "d":D
    iget-boolean v3, p0, Lnn/ecpm/EcpmHook;->skipNonPositive:Z

    if-eqz v3, :cond_c

    cmpl-double v3, v6, v4

    if-lez v3, :skipret_2

    goto :cond_c

    :skipret_2
    return-void

    .line 495
    :cond_c
    invoke-direct {p0}, Lnn/ecpm/EcpmHook;->next()J

    move-result-wide v3

    .line 496
    .local v3, "v":J
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v8

    invoke-direct {p0, p2, v5, v8}, Lnn/ecpm/EcpmHook;->logMod(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 497
    long-to-float v5, v3

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    invoke-virtual {p1, v5}, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->setResult(Ljava/lang/Object;)V

    goto/16 :goto_6

    .line 485
    .end local v3    # "v":J
    .end local v6    # "d":D
    :cond_d
    :goto_3
    if-nez v1, :cond_e

    return-void

    .line 486
    :cond_e
    invoke-static {v1}, Lnn/ecpm/EcpmHook;->toDouble(Ljava/lang/Object;)D

    move-result-wide v6

    .line 487
    .restart local v6    # "d":D
    iget-boolean v3, p0, Lnn/ecpm/EcpmHook;->skipNonPositive:Z

    if-eqz v3, :cond_f

    cmpl-double v3, v6, v4

    if-lez v3, :skipret_3

    goto :cond_f

    :skipret_3
    return-void

    .line 488
    :cond_f
    invoke-direct {p0}, Lnn/ecpm/EcpmHook;->next()J

    move-result-wide v3

    .line 489
    .restart local v3    # "v":J
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v8

    invoke-direct {p0, p2, v5, v8}, Lnn/ecpm/EcpmHook;->logMod(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 490
    long-to-double v8, v3

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    invoke-virtual {p1, v5}, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->setResult(Ljava/lang/Object;)V

    .line 491
    .end local v3    # "v":J
    .end local v6    # "d":D
    :cond_10
    goto :goto_6

    .line 478
    :cond_11
    :goto_4
    if-nez v1, :cond_12

    return-void

    .line 479
    :cond_12
    invoke-static {v1}, Lnn/ecpm/EcpmHook;->toDouble(Ljava/lang/Object;)D

    move-result-wide v6

    .line 480
    .restart local v6    # "d":D
    iget-boolean v3, p0, Lnn/ecpm/EcpmHook;->skipNonPositive:Z

    if-eqz v3, :cond_13

    cmpl-double v3, v6, v4

    if-lez v3, :skipret_4

    goto :cond_13

    :skipret_4
    return-void

    .line 481
    :cond_13
    invoke-direct {p0}, Lnn/ecpm/EcpmHook;->next()J

    move-result-wide v3

    .line 482
    .restart local v3    # "v":J
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v8

    invoke-direct {p0, p2, v5, v8}, Lnn/ecpm/EcpmHook;->logMod(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 483
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    invoke-virtual {p1, v5}, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->setResult(Ljava/lang/Object;)V

    .line 484
    .end local v3    # "v":J
    .end local v6    # "d":D
    goto :goto_6

    .line 471
    :cond_14
    :goto_5
    if-nez v1, :cond_15

    return-void

    .line 472
    :cond_15
    invoke-static {v1}, Lnn/ecpm/EcpmHook;->toDouble(Ljava/lang/Object;)D

    move-result-wide v6

    .line 473
    .restart local v6    # "d":D
    iget-boolean v3, p0, Lnn/ecpm/EcpmHook;->skipNonPositive:Z

    if-eqz v3, :cond_16

    cmpl-double v3, v6, v4

    if-lez v3, :skipret_5

    goto :cond_16

    :skipret_5
    return-void

    .line 474
    :cond_16
    invoke-direct {p0}, Lnn/ecpm/EcpmHook;->next()J

    move-result-wide v3

    .line 475
    .restart local v3    # "v":J
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v8

    invoke-direct {p0, p2, v5, v8}, Lnn/ecpm/EcpmHook;->logMod(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 476
    invoke-static {v3, v4}, Lnn/ecpm/EcpmHook;->clampInt(J)I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {p1, v5}, Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;->setResult(Ljava/lang/Object;)V

    .line 477
    .end local v3    # "v":J
    .end local v6    # "d":D
    nop

    .line 499
    :goto_6
    return-void
.end method

.method private static buildTargets()[Lnn/ecpm/EcpmHook$Target;
    .locals 6

    .line 135
    sget-object v0, Lnn/ecpm/EcpmHook;->RAW:[[Ljava/lang/String;

    array-length v0, v0

    new-array v0, v0, [Lnn/ecpm/EcpmHook$Target;

    .line 136
    .local v0, "arr":[Lnn/ecpm/EcpmHook$Target;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    sget-object v2, Lnn/ecpm/EcpmHook;->RAW:[[Ljava/lang/String;

    array-length v3, v2

    if-ge v1, v3, :cond_0

    .line 137
    new-instance v3, Lnn/ecpm/EcpmHook$Target;

    aget-object v2, v2, v1

    const/4 v4, 0x0

    aget-object v4, v2, v4

    const/4 v5, 0x1

    aget-object v2, v2, v5

    invoke-direct {v3, v4, v2}, Lnn/ecpm/EcpmHook$Target;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    aput-object v3, v0, v1

    .line 136
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 139
    .end local v1    # "i":I
    :cond_0
    return-object v0
.end method

.method private static clampInt(J)I
    .locals 2
    .param p0, "v"    # J

    .line 508
    const-wide/32 v0, 0x7fffffff

    cmp-long v0, p0, v0

    if-lez v0, :cond_0

    const v0, 0x7fffffff

    return v0

    .line 509
    :cond_0
    const-wide/32 v0, -0x80000000

    cmp-long v0, p0, v0

    if-gez v0, :cond_1

    const/high16 v0, -0x80000000

    return v0

    .line 510
    :cond_1
    long-to-int v0, p0

    return v0
.end method

.method private doHook(Ljava/lang/reflect/Method;Ljava/lang/String;)V
    .locals 4
    .param p1, "m"    # Ljava/lang/reflect/Method;
    .param p2, "tag"    # Ljava/lang/String;

    .line 382
    invoke-virtual {p1}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    move-result-object v0

    invoke-static {v0}, Lnn/ecpm/EcpmHook;->isCountableReturn(Ljava/lang/Class;)Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 383
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1}, Ljava/lang/reflect/Method;->getDeclaringClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p1}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 384
    .local v0, "key":Ljava/lang/String;
    iget-object v1, p0, Lnn/ecpm/EcpmHook;->hookedKeys:Ljava/util/Set;

    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    return-void

    .line 386
    :cond_1
    :try_start_0
    new-instance v1, Lnn/ecpm/EcpmHook$3;

    invoke-direct {v1, p0, p2}, Lnn/ecpm/EcpmHook$3;-><init>(Lnn/ecpm/EcpmHook;Ljava/lang/String;)V

    invoke-static {p1, v1}, Lde/robv/android/xposed/XposedBridge;->hookMethod(Ljava/lang/reflect/Member;Lde/robv/android/xposed/XC_MethodHook;)Lde/robv/android/xposed/XC_MethodHook$Unhook;

    .line 392
    iget v1, p0, Lnn/ecpm/EcpmHook;->hookedCount:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lnn/ecpm/EcpmHook;->hookedCount:I

    .line 393
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\u5df2\u6302\u94a9 "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " ("

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lnn/ecpm/EcpmHook;->emit(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 396
    goto :goto_0

    .line 394
    :catchall_0
    move-exception v1

    .line 395
    .local v1, "e":Ljava/lang/Throwable;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "hook \u5931\u8d25: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " -> "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lnn/ecpm/EcpmHook;->emit(Ljava/lang/String;)V

    .line 397
    .end local v1    # "e":Ljava/lang/Throwable;
    :goto_0
    return-void
.end method

.method private emit(Ljava/lang/String;)V
    .locals 5
    .param p1, "msg"    # Ljava/lang/String;

    .line 540
    const-string v0, "msg"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "[EcpmRange] "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lde/robv/android/xposed/XposedBridge;->log(Ljava/lang/String;)V

    .line 542
    :try_start_0
    invoke-static {}, Lnn/ecpm/EcpmHook;->getAppContext()Landroid/content/Context;

    move-result-object v1

    .line 543
    .local v1, "ctx":Landroid/content/Context;
    if-eqz v1, :cond_0

    .line 544
    new-instance v2, Landroid/content/Intent;

    const-string v3, "nn.ecpm.LOG"

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 545
    .local v2, "i":Landroid/content/Intent;
    const-string v3, "nn.ecpm"

    invoke-virtual {v2, v3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 546
    invoke-virtual {v2, v0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 547
    invoke-virtual {v1, v2}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    .line 549
    new-instance v3, Landroid/content/ContentValues;

    invoke-direct {v3}, Landroid/content/ContentValues;-><init>()V

    .line 550
    .local v3, "cv":Landroid/content/ContentValues;
    invoke-virtual {v3, v0, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 551
    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string v4, "content://nn.ecpm.config/log"

    .line 552
    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    .line 551
    invoke-virtual {v0, v4, v3}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 555
    .end local v1    # "ctx":Landroid/content/Context;
    .end local v2    # "i":Landroid/content/Intent;
    .end local v3    # "cv":Landroid/content/ContentValues;
    :cond_0
    goto :goto_0

    .line 554
    :catchall_0
    move-exception v0

    .line 556
    :goto_0
    return-void
.end method

.method private static findMethod(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Method;
    .locals 6
    .param p1, "name"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;",
            "Ljava/lang/String;",
            ")",
            "Ljava/lang/reflect/Method;"
        }
    .end annotation

    .line 434
    .local p0, "c":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    move-object v0, p0

    .line 435
    .local v0, "cur":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    :goto_0
    if-eqz v0, :cond_2

    .line 436
    invoke-virtual {v0}, Ljava/lang/Class;->getDeclaredMethods()[Ljava/lang/reflect/Method;

    move-result-object v1

    array-length v2, v1

    const/4 v3, 0x0

    :goto_1
    if-ge v3, v2, :cond_1

    aget-object v4, v1, v3

    .line 437
    .local v4, "m":Ljava/lang/reflect/Method;
    invoke-virtual {v4}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    invoke-virtual {v4}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v5

    array-length v5, v5

    if-nez v5, :cond_0

    .line 438
    return-object v4

    .line 436
    .end local v4    # "m":Ljava/lang/reflect/Method;
    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    .line 441
    :cond_1
    invoke-virtual {v0}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object v0

    goto :goto_0

    .line 443
    :cond_2
    const/4 v1, 0x0

    return-object v1
.end method

.method private static getAppContext()Landroid/content/Context;
    .locals 4

    .line 567
    const/4 v0, 0x0

    :try_start_0
    const-string v1, "android.app.ActivityThread"

    invoke-static {v1, v0}, Lde/robv/android/xposed/XposedHelpers;->findClass(Ljava/lang/String;Ljava/lang/ClassLoader;)Ljava/lang/Class;

    move-result-object v1

    .line 568
    .local v1, "at":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    const-string v2, "currentApplication"

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    invoke-static {v1, v2, v3}, Lde/robv/android/xposed/XposedHelpers;->callStaticMethod(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .line 569
    .local v2, "app":Ljava/lang/Object;
    instance-of v3, v2, Landroid/content/Context;

    if-eqz v3, :cond_0

    .line 570
    move-object v3, v2

    check-cast v3, Landroid/content/Context;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v3

    .line 573
    .end local v1    # "at":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    .end local v2    # "app":Ljava/lang/Object;
    :cond_0
    goto :goto_0

    .line 572
    :catchall_0
    move-exception v1

    .line 574
    :goto_0
    return-object v0
.end method

.method private hookBaiduUtil(Ljava/lang/ClassLoader;)Z
    .locals 6
    .param p1, "cl"    # Ljava/lang/ClassLoader;

    .line 411
    const/4 v0, 0x0

    :try_start_0
    const-string v1, "com.bytedance.msdk.adapter.baidu.BaiduAdapterUtil"

    invoke-static {v1, p1}, Lde/robv/android/xposed/XposedHelpers;->findClass(Ljava/lang/String;Ljava/lang/ClassLoader;)Ljava/lang/Class;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 414
    .local v1, "c":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    nop

    .line 416
    const/4 v2, 0x1

    :try_start_1
    const-string v3, "getEcpm"

    new-array v4, v2, [Ljava/lang/Class;

    const-class v5, Ljava/util/Map;

    aput-object v5, v4, v0

    .line 417
    invoke-static {v1, v3, v4}, Lde/robv/android/xposed/XposedHelpers;->findMethodExact(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    new-instance v3, Lnn/ecpm/EcpmHook$4;

    invoke-direct {v3, p0}, Lnn/ecpm/EcpmHook$4;-><init>(Lnn/ecpm/EcpmHook;)V

    .line 416
    invoke-static {v0, v3}, Lde/robv/android/xposed/XposedBridge;->hookMethod(Ljava/lang/reflect/Member;Lde/robv/android/xposed/XC_MethodHook;)Lde/robv/android/xposed/XC_MethodHook$Unhook;

    .line 424
    iget v0, p0, Lnn/ecpm/EcpmHook;->hookedCount:I

    add-int/2addr v0, v2

    iput v0, p0, Lnn/ecpm/EcpmHook;->hookedCount:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 425
    return v2

    .line 426
    :catchall_0
    move-exception v0

    .line 427
    .local v0, "e":Ljava/lang/Throwable;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "BaiduAdapterUtil hook \u5931\u8d25: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {p0, v3}, Lnn/ecpm/EcpmHook;->emit(Ljava/lang/String;)V

    .line 428
    return v2

    .line 412
    .end local v0    # "e":Ljava/lang/Throwable;
    .end local v1    # "c":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    :catchall_1
    move-exception v1

    .line 413
    .local v1, "e":Ljava/lang/Throwable;
    return v0
.end method

.method private hookGetter(Lnn/ecpm/EcpmHook$Target;Ljava/lang/ClassLoader;)Z
    .locals 5
    .param p1, "tgt"    # Lnn/ecpm/EcpmHook$Target;
    .param p2, "cl"    # Ljava/lang/ClassLoader;

    .line 284
    :try_start_0
    iget-object v0, p1, Lnn/ecpm/EcpmHook$Target;->fqcn:Ljava/lang/String;

    invoke-static {v0, p2}, Lde/robv/android/xposed/XposedHelpers;->findClass(Ljava/lang/String;Ljava/lang/ClassLoader;)Ljava/lang/Class;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 287
    .local v0, "c":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    nop

    .line 288
    invoke-virtual {v0}, Ljava/lang/Class;->isInterface()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    return v2

    .line 290
    :cond_0
    iget-object v1, p1, Lnn/ecpm/EcpmHook$Target;->method:Ljava/lang/String;

    invoke-static {v0, v1}, Lnn/ecpm/EcpmHook;->findMethod(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Method;

    move-result-object v1

    .line 291
    .local v1, "m":Ljava/lang/reflect/Method;
    if-nez v1, :cond_1

    return v2

    .line 292
    :cond_1
    invoke-virtual {v1}, Ljava/lang/reflect/Method;->getModifiers()I

    move-result v3

    invoke-static {v3}, Ljava/lang/reflect/Modifier;->isAbstract(I)Z

    move-result v3

    if-eqz v3, :cond_2

    .line 293
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u8df3\u8fc7\u62bd\u8c61\u65b9\u6cd5: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p1, Lnn/ecpm/EcpmHook$Target;->fqcn:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "."

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p1, Lnn/ecpm/EcpmHook$Target;->method:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "\uff08\u65e0\u65b9\u6cd5\u4f53\uff0c\u9700\u7531\u5b9e\u73b0\u7c7b\u8986\u76d6\uff09"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {p0, v3}, Lnn/ecpm/EcpmHook;->emit(Ljava/lang/String;)V

    .line 294
    return v2

    .line 296
    :cond_2
    iget-object v3, p1, Lnn/ecpm/EcpmHook$Target;->tag:Ljava/lang/String;

    invoke-direct {p0, v1, v3}, Lnn/ecpm/EcpmHook;->doHook(Ljava/lang/reflect/Method;Ljava/lang/String;)V

    .line 297
    return v2

    .line 285
    .end local v0    # "c":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    .end local v1    # "m":Ljava/lang/reflect/Method;
    :catchall_0
    move-exception v0

    .line 286
    .local v0, "e":Ljava/lang/Throwable;
    const/4 v1, 0x0

    return v1
.end method

.method private installScanner(Ljava/lang/ClassLoader;)V
    .locals 3
    .param p1, "cl"    # Ljava/lang/ClassLoader;

    .line 306
    :try_start_0
    const-string v0, "java.lang.ClassLoader"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lde/robv/android/xposed/XposedHelpers;->findClass(Ljava/lang/String;Ljava/lang/ClassLoader;)Ljava/lang/Class;

    move-result-object v0

    .line 307
    .local v0, "clsLoader":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    const-string v1, "loadClass"

    new-instance v2, Lnn/ecpm/EcpmHook$2;

    invoke-direct {v2, p0}, Lnn/ecpm/EcpmHook$2;-><init>(Lnn/ecpm/EcpmHook;)V

    invoke-static {v0, v1, v2}, Lde/robv/android/xposed/XposedBridge;->hookAllMethods(Ljava/lang/Class;Ljava/lang/String;Lde/robv/android/xposed/XC_MethodHook;)Ljava/util/Set;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 320
    nop

    .end local v0    # "clsLoader":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    goto :goto_0

    .line 319
    :catchall_0
    move-exception v0

    .line 321
    :goto_0
    return-void
.end method

.method private static isAdKeywordPackage(Ljava/lang/String;)Z
    .locals 2
    .param p0, "cn"    # Ljava/lang/String;

    .line 366
    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    .line 367
    .local v0, "n":Ljava/lang/String;
    const-string v1, "ads"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, ".ad."

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "monet"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    .line 368
    const-string v1, "reward"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "mediation"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "msdk"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    .line 369
    const-string v1, "bid"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "adx"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "splash"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    .line 370
    const-string v1, "cpm"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "ecpm"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "advert"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "promo"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "offer"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "campaign"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "traffic"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "yield"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "auction"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "rtb"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "dsp"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "ssp"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "waterfall"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "placement"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "revenue"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "mraid"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "vast"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "interstitial"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "banner"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "nativead"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x1

    .line 367
    :goto_1
    return v1
.end method

.method private static isAdPackage(Ljava/lang/String;)Z
    .locals 6
    .param p0, "cn"    # Ljava/lang/String;

    .line 374
    sget-object v0, Lnn/ecpm/EcpmHook;->SDK_PREFIXES:[Ljava/lang/String;

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    if-ge v3, v1, :cond_1

    aget-object v4, v0, v3

    .line 375
    .local v4, "p":Ljava/lang/String;
    invoke-virtual {p0, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v0, 0x1

    return v0

    .line 374
    .end local v4    # "p":Ljava/lang/String;
    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 377
    :cond_1
    return v2
.end method

.method private static isCountableReturn(Ljava/lang/Class;)Z
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)Z"
        }
    .end annotation

    .line 400
    .local p0, "rt":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    const-class v0, Ljava/lang/String;

    if-eq p0, v0, :cond_1

    sget-object v0, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    if-eq p0, v0, :cond_1

    const-class v0, Ljava/lang/Integer;

    if-eq p0, v0, :cond_1

    sget-object v0, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    if-eq p0, v0, :cond_1

    const-class v0, Ljava/lang/Long;

    if-eq p0, v0, :cond_1

    sget-object v0, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    if-eq p0, v0, :cond_1

    const-class v0, Ljava/lang/Double;

    if-eq p0, v0, :cond_1

    sget-object v0, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    if-eq p0, v0, :cond_1

    const-class v0, Ljava/lang/Float;

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method private static isEcpmMethod(Ljava/lang/String;)Z
    .locals 2
    .param p0, "name"    # Ljava/lang/String;

    .line 361
    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const-string v1, "cpm"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    return v0
.end method

.method private static isNumStr(Ljava/lang/String;)Z
    .locals 1
    .param p0, "s"    # Ljava/lang/String;

    .line 523
    if-eqz p0, :cond_0

    const-string v0, "[+-]?(\\d+(\\.\\d*)?|\\.\\d+)"

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private loadConfig()Z
    .locals 13

    .line 156
    iget v0, p0, Lnn/ecpm/EcpmHook;->configAttempts:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, Lnn/ecpm/EcpmHook;->configAttempts:I

    .line 157
    invoke-static {}, Lnn/ecpm/EcpmHook;->getAppContext()Landroid/content/Context;

    move-result-object v0

    .line 158
    .local v0, "ctx":Landroid/content/Context;
    const/4 v2, 0x0

    if-nez v0, :cond_0

    .line 159
    const-string v1, "\u5e94\u7528 Context \u5c1a\u672a\u5c31\u7eea\uff08\u7a0d\u540e\u91cd\u8bd5\uff09"

    invoke-direct {p0, v1}, Lnn/ecpm/EcpmHook;->onConfigFail(Ljava/lang/String;)V

    .line 160
    return v2

    .line 163
    :cond_0
    :try_start_0
    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    const-string v4, "content://nn.ecpm.config/config"

    .line 164
    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    .line 163
    invoke-virtual/range {v3 .. v8}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v3

    .line 166
    .local v3, "c":Landroid/database/Cursor;
    if-nez v3, :cond_1

    .line 167
    const-string v1, "Provider \u672a\u8fd4\u56de\u6570\u636e"

    invoke-direct {p0, v1}, Lnn/ecpm/EcpmHook;->onConfigFail(Ljava/lang/String;)V

    .line 168
    return v2

    .line 170
    :cond_1
    iget-wide v4, p0, Lnn/ecpm/EcpmHook;->ecpmMin:J

    .line 171
    .local v4, "min":J
    iget-wide v6, p0, Lnn/ecpm/EcpmHook;->ecpmMax:J

    .line 172
    .local v6, "max":J
    iget-boolean v8, p0, Lnn/ecpm/EcpmHook;->skipNonPositive:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 174
    .local v8, "skip":Z
    :goto_0
    :try_start_1
    invoke-interface {v3}, Landroid/database/Cursor;->moveToNext()Z

    move-result v9

    if-eqz v9, :cond_5

    .line 175
    invoke-interface {v3, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v9

    .line 176
    .local v9, "k":Ljava/lang/String;
    invoke-interface {v3, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v10

    .line 177
    .local v10, "v":Ljava/lang/String;
    const-string v11, "min"

    invoke-virtual {v11, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_2

    .line 178
    invoke-static {v10}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v11

    move-wide v4, v11

    goto :goto_1

    .line 179
    :cond_2
    const-string v11, "max"

    invoke-virtual {v11, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_3

    .line 180
    invoke-static {v10}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v11

    move-wide v6, v11

    goto :goto_1

    .line 181
    :cond_3
    const-string v11, "skip"

    invoke-virtual {v11, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_4

    .line 182
    const-string v11, "1"

    invoke-virtual {v11, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move v8, v11

    .line 184
    .end local v9    # "k":Ljava/lang/String;
    .end local v10    # "v":Ljava/lang/String;
    :cond_4
    :goto_1
    goto :goto_0

    .line 186
    :cond_5
    :try_start_2
    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    .line 187
    nop

    .line 188
    iput-wide v4, p0, Lnn/ecpm/EcpmHook;->ecpmMin:J

    .line 189
    iput-wide v6, p0, Lnn/ecpm/EcpmHook;->ecpmMax:J

    .line 190
    iput-boolean v8, p0, Lnn/ecpm/EcpmHook;->skipNonPositive:Z

    .line 191
    invoke-direct {p0}, Lnn/ecpm/EcpmHook;->normalize()V

    .line 192
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "\u6ce8\u5165\u8fdb\u7a0b: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    iget-object v10, p0, Lnn/ecpm/EcpmHook;->pkgName:Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, " | \u914d\u7f6e\u8bfb\u53d6\u6210\u529f | \u533a\u95f4 ["

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    iget-wide v10, p0, Lnn/ecpm/EcpmHook;->ecpmMin:J

    invoke-virtual {v9, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, " ~ "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    iget-wide v10, p0, Lnn/ecpm/EcpmHook;->ecpmMax:J

    invoke-virtual {v9, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, "] (\u5206)"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    .line 194
    iget-boolean v10, p0, Lnn/ecpm/EcpmHook;->skipNonPositive:Z

    if-eqz v10, :cond_6

    const-string v10, " | \u8df3\u8fc7\u975e\u6b63\u6570"

    goto :goto_2

    :cond_6
    const-string v10, ""

    :goto_2
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    .line 192
    invoke-direct {p0, v9}, Lnn/ecpm/EcpmHook;->emit(Ljava/lang/String;)V

    .line 195
    return v1

    .line 186
    :catchall_0
    move-exception v1

    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    .line 187
    nop

    .end local v0    # "ctx":Landroid/content/Context;
    throw v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 196
    .end local v3    # "c":Landroid/database/Cursor;
    .end local v4    # "min":J
    .end local v6    # "max":J
    .end local v8    # "skip":Z
    .restart local v0    # "ctx":Landroid/content/Context;
    :catchall_1
    move-exception v1

    .line 197
    .local v1, "e":Ljava/lang/Throwable;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ": "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {p0, v3}, Lnn/ecpm/EcpmHook;->onConfigFail(Ljava/lang/String;)V

    .line 198
    return v2
.end method

.method private logMod(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 5
    .param p1, "key"    # Ljava/lang/String;
    .param p2, "from"    # Ljava/lang/String;
    .param p3, "to"    # Ljava/lang/String;

    .line 528
    iget-object v0, p0, Lnn/ecpm/EcpmHook;->counters:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    .line 529
    .local v0, "existed":Ljava/lang/Integer;
    const/4 v1, 0x1

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v2

    add-int/2addr v1, v2

    .line 530
    .local v1, "c":I
    :goto_0
    iget-object v2, p0, Lnn/ecpm/EcpmHook;->counters:Ljava/util/Map;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, p1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 531
    const/4 v2, 0x2

    const-string v3, " -> "

    if-gt v1, v2, :cond_1

    .line 532
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, ": "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lnn/ecpm/EcpmHook;->emit(Ljava/lang/String;)V

    goto :goto_1

    .line 533
    :cond_1
    rem-int/lit8 v2, v1, 0x64

    if-nez v2, :cond_2

    .line 534
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " \u7d2f\u8ba1"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, "\u6b21 (\u6700\u8fd1 "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lnn/ecpm/EcpmHook;->emit(Ljava/lang/String;)V

    .line 536
    :cond_2
    :goto_1
    return-void
.end method

.method private next()J
    .locals 8

    .line 502
    iget-wide v0, p0, Lnn/ecpm/EcpmHook;->ecpmMax:J

    iget-wide v2, p0, Lnn/ecpm/EcpmHook;->ecpmMin:J

    cmp-long v4, v0, v2

    if-gtz v4, :cond_0

    return-wide v2

    .line 503
    :cond_0
    sub-long/2addr v0, v2

    const-wide/16 v4, 0x1

    add-long/2addr v0, v4

    .line 504
    .local v0, "span":J
    iget-object v4, p0, Lnn/ecpm/EcpmHook;->random:Ljava/util/Random;

    invoke-virtual {v4}, Ljava/util/Random;->nextDouble()D

    move-result-wide v4

    long-to-double v6, v0

    mul-double/2addr v4, v6

    double-to-long v4, v4

    add-long/2addr v2, v4

    return-wide v2
.end method

.method private normalize()V
    .locals 4

    .line 210
    iget-wide v0, p0, Lnn/ecpm/EcpmHook;->ecpmMin:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-gez v0, :cond_0

    iput-wide v2, p0, Lnn/ecpm/EcpmHook;->ecpmMin:J

    .line 211
    :cond_0
    iget-wide v0, p0, Lnn/ecpm/EcpmHook;->ecpmMax:J

    cmp-long v0, v0, v2

    if-gez v0, :cond_1

    iput-wide v2, p0, Lnn/ecpm/EcpmHook;->ecpmMax:J

    .line 212
    :cond_1
    iget-wide v0, p0, Lnn/ecpm/EcpmHook;->ecpmMin:J

    const-wide/32 v2, 0x1e8480

    cmp-long v0, v0, v2

    if-lez v0, :cond_min_ok

    iput-wide v2, p0, Lnn/ecpm/EcpmHook;->ecpmMin:J

    :cond_min_ok
    iget-wide v0, p0, Lnn/ecpm/EcpmHook;->ecpmMax:J

    const-wide/32 v2, 0x1e8480

    cmp-long v0, v0, v2

    if-lez v0, :cond_max_ok

    iput-wide v2, p0, Lnn/ecpm/EcpmHook;->ecpmMax:J

    :cond_max_ok
    iget-wide v0, p0, Lnn/ecpm/EcpmHook;->ecpmMax:J

    iget-wide v2, p0, Lnn/ecpm/EcpmHook;->ecpmMin:J

    cmp-long v2, v0, v2

    if-gez v2, :cond_2

    .line 213
    iget-wide v2, p0, Lnn/ecpm/EcpmHook;->ecpmMin:J

    .line 214
    .local v2, "t":J
    iput-wide v0, p0, Lnn/ecpm/EcpmHook;->ecpmMin:J

    .line 215
    iput-wide v2, p0, Lnn/ecpm/EcpmHook;->ecpmMax:J

    .line 217
    .end local v2    # "t":J
    :cond_2
    return-void
.end method

.method private onConfigFail(Ljava/lang/String;)V
    .locals 2
    .param p1, "reason"    # Ljava/lang/String;

    .line 204
    iget v0, p0, Lnn/ecpm/EcpmHook;->configAttempts:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_0

    .line 205
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "\u8bfb\u53d6\u914d\u7f6e\u5931\u8d25\uff08\u5df2\u91cd\u8bd5"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lnn/ecpm/EcpmHook;->configAttempts:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\u6b21\uff09\uff1a"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lnn/ecpm/EcpmHook;->emit(Ljava/lang/String;)V

    .line 207
    :cond_0
    return-void
.end method

.method private scanClass(Ljava/lang/Class;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)V"
        }
    .end annotation

    .line 324
    .local p1, "c":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    .line 325
    .local v0, "cn":Ljava/lang/String;
    const-string v1, "java."

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_d

    const-string v1, "javax."

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_d

    .line 326
    const-string v1, "android."

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_d

    const-string v1, "com.android."

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_d

    .line 327
    const-string v1, "sun."

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_d

    const-string v1, "dalvik."

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto/16 :goto_5

    .line 330
    :cond_0
    invoke-static {v0}, Lnn/ecpm/EcpmHook;->isAdPackage(Ljava/lang/String;)Z

    move-result v1

    .line 331
    .local v1, "ad":Z
    const/4 v2, 0x0

    if-nez v1, :cond_2

    invoke-static {v0}, Lnn/ecpm/EcpmHook;->isAdKeywordPackage(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_1

    goto :goto_0

    :cond_1
    move v3, v2

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v3, 0x1

    .line 332
    .local v3, "maybe":Z
    :goto_1
    if-nez v3, :cond_3

    return-void

    .line 333
    :cond_3
    iget-object v4, p0, Lnn/ecpm/EcpmHook;->scannedClasses:Ljava/util/Set;

    invoke-interface {v4, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4

    return-void

    .line 336
    :cond_4
    new-instance v4, Ljava/util/HashSet;

    invoke-direct {v4}, Ljava/util/HashSet;-><init>()V

    .line 338
    .local v4, "names":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    :try_start_0
    invoke-virtual {p1}, Ljava/lang/Class;->getDeclaredMethods()[Ljava/lang/reflect/Method;

    move-result-object v5

    array-length v6, v5

    :goto_2
    if-ge v2, v6, :cond_7

    aget-object v7, v5, v2

    .line 339
    .local v7, "m":Ljava/lang/reflect/Method;
    invoke-virtual {v7}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v8

    array-length v8, v8

    if-eqz v8, :cond_5

    goto :goto_3

    .line 340
    :cond_5
    invoke-virtual {v7}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Lnn/ecpm/EcpmHook;->isEcpmMethod(Ljava/lang/String;)Z

    move-result v8

    if-nez v8, :cond_6

    goto :goto_3

    .line 341
    :cond_6
    invoke-virtual {v7}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v4, v8}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 338
    .end local v7    # "m":Ljava/lang/reflect/Method;
    :goto_3
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    .line 345
    :cond_7
    nop

    .line 346
    invoke-interface {v4}, Ljava/util/Set;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_8

    return-void

    .line 348
    :cond_8
    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_4
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_c

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 349
    .local v5, "name":Ljava/lang/String;
    invoke-static {p1, v5}, Lnn/ecpm/EcpmHook;->findMethod(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Method;

    move-result-object v6

    .line 350
    .local v6, "impl":Ljava/lang/reflect/Method;
    if-nez v6, :cond_9

    goto :goto_4

    .line 351
    :cond_9
    invoke-virtual {v6}, Ljava/lang/reflect/Method;->getModifiers()I

    move-result v7

    invoke-static {v7}, Ljava/lang/reflect/Modifier;->isAbstract(I)Z

    move-result v7

    if-eqz v7, :cond_a

    goto :goto_4

    .line 352
    :cond_a
    invoke-virtual {v6}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    move-result-object v7

    invoke-static {v7}, Lnn/ecpm/EcpmHook;->isCountableReturn(Ljava/lang/Class;)Z

    move-result v7

    if-nez v7, :cond_b

    goto :goto_4

    .line 353
    :cond_b
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6}, Ljava/lang/reflect/Method;->getDeclaringClass()Ljava/lang/Class;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "."

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {p0, v6, v7}, Lnn/ecpm/EcpmHook;->doHook(Ljava/lang/reflect/Method;Ljava/lang/String;)V

    .line 354
    .end local v5    # "name":Ljava/lang/String;
    .end local v6    # "impl":Ljava/lang/reflect/Method;
    goto :goto_4

    .line 355
    :cond_c
    return-void

    .line 343
    :catchall_0
    move-exception v2

    .line 344
    .local v2, "ignored":Ljava/lang/Throwable;
    return-void

    .line 328
    .end local v1    # "ad":Z
    .end local v2    # "ignored":Ljava/lang/Throwable;
    .end local v3    # "maybe":Z
    .end local v4    # "names":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    :cond_d
    :goto_5
    return-void
.end method

.method private startInstall(Ljava/lang/ClassLoader;)V
    .locals 2
    .param p1, "cl"    # Ljava/lang/ClassLoader;

    .line 223
    invoke-direct {p0, p1}, Lnn/ecpm/EcpmHook;->installScanner(Ljava/lang/ClassLoader;)V

    .line 224
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lnn/ecpm/EcpmHook$1;

    invoke-direct {v1, p0, p1}, Lnn/ecpm/EcpmHook$1;-><init>(Lnn/ecpm/EcpmHook;Ljava/lang/ClassLoader;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 275
    .local v0, "t":Ljava/lang/Thread;
    const-string v1, "EcpmRange-install"

    invoke-virtual {v0, v1}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    .line 276
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/Thread;->setDaemon(Z)V

    .line 277
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 278
    return-void
.end method

.method private static toDouble(Ljava/lang/Object;)D
    .locals 4
    .param p0, "o"    # Ljava/lang/Object;

    :try_start_0
    instance-of v0, p0, Ljava/lang/Number;

    if-eqz v0, :cond_0

    move-object v0, p0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v0

    goto :guard

    :cond_0
    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    :guard
    const-wide/16 v2, 0x0

    cmpl-double v2, v0, v2

    if-lez v2, :bad

    const-wide v2, 0x412e848000000000L    # 1000000.0

    cmpg-double v2, v0, v2

    if-gez v2, :bad

    return-wide v0

    :bad
    const-wide/16 v0, 0x0

    return-wide v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    move-exception v0

    const-wide/16 v1, 0x0

    return-wide v1
.end method


# virtual methods
.method public handleLoadPackage(Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;)V
    .locals 2
    .param p1, "lpp"    # Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;

    .line 144
    sget-boolean v0, Lnn/ecpm/EcpmHook;->started:Z

    if-eqz v0, :cond_0

    return-void

    .line 145
    :cond_0
    const-string v0, "nn.ecpm"

    iget-object v1, p1, Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;->packageName:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    return-void

    .line 146
    :cond_1
    iget-object v0, p1, Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;->classLoader:Ljava/lang/ClassLoader;

    if-nez v0, :cond_2

    return-void

    .line 148
    :cond_2
    const/4 v0, 0x1

    sput-boolean v0, Lnn/ecpm/EcpmHook;->started:Z

    .line 149
    iget-object v0, p1, Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;->packageName:Ljava/lang/String;

    iput-object v0, p0, Lnn/ecpm/EcpmHook;->pkgName:Ljava/lang/String;

    .line 150
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "[EcpmRange] \u6ce8\u5165\u8fdb\u7a0b: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lnn/ecpm/EcpmHook;->pkgName:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lde/robv/android/xposed/XposedBridge;->log(Ljava/lang/String;)V

    .line 151
    iget-object v0, p1, Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;->classLoader:Ljava/lang/ClassLoader;

    invoke-direct {p0, v0}, Lnn/ecpm/EcpmHook;->startInstall(Ljava/lang/ClassLoader;)V

    .line 152
    return-void
.end method
