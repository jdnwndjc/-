.class Lnn/ecpm/EcpmHook$1;
.super Ljava/lang/Object;
.source "EcpmHook.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnn/ecpm/EcpmHook;->startInstall(Ljava/lang/ClassLoader;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnn/ecpm/EcpmHook;

.field final synthetic val$cl:Ljava/lang/ClassLoader;


# direct methods
.method constructor <init>(Lnn/ecpm/EcpmHook;Ljava/lang/ClassLoader;)V
    .locals 0
    .param p1, "this$0"    # Lnn/ecpm/EcpmHook;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 224
    iput-object p1, p0, Lnn/ecpm/EcpmHook$1;->this$0:Lnn/ecpm/EcpmHook;

    iput-object p2, p0, Lnn/ecpm/EcpmHook$1;->val$cl:Ljava/lang/ClassLoader;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 12

    .line 227
    const/4 v0, 0x0

    .line 228
    .local v0, "utilDone":Z
    const/4 v1, 0x0

    .line 229
    .local v1, "configLoaded":Z
    const/4 v2, 0x0

    .line 231
    .local v2, "round":I
    :goto_0
    const/4 v3, 0x1

    add-int/2addr v2, v3

    .line 232
    if-nez v1, :cond_0

    .line 233
    iget-object v4, p0, Lnn/ecpm/EcpmHook$1;->this$0:Lnn/ecpm/EcpmHook;

    invoke-static {v4}, Lnn/ecpm/EcpmHook;->access$000(Lnn/ecpm/EcpmHook;)Z

    move-result v1

    .line 236
    :cond_0
    const/4 v4, 0x0

    .local v4, "done":I
    const/4 v5, 0x0

    .line 238
    .local v5, "left":I
    invoke-static {}, Lnn/ecpm/EcpmHook;->access$100()[Lnn/ecpm/EcpmHook$Target;

    move-result-object v6

    array-length v7, v6

    const/4 v8, 0x0

    :goto_1
    if-ge v8, v7, :cond_3

    aget-object v9, v6, v8

    .line 239
    .local v9, "tgt":Lnn/ecpm/EcpmHook$Target;
    iget-boolean v10, v9, Lnn/ecpm/EcpmHook$Target;->done:Z

    if-nez v10, :cond_1

    iget-object v10, p0, Lnn/ecpm/EcpmHook$1;->this$0:Lnn/ecpm/EcpmHook;

    iget-object v11, p0, Lnn/ecpm/EcpmHook$1;->val$cl:Ljava/lang/ClassLoader;

    invoke-static {v10, v9, v11}, Lnn/ecpm/EcpmHook;->access$200(Lnn/ecpm/EcpmHook;Lnn/ecpm/EcpmHook$Target;Ljava/lang/ClassLoader;)Z

    move-result v10

    if-eqz v10, :cond_1

    .line 240
    iput-boolean v3, v9, Lnn/ecpm/EcpmHook$Target;->done:Z

    .line 242
    :cond_1
    iget-boolean v10, v9, Lnn/ecpm/EcpmHook$Target;->done:Z

    if-eqz v10, :cond_2

    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    .line 243
    :cond_2
    add-int/lit8 v5, v5, 0x1

    .line 238
    .end local v9    # "tgt":Lnn/ecpm/EcpmHook$Target;
    :goto_2
    add-int/lit8 v8, v8, 0x1

    goto :goto_1

    .line 246
    :cond_3
    if-nez v0, :cond_4

    .line 247
    iget-object v6, p0, Lnn/ecpm/EcpmHook$1;->this$0:Lnn/ecpm/EcpmHook;

    iget-object v7, p0, Lnn/ecpm/EcpmHook$1;->val$cl:Ljava/lang/ClassLoader;

    invoke-static {v6, v7}, Lnn/ecpm/EcpmHook;->access$300(Lnn/ecpm/EcpmHook;Ljava/lang/ClassLoader;)Z

    move-result v6

    if-eqz v6, :cond_4

    const/4 v0, 0x1

    .line 249
    :cond_4
    if-eqz v0, :cond_5

    add-int/lit8 v4, v4, 0x1

    goto :goto_3

    .line 250
    :cond_5
    add-int/lit8 v5, v5, 0x1

    .line 252
    :goto_3
    if-nez v5, :cond_6

    if-eqz v1, :cond_6

    .line 253
    iget-object v3, p0, Lnn/ecpm/EcpmHook$1;->this$0:Lnn/ecpm/EcpmHook;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "\u5b8c\u6210 | \u5df2\u6302\u94a9 "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v7, p0, Lnn/ecpm/EcpmHook$1;->this$0:Lnn/ecpm/EcpmHook;

    invoke-static {v7}, Lnn/ecpm/EcpmHook;->access$400(Lnn/ecpm/EcpmHook;)I

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " \u4e2a eCPM \u65b9\u6cd5 | \u968f\u673a\u533a\u95f4 ["

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v7, p0, Lnn/ecpm/EcpmHook$1;->this$0:Lnn/ecpm/EcpmHook;

    .line 254
    invoke-static {v7}, Lnn/ecpm/EcpmHook;->access$500(Lnn/ecpm/EcpmHook;)J

    move-result-wide v7

    invoke-virtual {v6, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " ~ "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v7, p0, Lnn/ecpm/EcpmHook$1;->this$0:Lnn/ecpm/EcpmHook;

    invoke-static {v7}, Lnn/ecpm/EcpmHook;->access$600(Lnn/ecpm/EcpmHook;)J

    move-result-wide v7

    invoke-virtual {v6, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, "] (\u5206)"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 253
    invoke-static {v3, v6}, Lnn/ecpm/EcpmHook;->access$700(Lnn/ecpm/EcpmHook;Ljava/lang/String;)V

    .line 255
    return-void

    .line 258
    :cond_6
    if-eq v2, v3, :cond_7

    rem-int/lit8 v6, v2, 0x19

    if-nez v6, :cond_8

    .line 259
    :cond_7
    iget-object v6, p0, Lnn/ecpm/EcpmHook$1;->this$0:Lnn/ecpm/EcpmHook;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "\u7b49\u5f85\u7c7b\u52a0\u8f7d "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "/"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-static {}, Lnn/ecpm/EcpmHook;->access$100()[Lnn/ecpm/EcpmHook$Target;

    move-result-object v8

    array-length v8, v8

    add-int/2addr v8, v3

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v7, " | \u5df2\u6302\u94a9 "

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v7, p0, Lnn/ecpm/EcpmHook$1;->this$0:Lnn/ecpm/EcpmHook;

    .line 260
    invoke-static {v7}, Lnn/ecpm/EcpmHook;->access$400(Lnn/ecpm/EcpmHook;)I

    move-result v7

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 259
    invoke-static {v6, v3}, Lnn/ecpm/EcpmHook;->access$700(Lnn/ecpm/EcpmHook;Ljava/lang/String;)V

    .line 263
    :cond_8
    const/16 v3, 0x12c

    if-lt v2, v3, :cond_9

    .line 264
    iget-object v3, p0, Lnn/ecpm/EcpmHook$1;->this$0:Lnn/ecpm/EcpmHook;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "\u505c\u6b62\u91cd\u8bd5\uff08\u5df2\u6302\u94a9 "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v7, p0, Lnn/ecpm/EcpmHook$1;->this$0:Lnn/ecpm/EcpmHook;

    invoke-static {v7}, Lnn/ecpm/EcpmHook;->access$400(Lnn/ecpm/EcpmHook;)I

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " \u4e2a eCPM \u65b9\u6cd5\uff09"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v3, v6}, Lnn/ecpm/EcpmHook;->access$700(Lnn/ecpm/EcpmHook;Ljava/lang/String;)V

    .line 265
    return-void

    .line 268
    :cond_9
    const-wide/16 v6, 0x7d0

    :try_start_0
    invoke-static {v6, v7}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 271
    nop

    .line 272
    .end local v4    # "done":I
    .end local v5    # "left":I
    goto/16 :goto_0

    .line 269
    .restart local v4    # "done":I
    .restart local v5    # "left":I
    :catch_0
    move-exception v3

    .line 270
    .local v3, "e":Ljava/lang/InterruptedException;
    return-void
.end method
