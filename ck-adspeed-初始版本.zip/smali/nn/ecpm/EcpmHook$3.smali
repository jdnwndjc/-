.class Lnn/ecpm/EcpmHook$3;
.super Lde/robv/android/xposed/XC_MethodHook;
.source "EcpmHook.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnn/ecpm/EcpmHook;->doHook(Ljava/lang/reflect/Method;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnn/ecpm/EcpmHook;

.field final synthetic val$tag:Ljava/lang/String;


# direct methods
.method constructor <init>(Lnn/ecpm/EcpmHook;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lnn/ecpm/EcpmHook;

    .line 386
    iput-object p1, p0, Lnn/ecpm/EcpmHook$3;->this$0:Lnn/ecpm/EcpmHook;

    iput-object p2, p0, Lnn/ecpm/EcpmHook$3;->val$tag:Ljava/lang/String;

    invoke-direct {p0}, Lde/robv/android/xposed/XC_MethodHook;-><init>()V

    return-void
.end method


# virtual methods
.method protected afterHookedMethod(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V
    .locals 2
    .param p1, "param"    # Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;

    .line 389
    iget-object v0, p0, Lnn/ecpm/EcpmHook$3;->this$0:Lnn/ecpm/EcpmHook;

    iget-object v1, p0, Lnn/ecpm/EcpmHook$3;->val$tag:Ljava/lang/String;

    invoke-static {v0, p1, v1}, Lnn/ecpm/EcpmHook;->access$900(Lnn/ecpm/EcpmHook;Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;Ljava/lang/String;)V

    .line 390
    return-void
.end method
