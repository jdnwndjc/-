.class public final Lnn/ecpm/Config;
.super Ljava/lang/Object;
.source "Config.java"


# static fields
.field public static final ACTION_LOG:Ljava/lang/String; = "nn.ecpm.LOG"

.field public static final AUTHORITY:Ljava/lang/String; = "nn.ecpm.config"

.field public static final DEFAULT_MAX:J = 0x1fbd0L

.field public static final DEFAULT_MIN:J = 0x186a0L

.field public static final DEFAULT_SKIP:Z = true

.field public static final LOG_PREFS:Ljava/lang/String; = "logbuf"

.field public static final PKG:Ljava/lang/String; = "nn.ecpm"

.field public static final PREFS:Ljava/lang/String; = "config"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    return-void
.end method
