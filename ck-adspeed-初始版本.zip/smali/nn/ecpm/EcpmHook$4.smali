.class Lnn/ecpm/EcpmHook$4;
.super Lde/robv/android/xposed/XC_MethodHook;
.source "EcpmHook.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnn/ecpm/EcpmHook;->hookBaiduUtil(Ljava/lang/ClassLoader;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnn/ecpm/EcpmHook;


# direct methods
.method constructor <init>(Lnn/ecpm/EcpmHook;)V
    .locals 0
    .param p1, "this$0"    # Lnn/ecpm/EcpmHook;

    .line 418
    iput-object p1, p0, Lnn/ecpm/EcpmHook$4;->this$0:Lnn/ecpm/EcpmHook;

    invoke-direct {p0}, Lde/robv/android/xposed/XC_MethodHook;-><init>()V

    return-void
.end method


# virtual methods
.method protected afterHookedMethod(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V
    .locals 2
    .param p1, "param"    # Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;

    .line 421
    iget-object v0, p0, Lnn/ecpm/EcpmHook$4;->this$0:Lnn/ecpm/EcpmHook;

    const-string v1, "BaiduAdapterUtil.getEcpm"

    invoke-static {v0, p1, v1}, Lnn/ecpm/EcpmHook;->access$900(Lnn/ecpm/EcpmHook;Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;Ljava/lang/String;)V

    .line 422
    return-void
.end method
