# NOTICE —— 第三方代码与授权状态

本仓库不是一个"全部由本项目作者原创"的代码库。为避免误解，逐块说明。

## 1. `src-java/` 与 `src-ui/`（本项目原创）

`PlayerScan.java`、`MainActivity.java`、`FloatService.java`、`LogReceiver.java`、`Diag.java`、`EcpmPlus.java` 以及 `build*.sh`、`docs/` 均为本项目作者编写，按 **GPL-3.0** 授权（见 `LICENSE`）。

## 2. `smali/`（上游基线，非本项目原创）

`smali/nn/ecpm/` 与 `smali/com/adspeed/hook/` 是对**上游已发布 APK 的反编译产物**（上游项目原名见 `docs/HISTORY.md`）。

- **版权归上游作者所有**，本项目作者未获得书面授权。
- 收录目的：作为 `EcpmHook` 的**只读研究基线**，用于对照 `EcpmPlus` 的补充范围，以及理解原模块的类结构。
- 该目录**不适用**本仓库的 GPL-3.0 授权。GPL 只能由权利人授予，本项目作者无权替上游授权。
- 如果你要复用其中任何代码，请自行联系上游权利人取得许可。
- **权利人如有异议**：请开 issue 或邮件说明，维护者会立即删除该目录及涉及它的构建步骤，不做争辩。

`android:value="zy广告助手"` 这类字符串仅出现在 `build_full.sh` 的改名逻辑中（把上游 `strings.xml` 里的旧名替换为本项目名），属于构建适配，不构成对上游商标的使用主张。

## 3. `lib/stub.jar`（自建 API 桩）

只包含 `de.robv.android.xposed.*` 的**方法签名**，没有任何实现，`javac` 编译期使用，不进入 dex。

Xposed API 本身由 rovo89 以 Apache-2.0 发布；LSPosed 以 GPL-3.0 发布。本项目不链接其运行时，仅以编译桩对接。

## 4. 字体 / 图片 / 图标

- `assets/bg.jpg`：本项目自带默认背景，随仓库以 GPL-3.0 提供。
- 界面未使用第三方图标库，全部为代码绘制的图形（`GradientDrawable` / `ShapeDrawable`）。

## 5. 依赖清单

| 依赖 | 用途 | 许可证 | 是否随仓库分发 |
|---|---|---|---|
| `lib/stub.jar` | 编译期 API 桩 | 自建（签名取自 Apache-2.0 的 Xposed API） | 是 |
| Android SDK | 编译 | Android SDK License | 否（用户自备） |
| apktool | 完整打包 | Apache-2.0 | 否（用户自备） |

---

**一句话总结**：自研部分 GPL-3.0；`smali/` 是别人的，只做研究基线收录，随时可删。
